# -*- coding: utf-8 -*-
"""Entry points the Android app (MainActivity.java) calls through Chaquopy.  The converter itself is the unchanged desktop code
(wwe2k_to_wii.py and friends, next to this file); web_runner.py is the same glue the browser page uses."""
import ctypes
import os
import threading
import traceback

_state = {}


def init(base, sink):
    """base: the app's private work folder (in / work / out are created below it); sink: a Java object with log(String)"""
    os.environ['WEB_BASE'] = base
    for d in ('in', 'work', 'out'):
        os.makedirs(os.path.join(base, d), exist_ok=True)
    import web_runner
    web_runner.IN_DIR = base + '/in'
    web_runner.WORK = base + '/work'
    web_runner.OUT_DIR = base + '/out'
    _state['R'] = web_runner
    web_runner.set_logger(lambda s: sink.log(str(s)))
    import sys
    return sys.version.split()[0]


def _wrap(name, fn, *args):
    _state['tid'] = threading.get_ident()
    try:
        return fn(*args)
    except BaseException:
        raise RuntimeError(name + " failed:\n" + traceback.format_exc())
    finally:
        _state['tid'] = None


def detect():
    R = _state['R']
    return _wrap('detect', R.detect)


def run(opts_json):
    R = _state['R']
    return _wrap('convert', R.convert, opts_json)


def cancel():
    """Cancel button: raises KeyboardInterrupt inside the converter thread (it stops at the next Python statement)"""
    tid = _state.get('tid')
    if tid:
        ctypes.pythonapi.PyThreadState_SetAsyncExc(ctypes.c_ulong(tid), ctypes.py_object(KeyboardInterrupt))
