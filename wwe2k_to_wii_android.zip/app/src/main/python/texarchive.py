# -*- coding: utf-8 -*-
"""Texture archive (PACH entry 9):  u32 count, u32 0x100, u32 0, u32 0x10, then count x 32-byte rows
[name 16][ext 4 'tpl\\0'][size u32][offset u32][pad u32], TPL files follow (first one at 0x80)."""
import struct


def read(raw):
    n = struct.unpack_from('<I', raw, 0)[0]
    head = raw[:16]
    ents = []
    for i in range(n):
        o = 16 + 32 * i
        name = raw[o:o + 16].split(b'\0')[0].decode('latin1')
        ext = raw[o + 16:o + 20]
        size, off = struct.unpack_from('<II', raw, o + 20)
        ents.append([name, ext, raw[off:off + size]])
    return head, ents


def build(head, ents):
    n = len(ents)
    table = bytearray(head)
    struct.pack_into('<I', table, 0, n)
    start = (16 + 32 * n + 0x7F) & ~0x7F
    off = start
    body = bytearray()
    for name, ext, data in ents:
        table += name.encode('latin1').ljust(16, b'\0') + ext + struct.pack('<III', len(data), off, 0)
        body += data
        pad = (-len(data)) % 32
        body += b'\0' * pad
        off += len(data) + pad
    return bytes(table) + b'\0' * (start - len(table)) + bytes(body)
