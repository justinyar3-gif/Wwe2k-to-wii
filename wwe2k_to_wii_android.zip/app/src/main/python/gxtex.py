# -*- coding: utf-8 -*-
"""GameCube/Wii TPL helpers: CMPR (fmt 14) decode/encode, C4/C8 decode."""
import struct
import numpy as np

def _rgb565(c):
    r = (c >> 11) & 31; g = (c >> 5) & 63; b = c & 31
    return np.stack([(r << 3) | (r >> 2), (g << 2) | (g >> 4), (b << 3) | (b >> 2)], -1)

def decode_cmpr(data, w, h):
    out = np.zeros((h, w, 4), np.uint8)
    p = 0
    for by in range(0, h, 8):
        for bx in range(0, w, 8):
            for sy in (0, 4):
                for sx in (0, 4):
                    c0, c1 = struct.unpack_from('>HH', data, p)
                    idx = data[p + 4:p + 8]
                    p += 8
                    a = _rgb565(np.array(c0)).astype(int); b = _rgb565(np.array(c1)).astype(int)
                    if c0 > c1:
                        pal = [a, b, (2 * a + b) // 3, (a + 2 * b) // 3]
                        al = [255] * 4
                    else:
                        pal = [a, b, (a + b) // 2, np.array([0, 0, 0])]
                        al = [255, 255, 255, 0]
                    for y in range(4):
                        row = idx[y]
                        for x in range(4):
                            k = (row >> (6 - 2 * x)) & 3
                            yy, xx = by + sy + y, bx + sx + x
                            if yy < h and xx < w:
                                out[yy, xx, :3] = pal[k]; out[yy, xx, 3] = al[k]
    return out

def encode_cmpr(rgba):
    """rgba uint8 HxWx4 -> CMPR bytes (opaque 4-colour blocks; alpha < 128 -> 3-colour+transparent block)."""
    h, w = rgba.shape[:2]
    H, W = (h + 7) & ~7, (w + 7) & ~7
    img = np.zeros((H, W, 4), np.uint8); img[:h, :w] = rgba
    if H > h: img[h:, :w] = rgba[-1:, :]
    if W > w: img[:, w:] = img[:, w - 1:w]
    # blocks 4x4 -> (H/4, W/4, 16, 4)
    bl = img.reshape(H // 4, 4, W // 4, 4, 4).transpose(0, 2, 1, 3, 4).reshape(-1, 16, 4).astype(np.float32)
    n = bl.shape[0]
    rgb = bl[:, :, :3]
    # endpoints: principal axis of the block colours
    mean = rgb.mean(1, keepdims=True)
    cen = rgb - mean
    cov = np.einsum('nij,nik->njk', cen, cen)
    w_, v_ = np.linalg.eigh(cov)
    axis = v_[:, :, -1]                                   # n,3 largest eigenvector
    proj = np.einsum('nij,nj->ni', cen, axis)
    lo = rgb[np.arange(n), proj.argmin(1)]
    hi = rgb[np.arange(n), proj.argmax(1)]
    def to565(c):
        c = np.clip(np.rint(c), 0, 255).astype(np.int32)
        return ((c[:, 0] >> 3) << 11) | ((c[:, 1] >> 2) << 5) | (c[:, 2] >> 3)
    c0, c1 = to565(hi), to565(lo)
    sw = c0 < c1
    c0, c1 = np.where(sw, c1, c0), np.where(sw, c0, c1)
    eq = c0 == c1
    c0 = np.where(eq & (c0 < 0xFFFF), c0 + 1, c0)           # force 4-colour mode (c0 > c1)
    e0 = _rgb565(c0).astype(np.float32); e1 = _rgb565(c1).astype(np.float32)
    pal = np.stack([e0, e1, (2 * e0 + e1) / 3, (e0 + 2 * e1) / 3], 1)      # n,4,3
    d = ((rgb[:, :, None, :] - pal[:, None, :, :]) ** 2).sum(-1)           # n,16,4
    k = d.argmin(2).astype(np.uint8)                                       # n,16
    trans = bl[:, :, 3] < 128
    # blocks with transparent pixels: 3-colour mode (c0 <= c1), index 3 = transparent
    has_t = trans.any(1)
    if has_t.any():
        a_ = np.minimum(c0, c1); b_ = np.maximum(c0, c1)
        t0 = np.where(has_t, a_, c0); t1 = np.where(has_t, b_, c1)
        f0 = _rgb565(t0).astype(np.float32); f1 = _rgb565(t1).astype(np.float32)
        p3 = np.stack([f0, f1, (f0 + f1) / 2], 1)
        d3 = ((rgb[:, :, None, :] - p3[:, None, :, :]) ** 2).sum(-1).argmin(2).astype(np.uint8)
        d3[trans] = 3
        k = np.where(has_t[:, None], d3, k)
        c0, c1 = t0, t1
    k = k.reshape(n, 4, 4)
    idxb = (k[:, :, 0] << 6) | (k[:, :, 1] << 4) | (k[:, :, 2] << 2) | k[:, :, 3]   # n,4 bytes (row-wise)
    blk = np.zeros((n, 8), np.uint8)
    blk[:, 0] = (c0 >> 8) & 255; blk[:, 1] = c0 & 255; blk[:, 2] = (c1 >> 8) & 255; blk[:, 3] = c1 & 255
    blk[:, 4:8] = idxb
    # arrange into 8x8 tiles (four 4x4 sub-blocks: TL, TR, BL, BR)
    blk = blk.reshape(H // 4, W // 4, 8)
    out = blk.reshape(H // 8, 2, W // 8, 2, 8).transpose(0, 2, 1, 3, 4).reshape(-1)
    return out.tobytes()

def tpl_header_info(b):
    it = struct.unpack_from('>I', b, 8)[0]
    ih, ph = struct.unpack_from('>II', b, it)
    h, w, fmt, off = struct.unpack_from('>HHII', b, ih)
    return dict(w=w, h=h, fmt=fmt, data_off=off, img_hdr=ih, pal_hdr=ph)

def decode_tpl(b):
    i = tpl_header_info(b)
    if i['fmt'] == 14:
        return decode_cmpr(b[i['data_off']:], i['w'], i['h'])
    raise ValueError('unsupported TPL format %d' % i['fmt'])


# ---------------------------------------------------------------------------------------------- C8 (CI8) + RGB5A3 palette
def encode_c8_tpl(rgb, template96, width=256, height=256):
    """Build a CI8 TPL (palette RGB5A3, all opaque) from an RGB image, re-using the header of an existing C8 TPL
    (`template96` = first 96 bytes of e.g. ch107's 'hair_' texture)."""
    from PIL import Image
    im = Image.fromarray(np.ascontiguousarray(rgb[..., :3]).astype(np.uint8)).convert('RGB').resize((width, height), Image.LANCZOS)
    q = im.quantize(256, method=Image.Quantize.MEDIANCUT, dither=Image.Dither.NONE)
    pal = np.array(q.getpalette()[:768], np.uint8).reshape(-1, 3)
    if len(pal) < 256:
        pal = np.concatenate([pal, np.zeros((256 - len(pal), 3), np.uint8)])
    idx = np.asarray(q, np.uint8)
    # RGB5A3: 1xxxxxxx opaque = 1 rrrrr ggggg bbbbb
    p16 = 0x8000 | ((pal[:, 0].astype(np.uint16) >> 3) << 10) | ((pal[:, 1].astype(np.uint16) >> 3) << 5) | (pal[:, 2].astype(np.uint16) >> 3)
    H = (height + 3) & ~3
    W = (width + 7) & ~7
    full = np.zeros((H, W), np.uint8)
    full[:height, :width] = idx
    tiles = full.reshape(H // 4, 4, W // 8, 8).transpose(0, 2, 1, 3).reshape(-1)
    hdr = bytearray(template96)
    struct.pack_into('>HH', hdr, 20, height, width)                 # image header: height, width
    data_off = struct.unpack_from('>I', hdr, 20 + 8)[0]
    pal_off = data_off + len(tiles)
    struct.pack_into('>I', hdr, 56 + 8, pal_off)                    # palette header: data offset
    return bytes(hdr) + tiles.tobytes() + p16.astype('>u2').tobytes()


def decode_c8_tpl(b):
    i = tpl_header_info(b)
    w, h, off = i['w'], i['h'], i['data_off']
    pal_n, _, _, pf, po = struct.unpack_from('>HBBII', b, i['pal_hdr'])
    pal = np.frombuffer(b[po:po + pal_n * 2], '>u2').astype(np.uint32)
    rgba = np.zeros((len(pal), 4), np.uint8)
    op = (pal & 0x8000) != 0
    rgba[:, 0] = np.where(op, ((pal >> 10) & 31) * 255 // 31, ((pal >> 8) & 15) * 17)
    rgba[:, 1] = np.where(op, ((pal >> 5) & 31) * 255 // 31, ((pal >> 4) & 15) * 17)
    rgba[:, 2] = np.where(op, (pal & 31) * 255 // 31, (pal & 15) * 17)
    rgba[:, 3] = np.where(op, 255, ((pal >> 12) & 7) * 255 // 7)
    H = (h + 3) & ~3; W = (w + 7) & ~7
    t = np.frombuffer(b[off:off + H * W], np.uint8).reshape(H // 4, W // 8, 4, 8).transpose(0, 2, 1, 3).reshape(H, W)
    return rgba[t[:h, :w]]


def rgba_to_rgb5a3(pal):
    pal = np.asarray(pal, np.uint16)
    r, gg, b, a = pal[:, 0], pal[:, 1], pal[:, 2], pal[:, 3]
    op = a >= 224
    full = 0x8000 | ((r >> 3) << 10) | ((gg >> 3) << 5) | (b >> 3)
    part = ((a >> 5) << 12) | ((r >> 4) << 8) | ((gg >> 4) << 4) | (b >> 4)
    return np.where(op, full, part).astype('>u2')


def c8_template_header(donor_tpl=None):
    """96-byte header of a one-image CI8 TPL with an RGB5A3 palette (image data directly behind it), the `template96`
    of encode_c8_tpl_indexed, built from scratch so no existing C8 texture is needed.  Wrap / filter modes are copied
    from `donor_tpl` (any TPL) when it has plausible ones, else REPEAT / LINEAR (what the game's own textures use)."""
    wrap_s, wrap_t, mn, mg = 1, 1, 1, 1
    if donor_tpl is not None:
        try:
            i = tpl_header_info(donor_tpl)
            pal_fmt = struct.unpack_from('>HBBII', donor_tpl, i['pal_hdr'])[3]
            if i['fmt'] == 9 and i['data_off'] == 96 and pal_fmt == 2 and len(donor_tpl) >= 96:
                return bytes(donor_tpl[:96])             # already a plain C8 / RGB5A3 texture: use its own header
        except Exception:
            pass
        try:
            i = tpl_header_info(donor_tpl)
            v = struct.unpack_from('>IIII', donor_tpl, i['img_hdr'] + 12)
            if max(v[:2]) <= 2 and max(v[2:]) <= 5:
                wrap_s, wrap_t, mn, mg = v
        except Exception:
            pass
    hdr = bytearray(96)
    struct.pack_into('>IIII', hdr, 0, 0x0020AF30, 1, 0x0C, 0x14)      # magic, image count, table offset, image header offset
    struct.pack_into('>I', hdr, 16, 0x38)                                 # palette header offset
    struct.pack_into('>HHIIIIIIf', hdr, 20, 256, 256, 9, 96, wrap_s, wrap_t, mn, mg, 0.0)   # h, w, fmt C8, data offset, ...
    struct.pack_into('>HBBII', hdr, 56, 256, 0, 0, 2, 0)                 # 256 palette entries, RGB5A3, data offset set later
    return bytes(hdr)


def encode_c8_tpl_indexed(idx, pal_rgba, template96):
    """idx: HxW uint8 palette indices, pal_rgba: (<=256,4).  Header re-used from a C8 TPL (template96)."""
    h, w = idx.shape
    pal = np.zeros((256, 4), np.uint16)
    pal[:len(pal_rgba)] = pal_rgba
    H = (h + 3) & ~3
    W = (w + 7) & ~7
    full = np.zeros((H, W), np.uint8)
    full[:h, :w] = idx
    tiles = full.reshape(H // 4, 4, W // 8, 8).transpose(0, 2, 1, 3).reshape(-1)
    hdr = bytearray(template96)
    struct.pack_into('>HH', hdr, 20, h, w)
    data_off = struct.unpack_from('>I', hdr, 28)[0]
    struct.pack_into('>I', hdr, 64, data_off + len(tiles))
    return bytes(hdr) + tiles.tobytes() + rgba_to_rgb5a3(pal).tobytes()
