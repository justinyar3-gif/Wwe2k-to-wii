# -*- coding: utf-8 -*-
"""Quadric-error edge-collapse decimation (Garland-Heckbert) with
   * boundary + UV-seam preservation (extra penalty quadrics),
   * skin-weight aware cost (vertices with different bone binding are collapsed last),
   * fold-over / non-manifold protection,
   * per-corner attributes (UVs) that travel with the triangles.
Half-edge collapses only (the surviving vertex keeps its position) so the skin weights of the survivor stay valid."""
import heapq
import math


def _plane_q(p0, p1, p2, w=1.0):
    ux, uy, uz = p1[0] - p0[0], p1[1] - p0[1], p1[2] - p0[2]
    vx, vy, vz = p2[0] - p0[0], p2[1] - p0[1], p2[2] - p0[2]
    nx, ny, nz = uy * vz - uz * vy, uz * vx - ux * vz, ux * vy - uy * vx
    ln = math.sqrt(nx * nx + ny * ny + nz * nz)
    if ln < 1e-14:
        return None, None
    area = 0.5 * ln
    a, b, c = nx / ln, ny / ln, nz / ln
    d = -(a * p0[0] + b * p0[1] + c * p0[2])
    k = area * w
    return (k * a * a, k * a * b, k * a * c, k * a * d, k * b * b, k * b * c, k * b * d, k * c * c, k * c * d, k * d * d), (a, b, c, ln)


def _qadd(q, r):
    return tuple(x + y for x, y in zip(q, r))


def _qerr(q, p):
    x, y, z = p
    return (q[0] * x * x + 2 * q[1] * x * y + 2 * q[2] * x * z + 2 * q[3] * x + q[4] * y * y + 2 * q[5] * y * z
            + 2 * q[6] * y + q[7] * z * z + 2 * q[8] * z + q[9])


def _wdiff(wa, wb):
    if not wa and not wb:
        return 0.0
    s = 0.0
    for k, v in wa.items():
        s += abs(v - wb.get(k, 0.0))
    for k, v in wb.items():
        if k not in wa:
            s += v
    return s


def decimate(P, tris, cuv, target, weights=None, seam_w=40.0, bound_w=200.0, weight_w=1.0,
             locked=None, log=lambda s: None, target_verts=None, importance=None, len_w=0.05, return_index=False):
    """P: list of (x,y,z).  tris: list of (a,b,c).  cuv: list of ((u,v),(u,v),(u,v)) per triangle corner.
    weights: optional list (per vertex) of {bone: w}.  locked: optional set of vertex ids that are never removed.
    importance: optional per-vertex multiplier (>0) of the collapse cost: vertices with a high value (face, torso,
    hands) are collapsed later, so they keep more triangles; low values (skin hidden under clothes) go first.
    len_w: small edge-length term so flat regions are thinned evenly instead of in vertex-index order.
    Returns (new_tris, new_cuv) referencing the ORIGINAL vertex ids (compact afterwards with compact()); with
    return_index=True also the list of the input triangle index each surviving triangle comes from (to carry per-triangle
    data such as the donor submesh through the decimation)."""
    n = len(P)
    tv = [list(t) for t in tris]
    tu = [list(c) for c in cuv]
    alive = [True] * len(tv)
    vt = [set() for _ in range(n)]
    for ti, t in enumerate(tv):
        for v in t:
            vt[v].add(ti)
    nalive = len(tv)
    nvert = sum(1 for x in vt if x)
    if nalive <= target and (not target_verts or nvert <= target_verts):
        if return_index:
            return [tuple(t) for t in tv], [tuple(c) for c in tu], list(range(len(tv)))
        return [tuple(t) for t in tv], [tuple(c) for c in tu]
    locked = locked or set()
    weights = weights or [None] * n

    # ---- quadrics --------------------------------------------------------------------------------
    Q = [(0.0,) * 10 for _ in range(n)]
    tn = [None] * len(tv)
    edge_tris = {}
    for ti, (a, b, c) in enumerate(tv):
        q, nn = _plane_q(P[a], P[b], P[c])
        tn[ti] = nn
        if q is not None:
            for v in (a, b, c):
                Q[v] = _qadd(Q[v], q)
        for x, y in ((a, b), (b, c), (c, a)):
            edge_tris.setdefault((x, y) if x < y else (y, x), []).append(ti)
    el = []
    for (x, y), ts in edge_tris.items():
        el.append(math.dist(P[x], P[y]))
    el.sort()
    med = el[len(el) // 2] if el else 1.0
    wscale = med * med * 0.02

    def uv_of(ti, v):
        t = tv[ti]
        return tu[ti][t.index(v)]

    # boundary / seam penalty planes
    for (x, y), ts in edge_tris.items():
        pen = None
        if len(ts) == 1:
            pen = bound_w
        elif len(ts) == 2:
            t0, t1 = ts
            u0x, u0y = uv_of(t0, x), uv_of(t0, y)
            u1x, u1y = uv_of(t1, x), uv_of(t1, y)
            if (abs(u0x[0] - u1x[0]) + abs(u0x[1] - u1x[1]) > 1e-5) or (abs(u0y[0] - u1y[0]) + abs(u0y[1] - u1y[1]) > 1e-5):
                pen = seam_w
        else:
            pen = bound_w
        if pen:
            nn = tn[ts[0]]
            if nn is None:
                continue
            a_, b_, c_, _ = nn
            ex, ey, ez = P[y][0] - P[x][0], P[y][1] - P[x][1], P[y][2] - P[x][2]
            L = math.sqrt(ex * ex + ey * ey + ez * ez)
            if L < 1e-12:
                continue
            # plane through the edge, perpendicular to the face
            px, py, pz = ey * c_ - ez * b_, ez * a_ - ex * c_, ex * b_ - ey * a_
            pl = math.sqrt(px * px + py * py + pz * pz)
            if pl < 1e-12:
                continue
            px, py, pz = px / pl, py / pl, pz / pl
            d = -(px * P[x][0] + py * P[x][1] + pz * P[x][2])
            k = pen * L * L
            q = (k * px * px, k * px * py, k * px * pz, k * px * d, k * py * py, k * py * pz, k * py * d,
                 k * pz * pz, k * pz * d, k * d * d)
            Q[x] = _qadd(Q[x], q)
            Q[y] = _qadd(Q[y], q)

    # ---- helpers -------------------------------------------------------------------------------------
    def nbrs(v):
        s = set()
        for ti in vt[v]:
            s.update(tv[ti])
        s.discard(v)
        return s

    lscale = len_w * med * med
    imp = importance

    def cost(a, b):
        """cost of collapsing a INTO b"""
        e = _qerr(_qadd(Q[a], Q[b]), P[b])
        if e < 0:
            e = 0.0
        if weight_w and (weights[a] or weights[b]):
            e += weight_w * wscale * _wdiff(weights[a] or {}, weights[b] or {})
        if lscale:
            dx, dy, dz = P[a][0] - P[b][0], P[a][1] - P[b][1], P[a][2] - P[b][2]
            e += lscale * (dx * dx + dy * dy + dz * dz)
        if imp is not None:
            e *= 0.5 * (imp[a] + imp[b])
        return e

    ver = [0] * n
    heap = []
    for (x, y) in edge_tris:
        for a, b in ((x, y), (y, x)):
            if a in locked:
                continue
            heapq.heappush(heap, (cost(a, b), a, b, ver[a], ver[b]))

    def can_collapse(a, b):
        shared = [ti for ti in vt[a] if b in tv[ti]]
        if not shared or len(shared) > 2:
            return False
        opp = set()
        for ti in shared:
            for v in tv[ti]:
                if v != a and v != b:
                    opp.add(v)
        na, nb = nbrs(a), nbrs(b)
        if (na & nb) != opp:
            return False                                   # link condition (keeps the surface manifold)
        pb = P[b]
        for ti in vt[a]:
            t = tv[ti]
            if b in t:
                continue
            i = t.index(a)
            p1, p2 = P[t[(i + 1) % 3]], P[t[(i + 2) % 3]]
            old = tn[ti]
            ux, uy, uz = p1[0] - pb[0], p1[1] - pb[1], p1[2] - pb[2]
            vx, vy, vz = p2[0] - pb[0], p2[1] - pb[1], p2[2] - pb[2]
            nx, ny, nz = uy * vz - uz * vy, uz * vx - ux * vz, ux * vy - uy * vx
            ln = math.sqrt(nx * nx + ny * ny + nz * nz)
            if ln < 1e-12:
                return False
            if old is not None:
                # triangle orientation must not flip (cos limit) - old normal is for the OLD orientation
                p0 = P[a]
                ox, oy, oz = old[0], old[1], old[2]
                # orient: old triangle vertices order (a, p1, p2) -> compare in same order
                if (nx * ox + ny * oy + nz * oz) / ln < 0.15:
                    return False
        return True

    # ---- main loop ---------------------------------------------------------------------------------------
    removed = 0
    while (nalive > target or (target_verts and nvert > target_verts)) and heap:
        c, a, b, va, vb = heapq.heappop(heap)
        if ver[a] != va or ver[b] != vb or not vt[a] or not vt[b]:
            continue
        if not can_collapse(a, b):
            continue
        # collapse a -> b
        # UV of a and b inside the triangles that disappear: corners of the moving triangles that sit in the same
        # UV chart get b's UV, so every vertex keeps ONE uv per chart (this is what keeps the triangle strips long)
        shared_uv = []
        for ti in vt[a]:
            t = tv[ti]
            if b in t:
                shared_uv.append((tu[ti][t.index(a)], tu[ti][t.index(b)]))
        dying = set()
        for ti in list(vt[a]):
            t = tv[ti]
            if b in t:
                alive[ti] = False
                nalive -= 1
                dying.update(t)
                for v in t:
                    vt[v].discard(ti)
            else:
                i = t.index(a)
                ua = tu[ti][i]
                for sa, sb in shared_uv:
                    if abs(ua[0] - sa[0]) + abs(ua[1] - sa[1]) < 1e-6:
                        tu[ti][i] = sb
                        break
                t[i] = b
                vt[b].add(ti)
        vt[a] = set()
        nvert -= 1
        for v in dying:                                    # a whole island collapsed: its other vertices are gone too
            if v != a and not vt[v]:
                nvert -= 1
        Q[b] = _qadd(Q[b], Q[a])
        # merge weights: keep b's (survivor) weights
        ver[b] += 1
        ver[a] += 1
        # refresh normals of changed triangles
        for ti in vt[b]:
            t = tv[ti]
            q, nn = _plane_q(P[t[0]], P[t[1]], P[t[2]])
            tn[ti] = nn
        # only the edges that touch the survivor b changed (its quadric / position / ring): they are re-queued below, every
        # other queued edge (w, x) stays valid.  (Bumping ver[w] of the whole ring used to drop those ring edges from the
        # queue for good, so regions around earlier collapses could not be thinned any further.)
        for w in nbrs(b):
            if w not in locked:
                heapq.heappush(heap, (cost(w, b), w, b, ver[w], ver[b]))
            if b not in locked:
                heapq.heappush(heap, (cost(b, w), b, w, ver[b], ver[w]))
        removed += 1
        if removed % 4000 == 0:
            log("    ... decimating: %d triangles left (target %d)" % (nalive, target))
    outt, outc, outi = [], [], []
    for ti, t in enumerate(tv):
        if alive[ti] and t[0] != t[1] and t[1] != t[2] and t[0] != t[2]:
            outt.append(tuple(t)); outc.append(tuple(tu[ti])); outi.append(ti)
    if return_index:
        return outt, outc, outi
    return outt, outc


def components(tris):
    """connected components (by shared vertices) -> list of lists of triangle indices"""
    parent = {}

    def find(x):
        while parent.setdefault(x, x) != x:
            parent[x] = parent[parent[x]]
            x = parent[x]
        return x
    for t in tris:
        r = find(t[0])
        for v in t[1:]:
            rv = find(v)
            if rv != r:
                parent[rv] = r
    groups = {}
    for i, t in enumerate(tris):
        groups.setdefault(find(t[0]), []).append(i)
    return list(groups.values())


def tri_area(P, t):
    a, b, c = P[t[0]], P[t[1]], P[t[2]]
    ux, uy, uz = b[0] - a[0], b[1] - a[1], b[2] - a[2]
    vx, vy, vz = c[0] - a[0], c[1] - a[1], c[2] - a[2]
    nx, ny, nz = uy * vz - uz * vy, uz * vx - ux * vz, ux * vy - uy * vx
    return 0.5 * math.sqrt(nx * nx + ny * ny + nz * nz)


def prune_small_components(P, tris, cuv, min_tris=12, min_area_frac=0.0008, return_index=False):
    """Drop only really tiny detached islands (stray stitches / loose fragments).  Islands are kept when they have
    >= min_tris triangles or a visible share of the surface (the old limits - 40 triangles / 0.4 % - also removed
    belt buckles, laces, ear pieces and other small but visible parts)."""
    comps = components(tris)
    areas = [sum(tri_area(P, tris[i]) for i in c) for c in comps]
    tot = sum(areas) or 1.0
    keep = []
    for c, a in zip(comps, areas):
        if len(c) >= min_tris or a / tot >= min_area_frac:
            keep.extend(c)
    keep.sort()
    ndrop = len(comps) - len([1 for c, a in zip(comps, areas) if len(c) >= min_tris or a / tot >= min_area_frac])
    if return_index:
        return [tris[i] for i in keep], [cuv[i] for i in keep], len(comps), ndrop, keep
    return [tris[i] for i in keep], [cuv[i] for i in keep], len(comps), ndrop


def enforce_budget(P, tris, cuv, max_tris, max_verts, tags=None):
    """last resort when edge collapse stalls: remove the smallest islands until the limits hold.
    tags: optional per-triangle list that is filtered along (then returned as a third value)."""
    def out(t, c, g):
        return (t, c) if tags is None else (t, c, g)
    while True:
        nv = len(set(v for t in tris for v in t))
        if len(tris) <= max_tris and nv <= max_verts:
            return out(tris, cuv, tags)
        comps = components(tris)
        if len(comps) <= 1:
            return out(tris, cuv, tags)
        areas = sorted((sum(tri_area(P, tris[i]) for i in c), k) for k, c in enumerate(comps))
        drop = set(comps[areas[0][1]])
        if tags is not None:
            tags = [g for i, g in enumerate(tags) if i not in drop]
        tris = [t for i, t in enumerate(tris) if i not in drop]
        cuv = [c for i, c in enumerate(cuv) if i not in drop]


def cluster_decimate(P, tris, cuv, N, W, target_verts, target_tris=None):
    """Vertex clustering (Rossignac-Borrel) for hair/beard *card* meshes made of hundreds of tiny islands: edge
    collapse cannot merge across islands, a spatial grid can.  The grid is refined until the vertex budget is just met.
    Returns (P, N, W, tris, cuv) for the clustered mesh; every triangle keeps its own corner UVs."""
    import numpy as np
    P = np.asarray(P, float)
    N = np.asarray(N, float)
    lo = P.min(0)
    ext = float((P.max(0) - lo).max()) or 1.0
    T_ = np.asarray(tris)

    def clusters(cell):
        k = np.floor((P - lo) / cell).astype(np.int64)
        _, inv = np.unique(k, axis=0, return_inverse=True)
        inv = inv.reshape(-1)
        tc = inv[T_]
        ok = (tc[:, 0] != tc[:, 1]) & (tc[:, 1] != tc[:, 2]) & (tc[:, 0] != tc[:, 2])
        tc = np.sort(tc[ok], axis=1)
        ntri = len(np.unique(tc, axis=0)) if len(tc) else 0
        nvert = len(np.unique(tc)) if len(tc) else 0
        return inv, nvert, ntri

    def fits(cell):
        inv, nv, nt = clusters(cell)
        return nv <= target_verts and (target_tris is None or nt <= target_tris)
    a, b = ext / 400.0, ext / 2.0
    for _ in range(26):                                     # smallest cell that fits both budgets
        mid = (a * b) ** 0.5
        if fits(mid):
            b = mid
        else:
            a = mid
    inv = clusters(b)[0]
    nc = inv.max() + 1
    cnt = np.bincount(inv, minlength=nc).astype(float)
    Pm = np.zeros((nc, 3)); Nm = np.zeros((nc, 3))
    np.add.at(Pm, inv, P); np.add.at(Nm, inv, N)
    Pm /= cnt[:, None]
    Nm /= np.maximum(np.linalg.norm(Nm, axis=1, keepdims=True), 1e-9)
    first = np.full(nc, -1)
    for r in range(len(inv) - 1, -1, -1):
        first[inv[r]] = r
    Wm = [W[first[c]] for c in range(nc)]
    seen, nt, ncv = set(), [], []
    for t, c in zip(tris, cuv):
        x, y, z = int(inv[t[0]]), int(inv[t[1]]), int(inv[t[2]])
        if x == y or y == z or x == z:
            continue
        key = tuple(sorted((x, y, z)))
        if key in seen:
            continue
        seen.add(key)
        nt.append((x, y, z)); ncv.append(c)
    return [tuple(p) for p in Pm], [n for n in Nm], Wm, nt, ncv
