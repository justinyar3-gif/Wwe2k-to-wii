# -*- coding: utf-8 -*-
"""Rest-pose retargeting: bring the 2K26 bind pose to the WWE 13 (Wii) rest pose.

Joint landmarks are measured *from the skin weights* of both meshes (the point where two neighbouring bone groups
overlap), so no 2K bone-transform table is needed.  Every bone group then gets a similarity transform
(rotation aligning the bone direction + uniform scale matching the bone length, pivot at the proximal joint) and the
mesh is deformed with linear blend skinning using its own weights."""
import numpy as np

SIDES = ('L', 'R')


def groups_for(side):
    S = side
    return {
        'clav': ['Bip %s Clavicle' % S],
        'uarm': ['Bip %s UpperArm' % S, '%s_UpperArm_x' % S.lower().upper()],
        'farm': ['Bip %s Forearm' % S, '%s_Wrist_x' % S, '%s_Wrist_x2' % S, '%s_Elbow_j' % S.lower()],
        'hand': ['Bip %s Hand' % S] + ['Bip %s Finger%s' % (S, f) for f in
                                       ('0', '01', '02', '1', '11', '12', '2', '21', '22', '3', '31', '32', '4', '41', '42')],
        'thigh': ['Bip %s Thigh' % S, '%s_Thigh_x' % S],
        'calf': ['Bip %s Calf' % S],
        'foot': ['Bip %s Foot' % S],
        'toe': ['Bip %s Toe0' % S],
    }


TORSO = ['Bip', 'Bip Pelvis', 'Bip Spine', 'Bip Spine1']
HEAD = ['Bip Neck', 'Neck_x', 'Bip Head', 'l_eye', 'r_eye', 'u_kuchi', 'd_kuchi']


def _norm(n):
    return n.replace(' ', '').replace('_', '').lower()


def group_table():
    """bone name (normalised) -> group key"""
    t = {}
    for n in TORSO:
        t[_norm(n)] = 'torso'
    for n in HEAD:
        t[_norm(n)] = 'head'
    for s in SIDES:
        for g, names in groups_for(s).items():
            for n in names:
                t[_norm(n)] = g + s
    return t


def vertex_group_weights(W, table):
    """W: per vertex {bone: w} -> (n, G) matrix and list of group keys"""
    keys = sorted(set(table.values()))
    kid = dict((k, i) for i, k in enumerate(keys))
    M = np.zeros((len(W), len(keys)))
    for i, w in enumerate(W):
        for b, x in w.items():
            k = table.get(_norm(b))
            if k is None:
                k = 'torso'
            M[i, kid[k]] += x
    return M, keys


def _overlap_point(P, M, kid, a, b, fallback=None):
    wa, wb = M[:, kid[a]], M[:, kid[b]]
    s = np.minimum(wa, wb)
    if s.sum() < 1e-6:
        return fallback
    return (P * s[:, None]).sum(0) / s.sum()


def _centroid(P, M, kid, g):
    w = M[:, kid[g]]
    if w.sum() < 1e-6:
        return None
    return (P * w[:, None]).sum(0) / w.sum()


def landmarks(P, W):
    table = group_table()
    M, keys = vertex_group_weights(W, table)
    kid = dict((k, i) for i, k in enumerate(keys))
    lm = {}
    lm['hip_c'] = _centroid(P, M, kid, 'torso')
    lm['neck'] = _overlap_point(P, M, kid, 'torso', 'head')
    for s in SIDES:
        lm['clav' + s] = _overlap_point(P, M, kid, 'torso', 'clav' + s)
        lm['shoulder' + s] = _overlap_point(P, M, kid, 'clav' + s, 'uarm' + s)
        lm['elbow' + s] = _overlap_point(P, M, kid, 'uarm' + s, 'farm' + s)
        lm['wrist' + s] = _overlap_point(P, M, kid, 'farm' + s, 'hand' + s)
        lm['handc' + s] = _centroid(P, M, kid, 'hand' + s)
        lm['hip' + s] = _overlap_point(P, M, kid, 'torso', 'thigh' + s)
        lm['knee' + s] = _overlap_point(P, M, kid, 'thigh' + s, 'calf' + s)
        lm['ankle' + s] = _overlap_point(P, M, kid, 'calf' + s, 'foot' + s)
        lm['toe' + s] = _overlap_point(P, M, kid, 'foot' + s, 'toe' + s)
        lm['toec' + s] = _centroid(P, M, kid, 'toe' + s)
    return lm


def _rot_between(a, b):
    a = a / (np.linalg.norm(a) + 1e-12); b = b / (np.linalg.norm(b) + 1e-12)
    v = np.cross(a, b); c = float(a @ b); s = np.linalg.norm(v)
    if s < 1e-9:
        return np.eye(3)
    vx = np.array([[0, -v[2], v[1]], [v[2], 0, -v[0]], [-v[1], v[0], 0]])
    return np.eye(3) + vx + vx @ vx * ((1 - c) / (s * s))


def bone_transforms(lm_s, lm_d):
    """per group key -> (pivot_src, pivot_dst, R, scale).  Returns None entries for missing landmarks."""
    T = {}

    def seg(key, p0, p1):
        a0, a1, b0, b1 = lm_s.get(p0), lm_s.get(p1), lm_d.get(p0), lm_d.get(p1)
        if any(x is None for x in (a0, a1, b0, b1)):
            return
        ds, dd = a1 - a0, b1 - b0
        ls, ld = np.linalg.norm(ds), np.linalg.norm(dd)
        if ls < 1e-6 or ld < 1e-6:
            return
        T[key] = (a0, b0, _rot_between(ds, dd), ld / ls)
    # torso / head / clavicles stay where the height-fit put them (landmark conventions of the two skeletons differ
    # there); only the limb chains are re-posed to the donor's rest pose
    T['torso'] = (np.zeros(3), np.zeros(3), np.eye(3), 1.0)
    T['head'] = (np.zeros(3), np.zeros(3), np.eye(3), 1.0)
    for s in SIDES:
        seg('uarm' + s, 'shoulder' + s, 'elbow' + s)
        seg('farm' + s, 'elbow' + s, 'wrist' + s)
        seg('hand' + s, 'wrist' + s, 'handc' + s)
        seg('thigh' + s, 'hip' + s, 'knee' + s)
        seg('calf' + s, 'knee' + s, 'ankle' + s)
        seg('foot' + s, 'ankle' + s, 'toec' + s if lm_s.get('toec' + s) is not None else 'toe' + s)
        if 'toe' + s in lm_s and lm_s.get('toe' + s) is not None and lm_d.get('toe' + s) is not None:
            T['toe' + s] = (lm_s['toe' + s], lm_d['toe' + s], T.get('foot' + s, (0, 0, np.eye(3), 1.0))[2], 1.0)
    return T


def retarget(P, N, W, lm_s, lm_d):
    """Deform (P, N) with blended per-group similarity transforms. Returns (P2, N2)."""
    table = group_table()
    M, keys = vertex_group_weights(W, table)
    T = bone_transforms(lm_s, lm_d)
    out = np.zeros_like(P)
    outn = np.zeros_like(N)
    wsum = np.zeros(len(P))
    for gi, k in enumerate(keys):
        w = M[:, gi]
        if not w.any():
            continue
        if k in T:
            ps, pd, R, s = T[k]
        else:                                              # unknown group: follow the torso
            ps, pd, R, s = T.get('torso', (np.zeros(3), np.zeros(3), np.eye(3), 1.0))
        q = pd + s * (P - ps) @ R.T
        out += w[:, None] * q
        outn += w[:, None] * (N @ R.T)
        wsum += w
    wsum = np.maximum(wsum, 1e-9)[:, None]
    P2 = out / wsum
    N2 = outn / wsum
    N2 /= np.maximum(np.linalg.norm(N2, axis=1, keepdims=True), 1e-9)
    return P2, N2


def angle_report(lm):
    """arm / leg direction angles for logging (degrees below horizontal for arms, from vertical for legs)"""
    out = []
    for s in SIDES:
        try:
            a = lm['wrist' + s] - lm['shoulder' + s]
            out.append('%s arm %.0f deg below horizontal' % (s, np.degrees(np.arctan2(a[1], abs(a[0])))))
            l = lm['ankle' + s] - lm['hip' + s]
            out.append('%s leg %.0f deg from vertical' % (s, np.degrees(np.arctan2(abs(l[0]), abs(l[1])))))
        except Exception:
            pass
    return ', '.join(out)


# ======================================================================================================================
# Legs + fingers only  (default).  Rotation about the joint, nothing else: no scaling, no translation of the limb,
# arms / torso / head are NOT touched, so the 2K26 body keeps its shape.
# ======================================================================================================================
SEG_SUFFIX = ('', '1', '2')


def lf_group_table():
    """bone name (normalised) -> moving group key.  Everything that is not listed stays where it is."""
    t = {}
    for s in SIDES:
        for key, names in (('thigh', ['Bip %s Thigh' % s, '%s_Thigh_x' % s]), ('calf', ['Bip %s Calf' % s]),
                           ('foot', ['Bip %s Foot' % s]), ('toe', ['Bip %s Toe0' % s])):
            for n in names:
                t[_norm(n)] = key + s
        for f in range(5):
            for k, suf in enumerate(SEG_SUFFIX):
                t[_norm('Bip %s Finger%d%s' % (s, f, suf))] = 'fg%s%d%d' % (s, f, k)
    return t


def _group_centroid(P, W, table, key, min_w=0.5):
    """weighted centroid of the vertices that belong (weight share >= min_w) to the moving group `key`"""
    num, den, n = np.zeros(3), 0.0, 0
    for p, w in zip(P, W):
        g = 0.0
        for b, x in w.items():
            if table.get(_norm(b)) == key:
                g += x
        if g >= min_w:
            num += g * p
            den += g
            n += 1
    return (num / den, n) if den > 1e-9 else (None, 0)


def finger_chain(P, W, table, side, f):
    """Joint chain of one finger from the centroids of its 3 segments:  [B0, B1, B2, B3] (base .. tip estimate)."""
    cs = []
    for k in range(3):
        c, n = _group_centroid(P, W, table, 'fg%s%d%d' % (side, f, k))
        if c is None:
            return None
        cs.append(c)
    b1 = (cs[0] + cs[1]) / 2
    b2 = (cs[1] + cs[2]) / 2
    return [2 * cs[0] - b1, b1, b2, 2 * cs[2] - b2]


def hand_frame(chains, wrist):
    """Orthonormal frame of a hand: u along the hand (wrist -> knuckles), v across (pinky -> index), n palm normal.
    Built from finger base joints only, so it is the same construction on the 2K26 and on the donor mesh."""
    if wrist is None or any(chains.get(f) is None for f in (1, 4)):
        return None
    bases = [chains[f][0] for f in range(5) if chains.get(f) is not None and f != 0]
    u = np.mean(bases, axis=0) - wrist
    v = chains[1][0] - chains[4][0]
    if np.linalg.norm(u) < 1e-6 or np.linalg.norm(v) < 1e-6:
        return None
    u = u / np.linalg.norm(u)
    n = np.cross(u, v)
    if np.linalg.norm(n) < 1e-9:
        return None
    n = n / np.linalg.norm(n)
    v = np.cross(n, u)
    return np.stack([u, v, n], 1)                       # columns


class LegFingerPose(object):
    """Plan: per moving group (pivot_src, pivot_dst, R) with   p' = pivot_dst + R (p - pivot_src)   (FK chains)."""

    def __init__(self, Ps, Ws, Pd, Wd, legs=True, fingers=True, log=print):
        self.table = lf_group_table()
        self.T = {}
        self.log = log
        self.info = []
        if legs:
            self._legs(Ps, Ws, Pd, Wd)
        if fingers:
            self._fingers(Ps, Ws, Pd, Wd)

    # ---- legs -------------------------------------------------------------------------------------------------
    def _legs(self, Ps, Ws, Pd, Wd):
        ls, ld = landmarks(Ps, Ws), landmarks(Pd, Wd)
        for s in SIDES:
            need = ['hip' + s, 'knee' + s, 'ankle' + s]
            if any(ls.get(k) is None or ld.get(k) is None for k in need):
                self.info.append('%s leg: landmarks missing, left as is' % s)
                continue
            hip, knee, ankle = ls['hip' + s], ls['knee' + s], ls['ankle' + s]
            R_t = _rot_between(knee - hip, ld['knee' + s] - ld['hip' + s])
            knee2 = hip + R_t @ (knee - hip)
            R_c = _rot_between(R_t @ (ankle - knee), ld['ankle' + s] - ld['knee' + s]) @ R_t
            ankle2 = knee2 + R_c @ (ankle - knee)
            self.T['thigh' + s] = (hip, hip, R_t)
            self.T['calf' + s] = (knee, knee2, R_c)
            tip_s = ls.get('toec' + s) if ls.get('toec' + s) is not None else ls.get('toe' + s)
            tip_d = ld.get('toec' + s) if ld.get('toec' + s) is not None else ld.get('toe' + s)
            R_f = R_c
            if tip_s is not None and tip_d is not None:
                R_f = _rot_between(R_c @ (tip_s - ankle), tip_d - ld['ankle' + s]) @ R_c
            self.T['foot' + s] = (ankle, ankle2, R_f)
            self.T['toe' + s] = (ankle, ankle2, R_f)

            def dev(v):                                  # angle from vertical, degrees
                return np.degrees(np.arctan2(np.hypot(v[0], v[2]), abs(v[1])))
            self.info.append('%s leg: thigh %.0f -> %.0f deg from vertical (donor %.0f), calf %.0f -> %.0f (donor %.0f)' % (
                s, dev(knee - hip), dev(R_t @ (knee - hip)), dev(ld['knee' + s] - ld['hip' + s]),
                dev(ankle - knee), dev(R_c @ (ankle - knee)), dev(ld['ankle' + s] - ld['knee' + s])))

    # ---- fingers ----------------------------------------------------------------------------------------------
    def _fingers(self, Ps, Ws, Pd, Wd):
        ls, ld = landmarks(Ps, Ws), landmarks(Pd, Wd)
        for s in SIDES:
            cs = dict((f, finger_chain(Ps, Ws, self.table, s, f)) for f in range(5))
            cd = dict((f, finger_chain(Pd, Wd, self.table, s, f)) for f in range(5))
            Fs = hand_frame(cs, ls.get('wrist' + s))
            Fd = hand_frame(cd, ld.get('wrist' + s))
            if Fs is None or Fd is None:
                self.info.append('%s hand: finger chains / hand frame not measurable, fingers left as is' % s)
                continue
            errs_b, errs_a, nfin = [], [], 0
            for f in range(5):
                a, d = cs.get(f), cd.get(f)
                if a is None or d is None:
                    continue
                nfin += 1
                Rprev = np.eye(3)
                cur = [a[0].copy()]                       # transformed joints (pivot of the next segment)
                for k in range(3):
                    ds = a[k + 1] - a[k]
                    dd = d[k + 1] - d[k]
                    if np.linalg.norm(ds) < 1e-6 or np.linalg.norm(dd) < 1e-6:
                        R = Rprev
                    else:
                        target = Fs @ (Fd.T @ (dd / np.linalg.norm(dd)))       # donor direction in the hand frame
                        cur_dir = Rprev @ ds
                        R = _rot_between(cur_dir, target) @ Rprev
                        errs_b.append(_angle(Fs.T @ ds, Fd.T @ dd))
                        errs_a.append(_angle(Fs.T @ (R @ ds), Fd.T @ dd))
                    self.T['fg%s%d%d' % (s, f, k)] = (a[k], cur[k], R)
                    cur.append(cur[k] + R @ ds)
                    Rprev = R
            if errs_b:
                self.info.append('%s hand: %d fingers rotated to the donor rest pose, mean segment-direction error %.1f -> %.1f deg' % (
                    s, nfin, float(np.mean(errs_b)), float(np.mean(errs_a))))

    # ---- apply ------------------------------------------------------------------------------------------------
    def apply(self, P, N, W):
        """linear blend skinning of the group transforms with the vertex's own weights; weight on groups that do not
        move (torso, arms, head ...) keeps the vertex where it is."""
        P = np.asarray(P, float)
        N = np.asarray(N, float)
        dP = np.zeros_like(P)
        dN = np.zeros_like(N)
        keys = {}
        for gk in self.T:
            keys[gk] = np.zeros(len(P))
        tot = np.zeros(len(P))
        tab = self.table
        for i, w in enumerate(W):
            for b, x in w.items():
                tot[i] += x
                g = tab.get(_norm(b))
                if g in keys:
                    keys[g][i] += x
        tot = np.maximum(tot, 1e-9)
        for gk, wv in keys.items():
            if not wv.any():
                continue
            ps, pd, R = self.T[gk]
            f = (wv / tot)[:, None]
            dP += f * ((pd + (P - ps) @ R.T) - P)
            dN += f * (N @ R.T - N)
        N2 = N + dN
        N2 /= np.maximum(np.linalg.norm(N2, axis=1, keepdims=True), 1e-9)
        return P + dP, N2


def _angle(a, b):
    a = a / (np.linalg.norm(a) + 1e-12)
    b = b / (np.linalg.norm(b) + 1e-12)
    return float(np.degrees(np.arccos(np.clip(a @ b, -1, 1))))


# ======================================================================================================================
# Arm / hand LENGTH only  (no rotation, no change of the pose): every segment of the arm is stretched along its own axis
# to the length it has in the donor, so the arms and hands are as long as the donor's.
# ======================================================================================================================
def hand_length(P, W, side, wrist, table=None):
    """curl-independent hand length: wrist -> base of the middle finger + the three segments of that finger"""
    table = table or lf_group_table()
    for f in (2, 3, 1, 4):
        ch = finger_chain(P, W, table, side, f)
        if ch is not None and wrist is not None:
            return float(np.linalg.norm(ch[0] - wrist) + sum(np.linalg.norm(ch[k + 1] - ch[k]) for k in range(3)))
    return None


def knuckle_centre(chains):
    b = [chains[f][0] for f in (1, 2, 3, 4) if chains.get(f) is not None]
    return np.mean(b, axis=0) if b else None


class ArmLength(object):
    """Arm / hand LENGTH and knuckle position match to the donor.
      * upper arm / forearm: stretched along the bone axis (thickness unchanged), hand: uniform scale about the wrist;
        every segment hangs on the end of the previous one (FK), vertices follow with their own skin weights.
      * height=True: the hand (palm + knuckles + fingers) is turned about the wrist into the donor's hand orientation
        and the whole arm is lowered / raised about the shoulder in its vertical plane (a few degrees) until the knuckles
        are at the donor's height.  Elbow bend, arm direction in the horizontal plane and the torso stay as they are.
      * reach=True: the 2K26 shoulder joints sit a little further inside than the donor's, so with exactly the donor's
        segment lengths the hands would end up short of the donor's hands; the two arm segments are stretched by the same
        small factor (never more than MAX_REACH) until the knuckles are as far out as the donor's knuckles."""

    MAX_DROOP = 20.0                                  # degrees, safety limit for the vertical correction
    MAX_HAND = 40.0                                   # degrees, safety limit for the hand turn
    MAX_REACH = 1.08                                  # largest extra stretch of the arm segments for the reach match

    def __init__(self, Ps, Ws, Pd, Wd, lo=0.5, hi=2.0, height=True, reach=True, log=print):
        self.table = group_table()
        self.T = {}
        self.info = []
        ls, ld = landmarks(Ps, Ws), landmarks(Pd, Wd)
        lft = lf_group_table()
        for s in SIDES:
            need = ['shoulder' + s, 'elbow' + s, 'wrist' + s]
            if any(ls.get(k) is None or ld.get(k) is None for k in need):
                self.info.append('%s arm: landmarks missing, left as is' % s)
                continue
            S, E, Wr = ls['shoulder' + s], ls['elbow' + s], ls['wrist' + s]
            Sd, Ed, Wrd = ld['shoulder' + s], ld['elbow' + s], ld['wrist' + s]
            l1, l2 = float(np.linalg.norm(E - S)), float(np.linalg.norm(Wr - E))
            d1, d2 = float(np.linalg.norm(Ed - Sd)), float(np.linalg.norm(Wrd - Ed))
            if min(l1, l2, d1, d2) < 1e-6:
                self.info.append('%s arm: degenerate landmarks, left as is' % s)
                continue
            a1 = min(hi, max(lo, d1 / l1))
            a2 = min(hi, max(lo, d2 / l2))
            hs = hand_length(Ps, Ws, s, Wr, lft)
            hd = hand_length(Pd, Wd, s, Wrd, lft)
            a3 = min(hi, max(lo, hd / hs)) if (hs and hd) else 1.0
            u1, u2 = (E - S) / l1, (Wr - E) / l2
            Qh = np.eye(3) * a3                           # hand: scale (and, with height, the turn into the donor's frame)
            Ks = Kd = None
            txt = ''
            if height:
                cs = dict((f, finger_chain(Ps, Ws, lft, s, f)) for f in range(5))
                cd = dict((f, finger_chain(Pd, Wd, lft, s, f)) for f in range(5))
                Fs, Fd = hand_frame(cs, Wr), hand_frame(cd, Wrd)
                Ks, Kd = knuckle_centre(cs), knuckle_centre(cd)
                if Fs is None or Fd is None or Ks is None or Kd is None:
                    Ks = Kd = None
                    txt = ', hand height: finger chains not measurable, left as is'
                else:
                    Rfix = Fd @ Fs.T                      # source hand frame -> donor hand frame
                    turn = float(np.degrees(np.arccos(np.clip((np.trace(Rfix) - 1) / 2, -1, 1))))
                    if turn > self.MAX_HAND:
                        Ks = Kd = None
                        txt = ', hand height: hand differs by %.0f deg from the donor (> %.0f), left as is' % (turn, self.MAX_HAND)
                    else:
                        Qh = a3 * Rfix

            def solve(g):
                """arm stretched by g, whole arm moved about the shoulder so the knuckles get the donor's height"""
                E2 = S + g * a1 * (E - S)
                W2 = E2 + g * a2 * (Wr - E)
                Rd = np.eye(3)
                if Ks is not None:
                    off = Qh @ (Ks - Wr)                  # wrist -> knuckles after the hand turn
                    w = W2 - S
                    L = float(np.linalg.norm(w))
                    y_t = float(np.clip(Kd[1] - off[1] - S[1], -0.98 * L, 0.98 * L))
                    hz = np.array([w[0], 0.0, w[2]])
                    hz = hz / max(np.linalg.norm(hz), 1e-9)
                    Rd = _rot_between(w, hz * np.sqrt(max(L * L - y_t * y_t, 0.0)) + np.array([0.0, y_t, 0.0]))
                return E2, W2, Rd

            g = 1.0
            if Ks is not None and reach:
                for _ in range(6):                        # knuckle centre as far out as the donor's
                    E2, W2, Rd = solve(g)
                    K3 = S + Rd @ (W2 - S) + Qh @ (Ks - Wr)
                    have, want = abs(K3[0] - S[0]), abs(Kd[0] - S[0])
                    if have < 1e-6:
                        break
                    g = min(self.MAX_REACH, max(1.0, g * want / have))
            E2, W2, Rd = solve(g)
            if Ks is not None:
                droop = float(np.degrees(np.arccos(np.clip((np.trace(Rd) - 1) / 2, -1, 1))))
                turn = float(np.degrees(np.arccos(np.clip((np.trace(Qh / a3) - 1) / 2, -1, 1))))
                K3 = S + Rd @ (W2 - S) + Qh @ (Ks - Wr)
                if droop > self.MAX_DROOP:
                    Rd, Qh, g = np.eye(3), np.eye(3) * a3, 1.0
                    E2, W2, _ = solve(1.0)
                    Ks = None
                    txt = ', hand height: would need %.0f deg of arm correction (> %.0f), left as is' % (droop, self.MAX_DROOP)
                else:
                    txt = (', hand turned %.1f deg into the donor orientation, arm moved %.1f deg in its vertical plane, knuckle '
                           'height off by %.2f -> %.2f, knuckle reach off by %.2f -> %.2f units' % (
                               turn, droop, Ks[1] - Kd[1], K3[1] - Kd[1], abs(Ks[0]) - abs(Kd[0]),
                               abs(K3[0]) - abs(Kd[0])))
            E3 = S + Rd @ (E2 - S)
            W3 = S + Rd @ (W2 - S)
            self.T['uarm' + s] = (S, S, Rd @ (np.eye(3) + (g * a1 - 1.0) * np.outer(u1, u1)))
            self.T['farm' + s] = (E, E3, Rd @ (np.eye(3) + (g * a2 - 1.0) * np.outer(u2, u2)))
            self.T['hand' + s] = (Wr, W3, Qh)
            self.info.append('%s arm: upper arm %.2f -> %.2f (donor %.2f), forearm %.2f -> %.2f (donor %.2f), hand %s -> %s (donor %s)%s%s' % (
                s, l1, g * a1 * l1, d1, l2, g * a2 * l2, d2,
                '%.2f' % hs if hs else '?', '%.2f' % (a3 * hs) if hs else '?', '%.2f' % hd if hd else '?',
                (' [arm stretched x%.3f to reach the donor hand position]' % g) if g > 1.0005 else '', txt))

    def apply(self, P, N, W):
        P = np.asarray(P, float)
        N = np.asarray(N, float)
        dP = np.zeros_like(P)
        dN = np.zeros_like(N)
        keys = dict((gk, np.zeros(len(P))) for gk in self.T)
        tot = np.zeros(len(P))
        for i, w in enumerate(W):
            for b, x in w.items():
                tot[i] += x
                g = self.table.get(_norm(b))
                if g in keys:
                    keys[g][i] += x
        tot = np.maximum(tot, 1e-9)
        for gk, wv in keys.items():
            if not wv.any():
                continue
            ps, pd, M = self.T[gk]
            f = (wv / tot)[:, None]
            dP += f * ((pd + (P - ps) @ M.T) - P)
            U, _, Vt = np.linalg.svd(M)                   # normals: the rotation part of the matrix
            dN += f * (N @ (U @ Vt).T - N)
        N2 = N + dN
        N2 /= np.maximum(np.linalg.norm(N2, axis=1, keepdims=True), 1e-9)
        return P + dP, N2


# ======================================================================================================================
# Knuckles and finger LENGTHS from the donor.
# After the legs / fingers / arms steps the finger directions already follow the donor's rest pose and the hand is as long
# as the donor's hand, but the knuckles (base joints) and the individual segments still have the 2K26's own proportions.
# Here every finger joint is put where the donor's joint is (in the hand's own frame): the finger segments are stretched
# along their axis to the donor's lengths (thickness unchanged), every segment hangs on the end of the previous one, the
# base joint (knuckle) moves to the donor's knuckle position, and the palm is stretched along the hand axis to the donor's
# palm length, so the skin between the palm and the finger bases follows.  Vertices follow with their own skin weights.
# ======================================================================================================================
def finger_extent(P, W, table, side, f, F, w, chain):
    """Base point and tip point of finger f in the hand's frame (columns of F: along the hand, across, palm normal; origin at the
    wrist w): the two ends of the vertices that belong to the finger (skin weight share >= 0.5 on its three segments).  Measured
    from the vertex cloud itself, not from segment centroids, so it hardly depends on how the mesh was decimated."""
    keys = set('fg%s%d%d' % (side, f, k) for k in range(3))
    wt = np.zeros(len(P))
    for i, d in enumerate(W):
        for b, x in d.items():
            if table.get(_norm(b)) in keys:
                wt[i] += x
    sel = wt >= 0.5
    if int(sel.sum()) < 6:
        return None
    Q = (np.asarray(P, float)[sel] - w) @ F
    ax = F.T @ (chain[3] - chain[0])
    if np.linalg.norm(ax) < 1e-9:
        return None
    ax = ax / np.linalg.norm(ax)
    t = Q @ ax
    lo, hi = float(np.percentile(t, 4)), float(np.percentile(t, 96))
    if hi - lo < 1e-6:
        return None
    base = Q[t <= lo + 0.12 * (hi - lo)].mean(0)
    tip = Q[t >= hi - 0.12 * (hi - lo)].mean(0)
    return base, tip


class FingerFit(object):
    """Per finger: the knuckle (base of the finger) goes to the donor's knuckle position in the hand's frame, the finger is
    stretched along its own axis (all three segments by the same factor, directions as they are) to the donor's finger length,
    and the palm is stretched along the hand axis to the donor's palm length."""
    LO, HI = 0.7, 1.4                                  # limits of the stretch of one finger
    PALM_LO, PALM_HI = 0.8, 1.25                       # limits of the stretch of the palm

    def __init__(self, Ps, Ws, Pd, Wd, log=print, keep_palm=False):
        """keep_palm: the wrist -> knuckle distance (palm length) stays the mesh's own: the palm is not stretched and the knuckles keep
        their place along the hand axis (their spread and height across the hand and the finger lengths still follow the donor)"""
        self.table = lf_group_table()
        for s in SIDES:
            self.table[_norm('Bip %s Hand' % s)] = 'palm' + s
        self.T = {}
        self.info = []
        ls, ld = landmarks(Ps, Ws), landmarks(Pd, Wd)
        for s in SIDES:
            w_s, w_d = ls.get('wrist' + s), ld.get('wrist' + s)
            cs = dict((f, finger_chain(Ps, Ws, self.table, s, f)) for f in range(5))
            cd = dict((f, finger_chain(Pd, Wd, self.table, s, f)) for f in range(5))
            Fs, Fd = hand_frame(cs, w_s), hand_frame(cd, w_d)
            if Fs is None or Fd is None:
                self.info.append('%s hand: finger chains / hand frame not measurable, fingers left as they are' % s)
                continue
            Rm = Fs @ Fd.T                              # donor-frame vector -> this mesh's vector
            ex_s, ex_d = {}, {}
            for f in range(5):
                if cs.get(f) is None or cd.get(f) is None:
                    continue
                es = finger_extent(Ps, Ws, self.table, s, f, Fs, w_s, cs[f])
                ed = finger_extent(Pd, Wd, self.table, s, f, Fd, w_d, cd[f])
                if es is not None and ed is not None:
                    ex_s[f], ex_d[f] = es, ed
            fin = [f for f in (1, 2, 3, 4) if f in ex_s]
            if not fin:
                self.info.append('%s hand: finger extents not measurable, fingers left as they are' % s)
                continue
            us = Fs[:, 0]
            ps_ = float(np.mean([ex_s[f][0][0] for f in fin]))
            pd_ = float(np.mean([ex_d[f][0][0] for f in fin]))
            sp = min(self.PALM_HI, max(self.PALM_LO, pd_ / ps_)) if ps_ > 1e-6 else 1.0
            if keep_palm:
                sp = 1.0
            self.T['palm' + s] = (w_s, w_s, np.eye(3) + (sp - 1.0) * np.outer(us, us))
            moved, ls_all, ld_all, sg_all = [], [], [], []
            for f in sorted(ex_s):
                bs_, ts_ = ex_s[f]
                bd_, td_ = ex_d[f]
                len_s, len_d = float(np.linalg.norm(ts_ - bs_)), float(np.linalg.norm(td_ - bd_))
                sg = min(self.HI, max(self.LO, len_d / len_s)) if len_s > 1e-6 else 1.0
                a, d = cs[f], cd[f]
                delta = Fs @ (bd_ - bs_)                # source knuckle -> the donor's knuckle position
                if keep_palm:
                    delta = delta - float(delta @ us) * us          # ... but not along the hand axis (wrist -> knuckle stays as it is)
                cur = a[0] + delta
                moved.append(float(np.linalg.norm(delta)))
                ls_all.append(len_s)
                ld_all.append(len_d)
                sg_all.append(sg)
                for k in range(3):
                    ds = a[k + 1] - a[k]
                    dd = Rm @ (d[k + 1] - d[k])
                    l1 = float(np.linalg.norm(ds))
                    if l1 < 1e-6 or np.linalg.norm(dd) < 1e-6:
                        M = np.eye(3)
                    else:
                        u = ds / l1
                        M = _rot_between(ds, dd) @ (np.eye(3) + (sg - 1.0) * np.outer(u, u))
                    self.T['fg%s%d%d' % (s, f, k)] = (a[k], cur, M)
                    cur = cur + M @ ds
            self.info.append('%s hand: palm length x%.3f%s, knuckles moved %.2f units on average (largest %.2f), finger length %.2f -> %.2f '
                             '(donor %.2f), stretch x%.2f on average' % (
                                 s, sp, " (kept)" if keep_palm else "", float(np.mean(moved)), float(np.max(moved)), float(np.mean(ls_all)),
                                 float(np.mean(ls_all)) * float(np.mean(sg_all)), float(np.mean(ld_all)), float(np.mean(sg_all))))

    def apply(self, P, N, W):
        P = np.asarray(P, float)
        N = np.asarray(N, float)
        dP = np.zeros_like(P)
        dN = np.zeros_like(N)
        keys = dict((gk, np.zeros(len(P))) for gk in self.T)
        tot = np.zeros(len(P))
        for i, w in enumerate(W):
            for b, x in w.items():
                tot[i] += x
                g = self.table.get(_norm(b))
                if g in keys:
                    keys[g][i] += x
        tot = np.maximum(tot, 1e-9)
        for gk, wv in keys.items():
            if not wv.any():
                continue
            ps, pd, M = self.T[gk]
            f = (wv / tot)[:, None]
            dP += f * ((pd + (P - ps) @ M.T) - P)
            U, _, Vt = np.linalg.svd(M)                   # normals: the rotation part of the matrix
            dN += f * (N @ (U @ Vt).T - N)
        N2 = N + dN
        N2 /= np.maximum(np.linalg.norm(N2, axis=1, keepdims=True), 1e-9)
        return P + dP, N2
