# -*- coding: utf-8 -*-
"""Python side of the browser tool (wwe2k_to_wii_web.html, runs inside Pyodide in a Web Worker).

The page puts the picked files into  <BASE>/in  (char.zip, donor.pac, hair.pac), calls detect() / convert() and reads the result
files back from  <BASE>/out.  Nothing here is browser specific, so it also runs under CPython (WEB_BASE=/some/dir) for testing.
"""
import json
import os
import shutil
import sys
import types
import zipfile

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import wwe2k_to_wii as P      # noqa: E402

BASE = os.environ.get('WEB_BASE', '')
IN_DIR = BASE + '/in'
WORK = BASE + '/work'
OUT_DIR = BASE + '/out'

_log = print


def set_logger(fn):
    """fn: a JS function (or any callable) taking one string"""
    global _log
    _log = lambda s: fn(str(s))           # noqa: E731


def _attire_dirs(names):
    """directories (zip-relative, no trailing slash) that hold an attire mcd (every .mcd that is not baseModel.mcd)"""
    out = []
    for n in names:
        low = n.lower()
        if low.endswith('.mcd') and 'basemodel' not in os.path.basename(low):
            d = os.path.dirname(n).replace('\\', '/')
            if d not in out:
                out.append(d)
    return out


def _wipe(path):
    shutil.rmtree(path, ignore_errors=True)
    os.makedirs(path, exist_ok=True)


def detect(char_zip=None):
    """Attires, meshes and materials of the character zip as a JSON string.  Only the .mcd / .mtls files are unpacked
    (the textures only need to exist), so this stays small and quick on a phone."""
    char_zip = char_zip or (IN_DIR + '/char.zip')
    d = WORK + '/detect'
    _wipe(d)
    with zipfile.ZipFile(char_zip) as z:
        adirs = _attire_dirs(z.namelist())
        for info in z.infolist():
            if info.is_dir():
                continue
            p = os.path.join(d, info.filename)
            os.makedirs(os.path.dirname(p), exist_ok=True)
            if info.filename.lower().endswith(('.mcd', '.mtls')):
                with z.open(info) as s, open(p, 'wb') as o:
                    shutil.copyfileobj(s, o)
            else:
                open(p, 'wb').close()
    try:
        res = P.scan_character(d, log=lambda s: None)
    finally:
        shutil.rmtree(d, ignore_errors=True)
    out = dict(attires=[], base=res['base'], parts=res['parts'])
    for lab, short, mcd in res['attires']:
        rel = os.path.relpath(os.path.dirname(mcd), d).replace('\\', '/')
        out['attires'].append(dict(label=lab, short=short, dir=rel))
    return json.dumps(out)


def convert(opts_json):
    """opts: {name: output stem, attire_dir: folder of the chosen attire in the zip, hair_donor: bool, args: {cli option: value}}.
    Unpacks BaseModel + the chosen attire only (so no other attire's textures are held in memory), runs the converter and returns
    the list of result files as JSON ([{name, size}], all in OUT_DIR)."""
    o = json.loads(opts_json)
    char_zip = IN_DIR + '/char.zip'
    donor = IN_DIR + '/donor.pac'
    d = WORK + '/char'
    _wipe(d)
    _wipe(OUT_DIR)
    keep = (o.get('attire_dir') or '').replace('\\', '/')
    with zipfile.ZipFile(char_zip) as z:
        adirs = _attire_dirs(z.namelist())
        other = [x for x in adirs if x != keep]
        for info in z.infolist():
            if info.is_dir():
                continue
            n = info.filename.replace('\\', '/')
            if any(x and (n == x or n.startswith(x + '/')) for x in other):
                continue
            p = os.path.join(d, info.filename)
            os.makedirs(os.path.dirname(p), exist_ok=True)
            with z.open(info) as s, open(p, 'wb') as out:
                shutil.copyfileobj(s, out)
    a = P.with_defaults(types.SimpleNamespace())
    a.character, a.donor = d, donor
    a.attire = None
    stem = o.get('name') or 'result'
    a.out = OUT_DIR + '/' + stem + '.pac'
    for k, v in (o.get('args') or {}).items():
        setattr(a, k, v)
    if o.get('hair_donor') and os.path.exists(IN_DIR + '/hair.pac'):
        a.hair_donor = IN_DIR + '/hair.pac'
    if a.exclude in ([], ''):
        a.exclude = None
    _log("Converting with attire folder '%s' ..." % keep)
    try:
        P.build(a, log=lambda s: _log(s) if 'decimating:' not in s else None)
    finally:
        shutil.rmtree(d, ignore_errors=True)
    files = []
    for f in sorted(os.listdir(OUT_DIR)):
        files.append(dict(name=f, size=os.path.getsize(os.path.join(OUT_DIR, f))))
    return json.dumps(files)
