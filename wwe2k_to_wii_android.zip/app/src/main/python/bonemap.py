# -*- coding: utf-8 -*-
"""WWE 2K (J_* / H_*) bone names -> WWE 13 Wii (3ds Max biped style) bone names."""
import re


def map_bone(name):
    """Return the Wii bone name for a 2K bone name (always returns something usable for body bones)."""
    return _map(name)[0]


def is_fallback(name):
    """True when the 2K bone has no match at all on the Wii skeleton and was sent to the root ('Bip') as a last resort
    (J_Hips and the gut jiggle bones map to the root on purpose and are not fallbacks)."""
    return _map(name)[1]


def _map(name):
    n = name
    side = 'L' if re.search(r'(_L$|_L_|_L\d|^.*_L$)', n) else ('R' if re.search(r'(_R$|_R_|_R\d)', n) else None)
    s = side
    low = n.lower()
    # ---- hair: head hair is skinned to hair root / chain bones (J_Hair, J_Hair_b, Hair_b00_01, Hair_c04 ...) -> the Wii has only the head
    if low.startswith(('j_hair', 'hair', 'h_hair')) or 'ponytail' in low:
        return 'Bip Head', False
    # ---- face -----------------------------------------------------------------
    if low in ('j_eye_l',):
        return 'l_eye', False
    if low in ('j_eye_r',):
        return 'r_eye', False
    if low in ('j_jaw', 'j_lowerteeth') or low.startswith('j_tongue'):
        return 'd_kuchi', False
    if low == 'j_upperteeth':
        return 'u_kuchi', False
    if low == 'j_head':
        return 'Bip Head', False
    if low in ('j_neck', 'h_neck_tw') or low.startswith('h_neck') or low.startswith('h_trap') or low.startswith('j_trap'):
        return 'Bip Neck', False
    # ---- torso ----------------------------------------------------------------
    if low in ('j_hips',) or low.startswith('h_gut_jig_c'):
        return 'Bip', False
    if low.startswith('h_gut') or low.startswith('j_gut') or low == 'j_spine1':
        return 'Bip Spine', False
    if low in ('j_spine2', 'j_chest') or re.match(r'[hj]_(pec|lat|collar)', low):
        return 'Bip Spine1', False
    # ---- arms -----------------------------------------------------------------
    if s:
        S = s
        if low.startswith('j_clavicle'):
            return 'Bip %s Clavicle' % S, False
        if low.startswith('j_shoulder') or re.match(r'[hj]_(delt|bicep)', low):
            return 'Bip %s UpperArm' % S, False
        if low.startswith('j_elbow') or re.match(r'h_(elbow|ebw)', low):
            return 'Bip %s Forearm' % S, False
        if low.startswith('j_wrist'):
            return 'Bip %s Hand' % S, False
        m = re.match(r'j_(thumb|index|middle|ring|pinky)f(\d)_', low)
        if m:
            fi = {'thumb': 0, 'index': 1, 'middle': 2, 'ring': 3, 'pinky': 4}[m.group(1)]
            seg = int(m.group(2))
            if m.group(1) == 'thumb':
                suffix = ['', '', '1', '2'][seg] if seg < 4 else '2'
                # ThumbF1..F3 -> Finger0, Finger01, Finger02
                suffix = {1: '', 2: '1', 3: '2'}.get(seg, '2')
                return 'Bip %s Finger0%s' % (S, suffix), False
            if seg == 0:
                return 'Bip %s Hand' % S, False
            return 'Bip %s Finger%d%s' % (S, fi, {1: '', 2: '1', 3: '2'}.get(seg, '2')), False
        # ---- legs ---------------------------------------------------------------
        if low.startswith('j_leg') or re.match(r'h_(hip|quad|leg_vol|knee_upper)', low) or low.startswith('j_quad') \
                or low.startswith('j_knee_up'):
            return 'Bip %s Thigh' % S, False
        if low.startswith('j_knee') or re.match(r'h_(knee_lower|kn_)', low):
            return 'Bip %s Calf' % S, False
        if low.startswith('j_foot') or low.startswith('h_foot'):
            return 'Bip %s Foot' % S, False
        if low.startswith('j_toe') or low.startswith('h_toe'):
            return 'Bip %s Toe0' % S, False
    if low.startswith('h_leg_vol'):
        return 'Bip Pelvis', False
    return 'Bip', True
