# -*- coding: utf-8 -*-
"""PAC helpers for the WWE (Wii) character archives: EPK8 > PACH > (BPE-wrapped) entries.

Layout (verified on ch102.pac):
  EPK8 : 16384-byte header table, then file data.  Directory row at 0x800 ('EMD ' ...), file row
         [name 8][offset u32 (2048 units)][size u32 (256 units)] at 0x80C.
  PACH : 'PACH' u32 count, count x [fileno u32][addr u32][size u32], data (addr relative to the end of the table,
         4-byte aligned).
  BPE  : 'BPE ' u32 flags u32 packedLen u32 rawLen, then Byte-Pair-Encoding blocks.
"""
import struct
from collections import Counter


# ------------------------------------------------------------------ BPE
def bpe_decompress(data):
    pos, n, out = 0, len(data), bytearray()
    count = data[pos]
    pos += 1
    while True:
        left, right = list(range(256)), [0] * 256
        c = 0
        while True:
            if count > 127:
                c += count - 127
                count = 0
            if c >= 256:
                break
            i = 0
            while i <= count and c < 256:
                left[c] = data[pos]; pos += 1
                if c != left[c]:
                    right[c] = data[pos]; pos += 1
                i += 1; c += 1
            if c >= 256:
                break
            count = data[pos]; pos += 1
        size = data[pos] + 256 * data[pos + 1]
        pos += 2
        stack = []
        while True:
            if stack:
                ch = stack.pop()
            else:
                if size == 0:
                    break
                size -= 1
                ch = data[pos]; pos += 1
            if ch == left[ch]:
                out.append(ch)
            else:
                stack.append(right[ch]); stack.append(left[ch])
        if pos >= n:
            break
        count = data[pos]; pos += 1
    return bytes(out)


def _bpe_block(block, used, threshold):
    arr = list(block)
    left = list(range(256)); right = [0] * 256
    code = 256
    while True:
        chosen = -1
        c = code - 1
        while c >= 0:
            if left[c] == c and not used[c]:
                chosen = c; break
            c -= 1
        if chosen < 0:
            break
        code = chosen
        if len(arr) < 2:
            break
        cnt = Counter(zip(arr, arr[1:]))
        best, bc = None, 2
        for k, v in cnt.items():
            if v > bc:
                bc, best = v, k
        if best is None or bc < threshold:
            break
        l, r = best
        new, i, n = [], 0, len(arr)
        while i < n:
            if i < n - 1 and arr[i] == l and arr[i + 1] == r:
                new.append(code); i += 2
            else:
                new.append(arr[i]); i += 1
        arr = new
        left[code], right[code] = l, r
    return left, right, arr


def _bpe_write(left, right, data):
    out = bytearray()
    c = 0
    while c < 256:
        if left[c] == c:
            ln = 1; c += 1
            while ln < 127 and c < 256 and left[c] == c:
                ln += 1; c += 1
            out.append(ln + 127)
            ln = 0
            if c == 256:
                break
        else:
            ln = 0; c += 1
            while (ln < 127 and c < 256 and left[c] != c) or (ln < 125 and c < 254 and left[c + 1] != c + 1):
                ln += 1; c += 1
            out.append(ln)
            c -= (ln + 1)
        for _ in range(ln + 1):
            out.append(left[c])
            if left[c] != c:
                out.append(right[c])
            c += 1
    size = len(data)
    out.append(size % 256); out.append(size // 256)
    out.extend(data)
    return out


def bpe_compress(raw, block=5000, maxchars=200, threshold=3):
    out = bytearray()
    pos, n = 0, len(raw)
    while pos < n:
        blk, used, nu = bytearray(), [0] * 256, 0
        while len(blk) < block and nu < maxchars and pos < n:
            c = raw[pos]; pos += 1
            blk.append(c)
            if not used[c]:
                used[c] = 1; nu += 1
        l, r, d = _bpe_block(blk, used, threshold)
        out += _bpe_write(l, r, d)
    return bytes(out)


def bpe_wrap(raw, field2=256):
    comp = bpe_compress(raw)
    return b'BPE ' + struct.pack('<III', field2, len(comp), len(raw)) + comp


def bpe_unwrap(entry):
    if entry[:4] == b'BPE ':
        f2, clen, dlen = struct.unpack_from('<III', entry, 4)
        raw = bpe_decompress(entry[16:16 + clen])
        if len(raw) != dlen:
            raise ValueError('BPE size mismatch (%d != %d)' % (len(raw), dlen))
        return raw, f2
    return entry, None


# ------------------------------------------------------------------ PACH
class Pach(object):
    def __init__(self, data):
        if data[:4] != b'PACH':
            raise ValueError('not a PACH container')
        self.head = struct.unpack_from('<I', data, 8)[0] if False else None
        n = struct.unpack_from('<I', data, 4)[0]
        self.entries = []                       # [fileno, raw_stored_bytes]
        end = 8 + 12 * n
        for i in range(n):
            fn, ad, sz = struct.unpack_from('<III', data, 8 + 12 * i)
            self.entries.append([fn, data[end + ad:end + ad + sz]])

    def get(self, fileno):
        for e in self.entries:
            if e[0] == fileno:
                return e[1]
        raise KeyError(fileno)

    def set(self, fileno, blob):
        for e in self.entries:
            if e[0] == fileno:
                e[1] = blob
                return
        raise KeyError(fileno)

    def add(self, fileno, blob):
        """replace or insert (kept sorted by file number)"""
        for e in self.entries:
            if e[0] == fileno:
                e[1] = blob
                return
        self.entries.append([fileno, blob])
        self.entries.sort(key=lambda e: e[0])

    def has(self, fileno):
        return any(e[0] == fileno for e in self.entries)

    def build(self):
        n = len(self.entries)
        table, body, addr = bytearray(), bytearray(), 0
        for fn, blob in self.entries:
            table += struct.pack('<III', fn, addr, len(blob))
            body += blob
            pad = (-len(blob)) % 4
            body += b'\0' * pad
            addr += len(blob) + pad
        return b'PACH' + struct.pack('<I', n) + bytes(table) + bytes(body)


# ------------------------------------------------------------------ EPK8 (single file archive)
class Epk8(object):
    TABLE = 16384
    SIZE_OFF = 0x818          # u32, units of 256 bytes
    NAME_OFF = 0x80C

    def __init__(self, data):
        if data[:4] != b'EPK8':
            raise ValueError('not an EPK8 container')
        self.table = bytearray(data[:self.TABLE])
        off = struct.unpack_from('<I', self.table, 0x814)[0]
        size = struct.unpack_from('<I', self.table, self.SIZE_OFF)[0] * 256
        if off != 0:
            raise ValueError('unexpected EPK8 layout (offset %d)' % off)
        self.inner = data[self.TABLE:self.TABLE + size]
        self.tail = data[self.TABLE + size:] or b'\0' * 2048
        self.name = bytes(self.table[self.NAME_OFF:self.NAME_OFF + 8]).decode('latin1')

    def build(self, inner):
        inner = inner + b'\0' * ((-len(inner)) % 2048)        # data block is padded to 2048
        tbl = bytearray(self.table)
        struct.pack_into('<I', tbl, self.SIZE_OFF, len(inner) // 256)
        return bytes(tbl) + inner + self.tail                   # the original ends with one extra padding block
