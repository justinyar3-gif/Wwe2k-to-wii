#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
WWE 13 (Wii) DUMY Port Tool
===========================
Port a custom OBJ / COLLADA (.dae) model into an existing .dumy ("donor") and patch everything
that depends on it:

  * DUMY / YOBJ container header (payload size)
  * root header + model-info block (vertex / skin-group / face-block / UV counts, pointers)
  * vertex block   (8.8 fixed point position; normal triple stored as (nz,nx,ny)*16)
  * UV block       (8.8 fixed point, stored x4, V flipped)
  * bone weights   (skin-group table, per-vertex weight records, batch flags)
  * face blocks    (triangle strips) + face-block table
  * texture-name slots
  * POF0 pointer-offset table (rebuilt from scratch)

Usage
  python dumy_port_tool.py                       -> GUI
  python dumy_port_tool.py --selftest DONOR.dumy -> checks against the donor
  python dumy_port_tool.py --port DONOR.dumy MODEL.obj OUT.dumy [--weights transfer|rigid|single]
  (add --no-face-anim to --port to fold face-bone weights into the head bone; --face-keywords LIST to tune it)
  (mesh tear is on by default: vertices at one position are never merged when their skin weights differ, so e.g. a
   closed mouth keeps separate upper/lower-lip vertices and can open; --no-tear switches it off)
  (no triangle / vertex limit is applied by default; --max-verts N sets an optional cap for the 'auto' normal-merging.
   The only wall left is the format itself: 255 skin groups x 128-vertex batches = 32,640 vertices at most)
  python dumy_port_tool.py --verify FILE.dumy
  python dumy_port_tool.py --export-donor DONOR.dumy ref.obj
  python dumy_port_tool.py --export-dae FILE.dumy OUT.dae      (whole model: mesh, UV, colours, skin weights, bones)
  python dumy_port_tool.py --port DONOR.dumy MODEL.dae OUT.dumy (weights/colours/texture names come from the .dae)
Only the Python standard library (tkinter for the GUI) is needed.

Format notes (reverse-engineered from a WWE 13 .dumy; parse -> rebuild of the
donor is byte-identical, see --selftest):

  file   : 'DUMY'... 0x18:'YOBJ' 0x1C:u32 size | payload (base 0x20) | 'POF0'
  POF0   : u32 len, then delta stream. byte>>6: 1=6bit, 2=14bit, 3=30bit delta,
           each delta is in 4-byte units from the previous pointer location.
  skin   : table of 20-byte groups  [bone u16][b1 u16][b2 u16][nInfl u16]
           [count u32][chunkPtr u32][flags u32].  Vertices are stored in the
           order of the groups, in batches of exactly 128 vertices (last batch
           shorter, vertex array padded with dummy vertices to a multiple of 32).
           First group of a batch: flags = (0x8, or 0x2 if last)<<28 |
           groupsInBatch<<16 | weightedVerts<<8.
  weights: (decoded) nInfl 1: vertex is 100% on `bone`, no record.
           nInfl 2/3: one u32 record per vertex, hi = rec>>16 (0..4096),
           lo = rec&0xFFFF (0..4095), scale 4096 = 1.0.  The record is a
           SEQUENTIAL LERP of the three bone matrices:
               t = lerp(M[bone], M[b1], hi/4096)      # 2 influences: stop here
               M = lerp(t,      M[b2], lo/4096)
           i.e.  w[b2] = lo/4096
                 w[b1] = (1 - w[b2]) * hi/4096
                 w[bone] = (1 - w[b2]) * (1 - hi/4096)
           Any 3 weights summing to 1 are exactly encodable in any role order.
           hi == 4096 means "bone" has 0 weight; rec == 0 means 100% `bone`.
  faces  : table of 8-byte entries [idx<<8|n u16][stripCount u16][ptr u32];
           each strip = u32 n, then n corners [vertex u16][colourIdx u16][uv u16].
  names  : 16-byte slots: 'name\0ext\0' (12 bytes) + 4 bytes of unknown data (kept).

Limitations: only structure verified, not in-game.  The weight format was decoded by
statistical/anatomical analysis of one sample (valid for all 2965 records, round-trips
exactly, spatially coherent), not from engine code.  Needs a donor whose segments
are in the same order as the supplied sample (checked; unsupported donors are
rejected with a message).  Bone count / skeleton / materials of the donor are kept.
"""
import os
import sys
import math
import struct
import re
import urllib.parse
import datetime
import xml.etree.ElementTree as ET
from collections import Counter, defaultdict, OrderedDict

BASE = 0x20            # payload start inside the file
BATCH_MAX = 128        # max vertices per skin batch / group
GROUP_MAX = 255        # group count is stored as one byte
STRIP_MAX = 250        # max corners per emitted strip
# Every skin batch (<= 128 vertices) needs at least one of the 255 skin groups, so the format cannot hold more than
# this many vertices no matter how the weights are set up (in practice fewer: every distinct bone combination in a
# batch costs one more group).  This is the only hard size wall that is left; everything else is a budget.
MAX_FORMAT_VERTS = GROUP_MAX * BATCH_MAX

# model-info field offsets (relative to the model-info pointer, normally 0x40)
MI_VCOUNT, MI_NGROUPS, MI_NBLOCKS, MI_NCOLORS = 0x00, 0x06, 0x07, 0x08
MI_VPTR, MI_SKINPTR, MI_FTABPTR = 0x0C, 0x14, 0x18
MI_VSIZE32, MI_WSIZE32, MI_COLPTR, MI_UVPTR, MI_UVCOUNT = 0x1C, 0x1E, 0x20, 0x24, 0x2A
# u16@+0x1C = vertex array size / 32 ; u16@+0x1E = weight-record area size / 32  (verified on two files)
MI_NPAL2 = 0x28                   # u16 palette entry count (the u8 at +0x08 is a different, unresolved constant)
MI_BBOX = 0x30                    # 4 x float32: (minX+maxX, minY+maxY, minZ+maxZ, |max-min|)


def al(n, a=16):
    return (n + a - 1) // a * a


class DumyError(Exception):
    pass


# --------------------------------------------------------------------------
# POF0
# --------------------------------------------------------------------------
def pof0_decode(buf, off):
    if buf[off:off + 4] != b'POF0':
        raise DumyError("POF0 chunk not found at 0x%X" % off)
    ln = struct.unpack_from('>I', buf, off + 4)[0]
    data = buf[off + 8:off + 8 + ln]
    pos, i, out = 0, 0, []
    while i < len(data):
        b = data[i]
        t = b >> 6
        if t == 0:
            break
        if t == 1:
            v = b & 0x3F
            i += 1
        elif t == 2:
            v = ((b & 0x3F) << 8) | data[i + 1]
            i += 2
        else:
            v = struct.unpack_from('>I', data, i)[0] & 0x3FFFFFFF
            i += 4
        pos += v * 4
        out.append(pos)
    return out, ln


def pof0_encode(positions):
    out = bytearray()
    prev = 0
    for p in sorted(set(positions)):
        if p % 4:
            raise DumyError("unaligned pointer location 0x%X" % p)
        d = (p - prev) // 4
        prev = p
        if d < 0x40:
            out.append(0x40 | d)
        elif d < 0x4000:
            out += struct.pack('>H', 0x8000 | d)
        else:
            out += struct.pack('>I', 0xC0000000 | d)
    while len(out) % 4:
        out.append(0)
    return b'POF0' + struct.pack('>I', len(out)) + bytes(out)


# --------------------------------------------------------------------------
# donor model
# --------------------------------------------------------------------------
class Group(object):
    __slots__ = ('bone', 'b1', 'b2', 'C', 'D', 'ptr', 'F')

    def key(self):
        return (self.bone, self.b1, self.b2, self.C)


class Dumy(object):
    """Parsed .dumy file."""

    def __init__(self, raw):
        raw = bytes(raw)
        if raw[:4] != b'DUMY' or raw[0x18:0x1C] != b'YOBJ':
            raise DumyError("Not a DUMY/YOBJ file")
        self.raw = raw
        self.yobj_size = struct.unpack_from('>I', raw, 0x1C)[0]
        self.pof_off = BASE + self.yobj_size
        self.data = raw[BASE:self.pof_off]
        self.ptrs, self.pof_len = pof0_decode(raw, self.pof_off)
        d = self.data
        self.u8 = lambda o: d[o]
        self.u16 = lambda o: struct.unpack_from('>H', d, o)[0]
        self.s16 = lambda o: struct.unpack_from('>h', d, o)[0]
        self.u32 = lambda o: struct.unpack_from('>I', d, o)[0]
        self.s32 = lambda o: struct.unpack_from('>i', d, o)[0]
        self._parse()

    # ---- parsing --------------------------------------------------------
    def _parse(self):
        u8, u16, s16, u32 = self.u8, self.u16, self.s16, self.u32
        self.mp = mp = u32(0x04)
        self.bone_count, self.bone_ptr = u32(0x08), u32(0x0C)
        self.mat_count, self.mat_ptr = u32(0x10), u32(0x14)
        self.name_count, self.name_ptr = u32(0x18), u32(0x1C)
        self.tail_start = u32(0x28)

        self.vcount = u16(mp + MI_VCOUNT)
        ngroups = u8(mp + MI_NGROUPS)
        nblocks = u8(mp + MI_NBLOCKS)
        self.u8_0x48 = u8(mp + MI_NCOLORS)          # constant 10 in both samples, meaning unresolved
        self.ncolors = u16(mp + MI_NPAL2)            # palette entry count (verified on two files)
        self.vptr = u32(mp + MI_VPTR)
        self.skin_ptr = u32(mp + MI_SKINPTR)
        self.ftab_ptr = u32(mp + MI_FTABPTR)
        self.col_ptr = u32(mp + MI_COLPTR)
        self.uv_ptr = u32(mp + MI_UVPTR)
        self.stride = 6 if self.col_ptr else 4

        # head (root + model info + color palette)
        self.head_end = self.uv_ptr
        self.palette = []
        if self.col_ptr:
            for i in range(self.ncolors):
                self.palette.append(tuple(d_ for d_ in self.data[self.col_ptr + 4 * i:self.col_ptr + 4 * i + 4]))

        # UVs / vertices
        slots = (self.vptr - self.uv_ptr) // 4
        all_uvs = [(s16(self.uv_ptr + 4 * i), s16(self.uv_ptr + 4 * i + 2)) for i in range(slots)]
        field = u16(mp + MI_UVCOUNT)
        self.uv_field_ok = (field <= slots and slots - field < 8 and
                            all(t == (0, 0) for t in all_uvs[field:]))
        self.uvs = all_uvs[:field] if self.uv_field_ok else all_uvs
        slot_verts = [tuple(s16(self.vptr + 12 * i + 2 * k) for k in range(6)) for i in range(self.vcount)]

        # skin groups
        self.groups = []
        for k in range(ngroups):
            a = self.skin_ptr + 20 * k
            g = Group()
            g.bone, g.b1, g.b2, g.C = u16(a), u16(a + 2), u16(a + 4), u16(a + 6)
            g.D, g.ptr, g.F = u32(a + 8), u32(a + 12), u32(a + 16)
            self.groups.append(g)
        self.vinfo = []      # per real vertex (group order): (key, record|None)
        for g in self.groups:
            for i in range(g.D):
                rec = u32(g.ptr + 4 * i) if g.C >= 2 else None
                self.vinfo.append((g.key(), rec))

        # batches are described by the flag words of the groups: first group of a batch =
        # slots/16 << 28 | groups << 16 | weighted << 8 ; last group of a batch = padding slots (low byte)
        self.batches = []
        i = 0
        while i < len(self.groups):
            g = self.groups[i]
            top, ng_b = g.F >> 28, (g.F >> 16) & 0xFF
            if top == 0 or ng_b == 0 or i + ng_b > len(self.groups):
                raise DumyError("skin group %d does not start a valid batch (flags 0x%08X)" % (i, g.F))
            grp = self.groups[i:i + ng_b]
            real = sum(x.D for x in grp)
            pad = grp[-1].F & 0xFF
            if real + pad != top * 16 or (g.F >> 8) & 0xFF != sum(x.D for x in grp if x.C >= 2):
                raise DumyError("skin batch at group %d is inconsistent (real %d + pad %d != %d slots)" %
                                (i, real, pad, top * 16))
            self.batches.append(dict(first=i, ng=ng_b, slots=top * 16, real=real, pad=pad,
                                     w=(g.F >> 8) & 0xFF))
            i += ng_b
        if sum(b_['slots'] for b_ in self.batches) != self.vcount:
            raise DumyError("skin batches cover %d vertex slots, model info says %d" %
                            (sum(b_['slots'] for b_ in self.batches), self.vcount))
        # slot <-> compact (real vertex) index
        self.slot_of = []
        s_ = 0
        for b_ in self.batches:
            self.slot_of += [s_ + k for k in range(b_['real'])]
            s_ += b_['slots']
        self.compact_of = dict((s__, c_) for c_, s__ in enumerate(self.slot_of))
        self.verts = [slot_verts[s__] for s__ in self.slot_of]
        self.pad_verts = [slot_verts[s__] for s__ in range(self.vcount) if s__ not in self.compact_of]
        self.extra = self.vcount - len(self.vinfo)

        # face blocks (corner stride is auto-detected: the strips of every block
        # must end exactly where the next block starts, indices must be in range)
        self.nblocks = nblocks
        self.fdata_start = u32(self.ftab_ptr + 4) if nblocks else self.ftab_ptr + 8 * nblocks
        order = (6, 4) if self.col_ptr else (4, 6)
        res = None
        for st_ in order:
            res = self._read_blocks(st_, nblocks)
            if res:
                self.stride = st_
                self.blocks, self.fdata_end = res
                break
        if not res:
            raise DumyError("Could not parse the face blocks (unknown corner layout)")
        try:
            self.blocks = [[[(self.compact_of[c_[0]], c_[1], c_[2]) for c_ in st_] for st_ in strips_]
                           for strips_ in self.blocks]
        except KeyError:
            raise DumyError("a face corner references a padding vertex slot")

        # bounding block (decoded: sums of min+max per axis and the box diagonal)
        self.bbox = struct.unpack_from('>4f', self.data, mp + MI_BBOX)
        # colour index of every corner (palette lookup).  vcol = the colour most corners of a vertex use.
        self.vcol, self.vcol_consistent = {}, True
        if self.stride == 6:
            seen = defaultdict(Counter)
            for strips in self.blocks:
                for st in strips:
                    for v_, x_, _uv in st:
                        seen[v_][x_] += 1
            for v_, c_ in seen.items():
                self.vcol[v_] = c_.most_common(1)[0][0]
                if len(c_) > 1:
                    self.vcol_consistent = False
        self.max_strip = max([len(s_) for b_ in self.blocks for s_ in b_] or [3])

        # bones
        self.bones = []
        for i in range(self.bone_count):
            a = self.bone_ptr + 80 * i
            nm = bytes(self.data[a:a + 28]).split(b'\0')[0].decode('latin1')
            self.bones.append((nm, self.s32(a + 0x30)))

        # texture-name slots: 'name\\0ext\\0' followed by uninitialised bytes (differ between files)
        self.names = []
        self.name_raw = []
        for i in range(self.name_count):
            slot = bytes(self.data[self.name_ptr + 16 * i:self.name_ptr + 16 * i + 16])
            self.name_raw.append(slot)
            i0 = slot.find(b'\0')
            nm_ = slot[:i0] if i0 >= 0 else slot
            rest_ = slot[i0 + 1:] if i0 >= 0 else b''
            i1 = rest_.find(b'\0')
            ex_ = rest_[:i1] if i1 >= 0 else rest_
            used_ = len(nm_) + 1 + len(ex_) + (1 if i1 >= 0 else 0)
            self.names.append([nm_.decode('latin1'), ex_.decode('latin1'), slot[used_:]])
        self.names_resizable = (self.name_ptr + 16 * self.name_count == self.mat_ptr
                                and self.name_ptr > self.tail_start)

    def block_slot_hint(self):
        """Per face block: u16 at +0x1A of its 0x48-byte material blob (the only field that differs between the
        blobs in the known donors, so most likely the texture-name slot). None when it is not a valid slot index."""
        out = []
        for i in range(self.mat_count):
            try:
                pt = self.u32(self.mat_ptr + 20 * i + 16)
                v = self.u16(pt + 0x1a)
            except Exception:
                v = None
            out.append(v if v is not None and v < self.name_count else None)
        return out

    def _read_blocks(self, stride, nblocks):
        u16, u32 = self.u16, self.u32
        n_data = len(self.data)
        ptrs = [u32(self.ftab_ptr + 8 * b + 4) for b in range(nblocks)]
        blocks, end = [], self.ftab_ptr + 8 * nblocks
        try:
            for b in range(nblocks):
                cnt = u16(self.ftab_ptr + 8 * b + 2)
                o, strips = ptrs[b], []
                for _ in range(cnt):
                    n = u32(o)
                    if n < 1 or n > 4000 or o + 4 + n * stride > n_data:
                        return None
                    o += 4
                    st = []
                    for _i in range(n):
                        v = u16(o)
                        if v >= self.vcount:
                            return None
                        if stride == 6:
                            st.append((v, u16(o + 2), u16(o + 4)))
                        else:
                            st.append((v, 0, u16(o + 2)))
                        o += stride
                    strips.append(st)
                nxt = ptrs[b + 1] if b + 1 < nblocks else self.tail_start
                if b + 1 < nblocks:
                    if o != nxt:
                        return None
                elif not (0 <= nxt - o < 32):
                    return None
                blocks.append(strips)
                end = max(end, o)
        except struct.error:
            return None
        return blocks, end

    def layout_problem(self):
        """None if the file follows the segment order rebuild() relies on."""
        seq = [('model head', self.uv_ptr), ('UV array', self.vptr), ('vertex array', self.skin_ptr),
               ('face table', self.ftab_ptr), ('face data', self.fdata_start),
               ('tail', self.tail_start), ('name table', self.name_ptr)]
        # skin table + weight chunks must sit directly between vertex array and face table
        prev = 0
        for nm, v in seq:
            if v < prev:
                return "segment '%s' (0x%X) lies before the previous segment" % (nm, v)
            prev = v
        if self.ftab_ptr + 8 * self.nblocks != self.fdata_start:
            return "face data does not directly follow the face table"
        if self.fdata_end > self.tail_start:
            return "face data overruns the tail section"
        if self.name_ptr + 16 * self.name_count > len(self.data):
            return "texture name table is outside the file"
        if not (self.name_ptr + 16 * self.name_count == self.mat_ptr or self.names_resizable is False):
            pass
        return None

    def model_name(self):
        """The model-name string the root header points to (e.g. 'body' / '161_body')."""
        try:
            o = self.u32(0x34)
            return bytes(self.data[o:o + 32]).split(b'\0')[0].decode('latin1')
        except (struct.error, IndexError):
            return ''

    def opaque_color_index(self):
        """Palette index of opaque white (the one most corners of the donor use)."""
        cands = [i for i, c in enumerate(self.palette) if c == (255, 255, 255, 255)]
        cands = cands or [i for i, c in enumerate(self.palette) if c[3] == 255]
        if not cands:
            return 0
        cnt = Counter(self.vcol.values())
        return max(cands, key=lambda i: cnt.get(i, 0))

    def mesh_bbox(self):
        """The bounding block recomputed from the stored (8.8) vertices."""
        return compute_bbox([self.pos(i) for i in range(self.real_vcount)])

    def weights(self):
        """Decoded weights of every real vertex: list of {bone: weight}."""
        if getattr(self, '_wcache', None) is None:
            self._wcache = [decode_weights(k, r) for k, r in self.vinfo]
        return self._wcache

    def edges(self):
        """Unique mesh edges (vertex index pairs) over all face blocks."""
        if getattr(self, '_ecache', None) is None:
            seen, n = set(), self.real_vcount
            for b in range(len(self.blocks)):
                for t in self.triangles(b):
                    ids = [c[0] for c in t]
                    if max(ids) >= n:
                        continue
                    for a, c in ((0, 1), (1, 2), (2, 0)):
                        seen.add((min(ids[a], ids[c]), max(ids[a], ids[c])))
            self._ecache = sorted(seen)
        return self._ecache

    # ---- helpers --------------------------------------------------------
    @property
    def real_vcount(self):
        return len(self.vinfo)

    def pos(self, i):
        v = self.verts[i]
        return (v[0] / 256.0, v[1] / 256.0, v[2] / 256.0)

    def block_vertices(self, b):
        s = set()
        for st in self.blocks[b]:
            for c in st:
                s.add(c[0])
        return sorted(x for x in s if x < self.real_vcount)

    def block_color_mode(self, b):
        c = Counter(x[1] for st in self.blocks[b] for x in st)
        return c.most_common(1)[0][0] if c else 0

    def triangles(self, b):
        """Yield (c0, c1, c2) corner tuples using the engine strip convention."""
        for st in self.blocks[b]:
            for i in range(len(st) - 2):
                if i % 2 == 0:
                    yield st[i], st[i + 1], st[i + 2]
                else:
                    yield st[i + 1], st[i], st[i + 2]

    def winding_sign(self):
        """Sign of the signed volume of the whole mesh under the engine strip
        winding (-1 for the supplied donor: its frame is Y-down)."""
        vol = 0.0
        for b in range(len(self.blocks)):
            for t in self.triangles(b):
                if max(c[0] for c in t) >= self.real_vcount:
                    continue
                p = [self.verts[c[0]] for c in t]
                vol += (p[0][0] * (p[1][1] * p[2][2] - p[1][2] * p[2][1])
                        - p[0][1] * (p[1][0] * p[2][2] - p[1][2] * p[2][0])
                        + p[0][2] * (p[1][0] * p[2][1] - p[1][1] * p[2][0]))
        return 1 if vol >= 0 else -1

    def normal_out(self, i):
        """Outward unit normal of real vertex i.  The file stores the triple as
        (n_z, n_x, n_y) scaled by 16 (verified on extreme vertices)."""
        v = self.verts[i]
        return (v[4] / 4096.0, v[5] / 4096.0, v[3] / 4096.0)

    def validate(self):
        """Return list of problems found (empty list == structurally sane)."""
        probs = []
        n = len(self.data)
        for p in self.ptrs:
            if p + 4 > n:
                probs.append("POF0 location 0x%X outside payload" % p)
                continue
            v = self.u32(p)
            if v > n:
                probs.append("pointer @0x%X -> 0x%X outside payload" % (p, v))
        if self.pof_off + 8 + self.pof_len != len(self.raw):
            probs.append("POF0 length does not reach end of file")
        return probs

    # ---- rebuild --------------------------------------------------------
    def rebuild(self, verts=None, uvs=None, groups_spec=None, blocks=None,
                names=None, bbox=None, batch_plan=None, max_name_bytes=10, block_slots=None, mat_clone=None):
        """
        Re-emit the whole file.  Anything left as None is taken from this donor,
        so rebuild() with no arguments must reproduce the original bytes.

        verts       : list of 6-int tuples (raw s16 pos+normal) for REAL vertices
        uvs         : list of (u_raw, v_raw)
        groups_spec : list of dicts {key:(bone,b1,b2,C), recs:[u32|None,...]}
                      in final vertex order (len(recs) <= 128)
        blocks      : list (per face block) of list of strips of (v, color, uv)
        names       : list of [name, ext, tail4]
        batch_plan  : [(groups in batch, slots)] ; slots multiple of 16, <= 128, >= vertices in the batch
        """
        identity = groups_spec is None
        if verts is None:
            verts = self.verts
        if uvs is None:
            uvs = self.uvs
        if groups_spec is None:
            groups_spec = []
            idx = 0
            for g in self.groups:
                groups_spec.append(dict(key=g.key(),
                                        recs=[self.vinfo[idx + i][1] for i in range(g.D)]))
                idx += g.D
        if blocks is None:
            blocks = self.blocks
        if names is None:
            names = self.names
        if batch_plan is None:
            batch_plan = ([(b_['ng'], b_['slots']) for b_ in self.batches] if identity
                          else plan_batches(groups_spec))
        if len(groups_spec) > GROUP_MAX:
            raise DumyError("%d skin groups needed, the format allows %d" %
                            (len(groups_spec), GROUP_MAX))
        nverts_real = sum(len(g['recs']) for g in groups_spec)
        if nverts_real != len(verts):
            raise DumyError("internal: group vertex count != vertex count")
        if sum(n_ for n_, _ in batch_plan) != len(groups_spec):
            raise DumyError("internal: batch plan does not cover all groups")
        gi_ = 0
        slot_of, s_ = [], 0
        for ng_b, slots in batch_plan:
            real_b = sum(len(g['recs']) for g in groups_spec[gi_:gi_ + ng_b])
            if slots % 16 or slots > BATCH_MAX or real_b > slots or slots - real_b > 255:
                raise DumyError("invalid skin batch: %d vertices in %d slots" % (real_b, slots))
            slot_of += [s_ + k for k in range(real_b)]
            s_ += slots
            gi_ += ng_b
        total_v = s_
        if total_v > 0xFFFF:
            raise DumyError("too many vertices (%d)" % total_v)
        if len(uvs) > 0xFFFF:
            raise DumyError("too many UVs (%d)" % len(uvs))
        if names is not self.names and not self.names_resizable and len(names) != len(self.names):
            raise DumyError("this donor does not allow changing the texture slot count")

        prob = self.layout_problem()
        if prob:
            raise DumyError("Unsupported donor layout: " + prob)
        old = self.data
        # old segment boundaries
        o_head_e = self.uv_ptr
        o_uv_e = self.vptr
        o_vert_e = self.skin_ptr
        o_skin_e = self.ftab_ptr
        o_ftab_e = self.fdata_start
        o_fdata_e = self.tail_start
        o_t1_e = self.name_ptr
        o_names_e = self.name_ptr + 16 * self.name_count
        o_end = len(old)
        # (name, old_start, old_end, kind)
        segs = [('head', 0, o_head_e, 'orig'),
                ('uv', o_head_e, o_uv_e, 'gen'),
                ('vert', o_uv_e, o_vert_e, 'gen'),
                ('skin', o_vert_e, o_skin_e, 'gen'),     # table + weight chunks
                ('ftab', o_skin_e, o_ftab_e, 'gen'),
                ('fdata', o_ftab_e, o_fdata_e, 'gen'),
                ('t1', o_fdata_e, o_t1_e, 'orig'),
                ('names', o_t1_e, o_names_e, 'gen'),
                ('t3', o_names_e, o_end, 'orig')]
        # weight chunks live inside the skin segment; old ftab begins where skin ends
        # (self.ftab_ptr), old fdata begins at fdata_start.
        for i in range(len(segs) - 1):
            assert segs[i][2] == segs[i + 1][1], (segs[i], segs[i + 1])

        out = bytearray()
        new_start = {}
        gen_ptrs = []          # absolute new pointer locations written by generators
        pieces = {}
        cursor = 0
        for name, s, e, kind in segs:
            new_start[name] = cursor
            if kind == 'orig':
                b = bytearray(old[s:e])
            else:
                b, locs = getattr(self, '_gen_' + name)(cursor, locals_ctx=dict(
                    verts=verts, uvs=uvs, groups_spec=groups_spec, blocks=blocks,
                    names=names, batch_plan=batch_plan, slot_of=slot_of, new_start=new_start,
                    max_name_bytes=max_name_bytes))
                gen_ptrs += locs
            pieces[name] = b
            cursor += len(b)
            out += b

        # remap function for pointer VALUES that target old coordinates
        order = [(s, e, new_start[n]) for n, s, e, k in segs]

        def remap(v):
            for s, e, ns in order:
                if s <= v < e:
                    return ns + (v - s)
            if v == o_end:
                return len(out)
            raise DumyError("pointer value 0x%X not inside any known segment" % v)

        seg_by_name = dict((n, (s, e, k)) for n, s, e, k in segs)
        orig_ptr_locs = []
        for p in self.ptrs:
            for n, s, e, k in segs:
                if s <= p < e:
                    if k == 'orig':
                        nl = new_start[n] + (p - s)
                        v = struct.unpack_from('>I', out, nl)[0]
                        struct.pack_into('>I', out, nl, remap(v))
                        orig_ptr_locs.append(nl)
                    break
        # head patches --------------------------------------------------------
        mp = self.mp
        struct.pack_into('>H', out, mp + MI_VCOUNT, total_v)
        out[mp + MI_NGROUPS] = len(groups_spec)
        out[mp + MI_NBLOCKS] = len(blocks)
        table_len_ = al(20 * len(groups_spec), 32)
        struct.pack_into('>H', out, mp + MI_VSIZE32, len(pieces['vert']) // 32)
        struct.pack_into('>H', out, mp + MI_WSIZE32, (len(pieces['skin']) - table_len_) // 32)
        struct.pack_into('>I', out, 0x18, len(names))
        if bbox is not None:
            struct.pack_into('>4f', out, mp + MI_BBOX, *bbox)
        if self.uv_field_ok:
            struct.pack_into('>H', out, mp + MI_UVCOUNT, len(uvs))

        # material of a NEW block: a copy of the material blob of another block (all of it except the 4 bytes at +0x18 that
        # point at the blob itself); the texture slot byte (+0x47) is set afterwards by block_slots
        for dst_, src_ in (mat_clone or {}).items():
            if 0 <= dst_ < self.mat_count and 0 <= src_ < self.mat_count:
                pd_ = self.u32(self.mat_ptr + 20 * dst_ + 16)
                ps_ = self.u32(self.mat_ptr + 20 * src_ + 16)
                if o_names_e <= pd_ and pd_ + 0x48 <= o_end and o_names_e <= ps_ and ps_ + 0x48 <= o_end:
                    for i_ in range(0x48):
                        if 0x18 <= i_ < 0x1C:
                            continue
                        out[new_start['t3'] + (pd_ - o_names_e) + i_] = old[ps_ + i_]

        # texture slot per face block: u8 at +0x47 of the block's 0x48-byte material blob (donor: colour blocks 0,
        # blood block 10).  Without this every colour submesh samples slot 0, i.e. one texture on the whole model.
        if block_slots:
            for blk_, slot_ in block_slots.items():
                if 0 <= blk_ < self.mat_count and 0 <= slot_ < len(names):
                    pt_ = self.u32(self.mat_ptr + 20 * blk_ + 16)
                    if o_names_e <= pt_ and pt_ + 0x48 <= o_end:
                        out[new_start['t3'] + (pt_ - o_names_e) + 0x47] = slot_

        pof = pof0_encode(orig_ptr_locs + gen_ptrs)
        head = bytearray(self.raw[:BASE])
        struct.pack_into('>I', head, 0x1C, len(out))
        return bytes(head) + bytes(out) + pof


    # ---- generators ------------------------------------------------------
    def _gen_uv(self, base, locals_ctx):
        uvs = locals_ctx['uvs']
        b = bytearray()
        for u, v in uvs:
            b += struct.pack('>hh', u, v)
        b += bytes(al(len(b), 32) - len(b))
        return b, []

    def _gen_vert(self, base, locals_ctx):
        verts, plan, gs = locals_ctx['verts'], locals_ctx['batch_plan'], locals_ctx['groups_spec']
        b = bytearray()
        vi, gi = 0, 0
        for ng_b, slots in plan:
            real_b = sum(len(g['recs']) for g in gs[gi:gi + ng_b])
            for v in verts[vi:vi + real_b]:
                b += struct.pack('>6h', *v)
            b += bytes(12 * (slots - real_b))
            vi += real_b
            gi += ng_b
        b += bytes(al(len(b), 32) - len(b))
        return b, []

    def _gen_skin(self, base, locals_ctx):
        groups_spec, plan = locals_ctx['groups_spec'], locals_ctx['batch_plan']
        ng = len(groups_spec)
        table_len = al(20 * ng, 32)
        table = bytearray(table_len)
        chunks = bytearray()
        locs = []
        gi = 0
        for ng_b, slots in plan:
            batch = groups_spec[gi:gi + ng_b]
            real_b = sum(len(g['recs']) for g in batch)
            wcount = sum(len(g['recs']) for g in batch if g['key'][3] >= 2)
            for k, g in enumerate(batch):
                bone, b1, b2, C = g['key']
                F = 0
                if k == 0:
                    F = ((slots // 16) << 28) | (ng_b << 16) | (wcount << 8)
                if k == ng_b - 1:
                    F |= (slots - real_b)
                ptr = base + table_len + len(chunks)
                if C >= 2:
                    for r in g['recs']:
                        chunks += struct.pack('>I', r & 0xFFFFFFFF)
                struct.pack_into('>HHHHIII', table, 20 * gi, bone, b1, b2, C,
                                 len(g['recs']), ptr, F)
                locs.append(base + 20 * gi + 12)
                gi += 1
            chunks += bytes(al(len(chunks), 32) - len(chunks))
        return bytearray(table) + chunks, locs

    def _gen_ftab(self, base, locals_ctx):
        blocks = locals_ctx['blocks']
        tab_len = 8 * len(blocks)     # face data follows the table directly
        fdata_base = base + tab_len
        tab = bytearray(tab_len)
        locs = []
        addr = fdata_base
        for b, strips in enumerate(blocks):
            cnt = len(strips)
            if cnt > 0xFFFF:
                raise DumyError("too many strips in block %d" % b)
            struct.pack_into('>HHI', tab, 8 * b, ((b & 0xFF) << 8) | (cnt & 0xFF), cnt, addr)
            locs.append(base + 8 * b + 4)
            for st in strips:
                addr += 4 + self.stride * len(st)
        return tab, locs

    def _gen_fdata(self, base, locals_ctx):
        blocks, slot_of = locals_ctx['blocks'], locals_ctx['slot_of']
        b = bytearray()
        for strips in blocks:
            for st in strips:
                b += struct.pack('>I', len(st))
                for v, x, uv in st:
                    if self.stride == 6:
                        b += struct.pack('>HHH', slot_of[v], x, uv)
                    else:
                        b += struct.pack('>HH', slot_of[v], uv)
        b += bytes(al(base + len(b), 32) - (base + len(b)))
        return b, []

    def _gen_names(self, base, locals_ctx):
        names, limit = locals_ctx['names'], locals_ctx['max_name_bytes']
        b = bytearray()
        for i, (nm, ext, filler) in enumerate(names):
            s = nm.encode('latin1') + b'\0' + ext.encode('latin1') + b'\0'
            if len(s) > limit or len(s) > 16:
                raise DumyError("texture name '%s.%s' needs %d bytes; the donor files only show names up to "
                                "%d bytes (name + ext + 2 terminators)" % (nm, ext, len(s), limit))
            if i < len(self.name_raw):
                old = self.name_raw[i]
                oi0 = old.find(b'\0')
                # keep the donor's bytes after its own strings; clear the part of the old strings we shorten
                used_old = len(self.names[i][0]) + len(self.names[i][1]) + 2 if oi0 >= 0 else 16
                slot = s + bytes(max(0, used_old - len(s))) + old[max(len(s), used_old):]
            else:
                slot = s + bytes(16 - len(s))
            b += slot[:16].ljust(16, b'\0')
        return b, []


def dumy_roundtrip_ok(dumy):
    """Rebuild with unchanged content; True if bytes are identical."""
    return dumy.rebuild() == dumy.raw


# --------------------------------------------------------------------------
# skin weight records (decoded)
# --------------------------------------------------------------------------
W_SCALE = 4096.0
NO_BONE = 0xFFFF
HI_MAX, LO_MAX = 4096, 4095


def decode_weights(key, rec):
    """(bone, b1, b2, nInfl) + u32 record -> {bone: weight}  (weights sum to 1)."""
    bone, b1, b2, C = key
    if C <= 1 or rec is None:
        return {bone: 1.0}
    hi = (rec >> 16) / W_SCALE
    lo = (rec & 0xFFFF) / W_SCALE
    out = defaultdict(float)
    if C == 2:
        out[bone] += 1.0 - hi
        out[b1] += hi
    else:
        out[bone] += (1.0 - lo) * (1.0 - hi)
        out[b1] += (1.0 - lo) * hi
        out[b2] += lo
    return dict(out)


def encode_into_key(key, weights):
    """Encode {bone: weight} into the u32 record of an existing skin group key.
    Bones of `weights` that are not part of the key are ignored (renormalised)."""
    bone, b1, b2, C = key
    if C <= 1:
        return None
    w0, w1 = weights.get(bone, 0.0), weights.get(b1, 0.0)
    w2 = weights.get(b2, 0.0) if C >= 3 else 0.0
    tot = w0 + w1 + w2
    if tot <= 1e-12:
        w0, w1, w2, tot = 1.0, 0.0, 0.0, 1.0
    w0, w1, w2 = w0 / tot, w1 / tot, w2 / tot
    rem = w0 + w1
    hi = (w1 / rem) if rem > 1e-9 else 0.0
    hi_i = max(0, min(HI_MAX, int(round(hi * W_SCALE))))
    lo_i = max(0, min(LO_MAX, int(round(w2 * W_SCALE)))) if C >= 3 else 0
    return (hi_i << 16) | lo_i


def encode_weights(weights, max_influences=3):
    """Free-form encode: {bone: weight} -> (key, record).  The three strongest
    bones are kept; the strongest becomes `bone` (so a zero record == 100% on it)."""
    w = sorted(((b, v) for b, v in weights.items() if v > 1e-4), key=lambda kv: -kv[1])
    w = w[:max_influences]
    if not w:
        raise DumyError("no influences")
    s = sum(v for _, v in w)
    w = [(b, v / s) for b, v in w]
    if len(w) == 1:
        return (w[0][0], NO_BONE, NO_BONE, 1), None
    if len(w) == 2:
        key = (w[0][0], w[1][0], NO_BONE, 2)
    else:
        key = (w[0][0], w[1][0], w[2][0], 3)
    return key, encode_into_key(key, dict(w))


def compute_bbox(points):
    """Decoded bounding block: (minX+maxX, minY+maxY, minZ+maxZ, length of the box diagonal)."""
    xs, ys, zs = zip(*points)
    lo = (min(xs), min(ys), min(zs))
    hi = (max(xs), max(ys), max(zs))
    return (lo[0] + hi[0], lo[1] + hi[1], lo[2] + hi[2],
            math.sqrt(sum((hi[k] - lo[k]) ** 2 for k in range(3))))


LSB = 1.0 / 256.0


def check_rules(d):
    """Test every decoded format rule on a loaded file.  Returns [(id, 'PASS'|'FAIL'|'INFO', text)].
    Rules were derived from two sample files; run on a third file this shows which still hold."""
    R = []

    def add(rid, ok, text):
        R.append((rid, 'PASS' if ok else 'FAIL', text))

    def info(rid, text):
        R.append((rid, 'INFO', text))
    n = len(d.data)
    mp = d.mp
    add('root.pointers', all(0 < p_ < n for p_ in (d.mp, d.bone_ptr, d.mat_ptr, d.name_ptr, d.tail_start)),
        "root pointers (model info, bones, materials, names, tail) lie inside the payload")
    add('model.vertex_slots', d.vcount == sum(b_['slots'] for b_ in d.batches) and
        d.skin_ptr - d.vptr == al(12 * d.vcount, 32) and all(v_ == (0,) * 6 for v_ in d.pad_verts),
        "u16@+0x00 = vertex SLOTS (%d = %d real + %d zero padding slots); array = 12 bytes per slot" %
        (d.vcount, d.real_vcount, d.extra))
    add('model.size_fields',
        d.u16(mp + MI_VSIZE32) * 32 == d.skin_ptr - d.vptr and
        d.u16(mp + MI_WSIZE32) * 32 == d.ftab_ptr - (d.skin_ptr + al(20 * len(d.groups), 32)),
        "u16@+0x1C = vertex array bytes/32 (%d), u16@+0x1E = weight-record area bytes/32 (%d)" %
        (d.u16(mp + MI_VSIZE32), d.u16(mp + MI_WSIZE32)))
    add('model.group_block_counts', d.u8(mp + MI_NGROUPS) == len(d.groups) and d.u8(mp + MI_NBLOCKS) == len(d.blocks),
        "u8@+0x06 = skin groups, u8@+0x07 = face blocks")
    add('model.uv_count', d.uv_field_ok, "u16@+0x2A = UV count; the UV array is zero-padded to 32 bytes")
    add('model.palette', len(d.palette) == d.u16(mp + MI_NPAL2) and 4 * len(d.palette) <= d.uv_ptr - d.col_ptr,
        "u16@+0x28 = palette entries (%d) of RGBA8 at the palette pointer" % len(d.palette))
    sb = d.mesh_bbox()
    err = [abs(sb[k] - d.bbox[k]) for k in range(4)]
    add('model.bbox', max(err) <= 1.0,
        "bounding block @+0x30 ~ (min+max per axis, box diagonal) of the real vertices: exact to 1.5 LSB on one "
        "sample, off by up to 0.6 on the other, so the game tolerates inexact values  "
        "[stored %s | recomputed %s | max error %.3f]" %
        (tuple(round(x, 3) for x in d.bbox), tuple(round(x, 3) for x in sb), max(err)))
    ok = True
    for b_ in d.batches:
        grp = d.groups[b_['first']:b_['first'] + b_['ng']]
        ok = ok and b_['slots'] % 16 == 0 and 16 <= b_['slots'] <= BATCH_MAX and b_['real'] + b_['pad'] == b_['slots']
        ok = ok and [g.C for g in grp] == sorted(g.C for g in grp)
        for k, g in enumerate(grp):
            e = 0
            if k == 0:
                e = ((b_['slots'] // 16) << 28) | (b_['ng'] << 16) | (b_['w'] << 8)
            if k == len(grp) - 1:
                e |= b_['pad']
            ok = ok and g.F == e
    add('skin.batches', ok,
        "%d batches (<=128 slots, multiple of 16): first group flags = slots/16<<28 | groups<<16 | weighted<<8, "
        "last group's low byte = padding slots; groups inside a batch ascend in influence count" % len(d.batches))
    ok = True
    wch = [g for g in d.groups if g.C >= 2]
    for i, g in enumerate(wch):
        nxt = wch[i + 1].ptr if i + 1 < len(wch) else d.ftab_ptr
        ok = ok and 0 <= nxt - g.ptr - 4 * g.D < 32
    add('skin.chunks', ok, "weight records: one u32 per vertex of every 2/3-bone group, chunks 32-byte aligned")
    add('skin.weights', all(abs(sum(w.values()) - 1) < 1e-6 and min(w.values()) > -1e-9 and max(w.values()) < 1 + 1e-9
                            for w in d.weights()),
        "every record decodes to weights in 0..1 summing to 1 (sequential lerp bone->b1->b2)")
    ok = True
    for b in range(len(d.blocks)):
        a = d.ftab_ptr + 8 * b
        cnt = len(d.blocks[b])
        ok = ok and d.u16(a + 2) == cnt and d.u16(a) == ((b & 0xFF) << 8 | (cnt & 0xFF))
    add('faces.table', ok, "face table entry = [block<<8 | strips&0xFF][strip count][pointer]")
    uvmax = max([c[2] for b in d.blocks for s in b for c in s] or [0])
    add('faces.strips', all(len(s) >= 3 for b in d.blocks for s in b) and uvmax < len(d.uvs) and
        d.fdata_end <= d.tail_start,
        "strips: >=3 corners, corner = [vertex slot][colour][uv] (stride %d); slots never point at padding; "
        "longest strip %d" % (d.stride, d.max_strip))
    if d.stride == 6:
        used = {c[1] for b in d.blocks for s in b for c in s}
        add('vertex.colour', max(used or [0]) < len(d.palette),
            "corner colour index < palette size (%d entries; alpha %s)" % (len(d.palette), [c[3] for c in d.palette]))
        info('vertex.colour.scope', "colour index is %s in this file; palette RGB %s" % (
            "constant per vertex" if d.vcol_consistent else "PER CORNER (vertices differ between corners)",
            "all white" if all(c[:3] == (255, 255, 255) for c in d.palette) else "not all white"))
    nm_ok = True
    for i in range(d.name_count):
        slot = d.name_raw[i]
        z = slot.find(b'\0')
        nm_ok = nm_ok and z > 0 and slot.find(b'\0', z + 1) > z and slot.find(b'\0', z + 1) < 16
    add('names.slots', nm_ok, "texture-name slot starts with 'name\\0ext\\0'; the bytes after are uninitialised "
                              "filler (differs between files)")
    blobs = []
    for i in range(d.mat_count):
        pt = d.u32(d.mat_ptr + 20 * i + 16)
        blobs.append(bytes(d.data[pt:pt + 0x48]))
    diff = [o for o in range(0x48) if len({b[o] for b in blobs}) > 1 and o not in (0x1a, 0x1b)]
    add('materials.table', d.mat_count == len(d.blocks) and
        all(d.u32(d.mat_ptr + 20 * i + 16) == d.u32(d.mat_ptr + 16) + 0x48 * i for i in range(d.mat_count)),
        "one 20-byte material entry + one 0x48-byte blob per face block")
    info('materials.blobs', "blobs identical except bytes at +%s" % ", +".join("0x%02x" % o for o in diff))
    info('tail', "0x%X: count+pointer record -> bone table; 0x%X: 6 material ids; 0x%X: model name string" %
         (d.tail_start, d.u32(0x2c), d.u32(0x34)))
    return R


def plan_batches(groups_spec):
    """Default batch plan: groups are packed in order, up to 128 vertices per batch;
    each batch is padded to a multiple of 16 slots."""
    plan, cur, curn = [], 0, 0
    for g in groups_spec:
        n = len(g['recs'])
        if cur and curn + n > BATCH_MAX:
            plan.append((cur, al(curn, 16)))
            cur, curn = 0, 0
        cur += 1
        curn += n
    if cur:
        plan.append((cur, al(curn, 16)))
    return plan


# --------------------------------------------------------------------------
# OBJ import
# --------------------------------------------------------------------------
class ObjModel(object):
    def __init__(self):
        self.V, self.VT, self.VN = [], [], []
        self.groups = OrderedDict()      # name -> list of tris ((vi,ti,ni[,ci]) x3)
        self.skin = None                 # {position index: {joint name: weight}}  (from .dae)
        self.VC = None                   # corner colours RGBA 0..1 (from .dae)
        self.meta = {}

    @property
    def tri_count(self):
        return sum(len(t) for t in self.groups.values())


def parse_obj(path, mode='object'):
    """mode: 'object' -> group by o/g lines, 'material' -> group by usemtl."""
    m = ObjModel()
    cur_obj, cur_mat = 'default', None
    mtllibs, grp_mats = [], defaultdict(Counter)     # grp_mats[group][material] = triangles

    def idx(tok, n):
        if not tok:
            return None
        i = int(tok)
        return i - 1 if i > 0 else n + i

    with open(path, 'r', errors='ignore') as fh:
        for line in fh:
            p = line.split()
            if not p or p[0].startswith('#'):
                continue
            t = p[0]
            if t == 'v' and len(p) >= 4:
                m.V.append((float(p[1]), float(p[2]), float(p[3])))
            elif t == 'vt' and len(p) >= 3:
                m.VT.append((float(p[1]), float(p[2])))
            elif t == 'vn' and len(p) >= 4:
                m.VN.append((float(p[1]), float(p[2]), float(p[3])))
            elif t in ('o', 'g'):
                cur_obj = ' '.join(p[1:]) or 'default'
            elif t == 'usemtl':
                cur_mat = ' '.join(p[1:]) or None
            elif t == 'mtllib' and len(p) >= 2:
                mtllibs.append(line.strip()[6:].strip())
            elif t == 'f' and len(p) >= 4:
                corners = []
                for tok in p[1:]:
                    s = tok.split('/')
                    vi = idx(s[0], len(m.V))
                    ti = idx(s[1], len(m.VT)) if len(s) > 1 and s[1] else None
                    ni = idx(s[2], len(m.VN)) if len(s) > 2 and s[2] else None
                    corners.append((vi, ti, ni))
                name = cur_obj if (mode == 'object' or not cur_mat) else cur_mat
                lst = m.groups.setdefault(name, [])
                for k in range(1, len(corners) - 1):
                    lst.append((corners[0], corners[k], corners[k + 1]))
                if cur_mat:
                    grp_mats[name][cur_mat] += len(corners) - 2
    if not m.V or not m.groups:
        raise DumyError("OBJ contains no vertices/faces")
    # textures from the .mtl (map_Kd): group -> image stem of the material that has most triangles in the group
    mat_tex, found = {}, []
    for lib in mtllibs:
        for cand in (lib, lib.split()[0] if lib.split() else lib):
            fp = os.path.join(os.path.dirname(os.path.abspath(path)), cand.replace('\\', os.sep))
            if os.path.isfile(fp):
                mat_tex.update(parse_mtl(fp))
                found.append(fp)
                break
    gt, multi = {}, []
    for g_, cnt in grp_mats.items():
        texs = Counter()
        for mt_, n_ in cnt.items():
            if mat_tex.get(mt_):
                texs[mat_tex[mt_]] += n_
        if texs:
            gt[g_] = texs.most_common(1)[0][0]
            if len(texs) > 1:
                multi.append(g_)
    m.meta = dict(format='obj', mtl=found, mtllib=mtllibs, group_textures=gt, group_multi=multi,
                  images=sorted(set(mat_tex.values())))
    return m


_MTL_OPT_ARGS = {'-blendu': 1, '-blendv': 1, '-cc': 1, '-clamp': 1, '-imfchan': 1, '-mm': 2, '-o': 3, '-s': 3,
                 '-t': 3, '-texres': 1, '-bm': 1, '-boost': 1, '-type': 1}


def parse_mtl(path):
    """{material name: texture image stem} from the map_Kd (diffuse) lines of a .mtl file."""
    out, cur = {}, None
    with open(path, 'r', errors='ignore') as fh:
        for line in fh:
            p = line.split()
            if not p or p[0].startswith('#'):
                continue
            k = p[0].lower()
            if k == 'newmtl':
                cur = ' '.join(p[1:])
            elif k == 'map_kd' and cur is not None and len(p) > 1:
                i = 1
                while i < len(p) and p[i].startswith('-') and p[i].lower() in _MTL_OPT_ARGS:
                    i += 1 + _MTL_OPT_ARGS[p[i].lower()]
                fn = ' '.join(p[i:]).strip().strip('"')
                stem = os.path.splitext(re.split(r'[\\/]', fn)[-1])[0]
                if stem:
                    out[cur] = stem
    return out


def load_obj_mtl(path, use_mtl=True, log=print):
    """Load an .obj/.dae.  For an .obj with a .mtl: when one o/g group uses several textures the model is regrouped
    by material (usemtl) so each texture gets its own submesh.  Returns the model (meta['group_textures'] filled
    from the .mtl unless use_mtl is False)."""
    obj = load_model(path, 'object')
    if path.lower().endswith('.dae'):
        return obj
    if not use_mtl:
        obj.meta['group_textures'] = {}
        return obj
    if obj.meta.get('group_multi'):
        log("Some OBJ groups use more than one material/texture: grouping by material (usemtl) instead of o/g so "
            "each texture gets its own submesh.")
        obj = load_model(path, 'material')
    if not obj.meta.get('mtl'):
        log("No .mtl found next to the OBJ (mtllib: %s): texture names left unchanged." %
            (", ".join(obj.meta.get('mtllib') or []) or "none"))
    elif not obj.meta.get('group_textures'):
        log("The .mtl has no map_Kd texture for the materials used: texture names left unchanged.")
    else:
        log("Textures from %s: %s" % (", ".join(os.path.basename(x) for x in obj.meta['mtl']),
                                      ", ".join("%s -> %s" % kv for kv in obj.meta['group_textures'].items())))
    return obj


# --------------------------------------------------------------------------
# transform
# --------------------------------------------------------------------------
class Xform(object):
    def __init__(self, scale=1.0, flip=(False, True, True), swap_yz=False,
                 offset=(0.0, 0.0, 0.0), stretch=(1.0, 1.0, 1.0)):
        self.scale, self.flip, self.swap_yz, self.offset = scale, tuple(flip), swap_yz, tuple(offset)
        self.stretch = tuple(stretch)     # extra per-axis scale in donor space (Blender-style S, X/Y/Z)

    def _lin(self, p):
        x, y, z = p
        if self.swap_yz:
            y, z = z, y
        return (-x if self.flip[0] else x, -y if self.flip[1] else y, -z if self.flip[2] else z)

    def point(self, p):
        q = self._lin(p)
        s, o, t = self.scale, self.offset, self.stretch
        return (q[0] * s * t[0] + o[0], q[1] * s * t[1] + o[1], q[2] * s * t[2] + o[2])

    def normal(self, n):
        q = self._lin(n)
        t = self.stretch
        q = (q[0] / (t[0] or 1.0), q[1] / (t[1] or 1.0), q[2] / (t[2] or 1.0))   # inverse-transpose of a diagonal
        l = math.sqrt(q[0] ** 2 + q[1] ** 2 + q[2] ** 2) or 1.0
        return (q[0] / l, q[1] / l, q[2] / l)


def bbox(points):
    xs, ys, zs = zip(*points)
    return (min(xs), min(ys), min(zs)), (max(xs), max(ys), max(zs))


def auto_fit(donor, obj, xf):
    """Set xf.scale/offset so the custom model's bbox matches the donor's."""
    used = set()
    for tris in obj.groups.values():
        for t in tris:
            for c in t:
                used.add(c[0])
    base = Xform(1.0, xf.flip, xf.swap_yz, (0, 0, 0))
    pts = [base.point(obj.V[i]) for i in used]
    (a0, a1, a2), (b0, b1, b2) = bbox(pts)
    dpts = [donor.pos(i) for i in range(donor.real_vcount)]
    (d0, d1, d2), (e0, e1, e2) = bbox(dpts)
    h_c, h_d = (b1 - a1), (e1 - d1)
    xf.scale = (h_d / h_c) if h_c > 1e-9 else 1.0
    xf.stretch = (1.0, 1.0, 1.0)
    s = xf.scale
    xf.offset = (((d0 + e0) - (a0 + b0) * s) / 2.0,
                 ((d1 + e1) - (a1 + b1) * s) / 2.0,
                 ((d2 + e2) - (a2 + b2) * s) / 2.0)
    return xf


PIVOTS = ("bounding-box centre", "bottom centre (feet)", "origin (0,0,0)")


def pivot_point(pts, mode):
    """Pivot for the interactive scale (donor space, Y-down: the feet are at the largest Y)."""
    if str(mode).startswith('origin') or not pts:
        return (0.0, 0.0, 0.0)
    lo, hi = bbox(pts)
    c = [(lo[k] + hi[k]) / 2.0 for k in range(3)]
    if str(mode).startswith('bottom'):
        c[1] = hi[1]
    return tuple(c)


def view_basis(yaw, pitch):
    """Donor-space unit vectors of the preview's screen-right and screen-down directions."""
    cy, sy, cp, sp = math.cos(yaw), math.sin(yaw), math.cos(pitch), math.sin(pitch)
    return (cy, 0.0, sy), (sp * sy, cp, -sp * cy)


def grab_delta(dx, dy, sc, basis, axis=None, exclude=False, typed=None, snap=False):
    """Blender 'G': screen drag (px) -> donor-space translation.  axis = 0/1/2 constrains to that axis,
    exclude=True moves in the plane that leaves that axis alone; typed = per-axis typed values."""
    R, D = basis
    if axis is not None and not exclude:
        n2 = R[axis] ** 2 + D[axis] ** 2
        d = [0.0, 0.0, 0.0]
        d[axis] = (dx * R[axis] + dy * D[axis]) / (sc * n2) if n2 > 0.05 else 0.0
    else:
        d = [(dx * R[k] + dy * D[k]) / sc for k in range(3)]
        if axis is not None:
            d[axis] = 0.0
    if snap:
        d = [float(round(v)) for v in d]
    if typed and any(v is not None for v in typed):
        d = [0.0 if v is None else float(v) for v in typed]
        if axis is not None and exclude:
            d[axis] = 0.0
    return tuple(d)


def scale_factors(k, axis=None, exclude=False):
    """Blender 'S': one factor -> per-axis factors (X/Y/Z constrain, Shift+X/Y/Z exclude)."""
    k = max(float(k), 0.001)
    if axis is None:
        return (k, k, k)
    K = [k, k, k] if exclude else [1.0, 1.0, 1.0]
    K[axis] = 1.0 if exclude else k
    return tuple(K)


def apply_scale(scale, stretch, offset, pivot, K, uniform):
    """Scale the transformed model by K (per axis) about pivot (donor space)."""
    off = tuple(K[i] * offset[i] + pivot[i] * (1.0 - K[i]) for i in range(3))
    if uniform:
        return scale * K[0], tuple(stretch), off
    return scale, tuple(stretch[i] * K[i] for i in range(3)), off


# --------------------------------------------------------------------------
# nearest-vertex search (uniform grid, pure python)
# --------------------------------------------------------------------------
class Grid(object):
    """Uniform grid for nearest-point queries.  A query starts at the occupied cell box (never at the query
    cell itself, so far-away queries are cheap) and walks only the shell of each ring, clipped to that box."""

    def __init__(self, pts, ids=None, cell=2.0):
        self.cell = cell
        self.pts = pts
        self.map = defaultdict(list)
        lo = [10 ** 9] * 3
        hi = [-10 ** 9] * 3
        for i in (ids if ids is not None else range(len(pts))):
            x, y, z = pts[i]
            k = (int(math.floor(x / cell)), int(math.floor(y / cell)), int(math.floor(z / cell)))
            self.map[k].append(i)
            for a in range(3):
                lo[a] = min(lo[a], k[a])
                hi[a] = max(hi[a], k[a])
        self.lo, self.hi = lo, hi
        self.cache = {}

    def _scan(self, q, k):
        if not self.map:
            return []
        key = (q, k)
        hit = self.cache.get(key)
        if hit is not None:
            return hit
        c = self.cell
        cx, cy, cz = (int(math.floor(q[0] / c)), int(math.floor(q[1] / c)), int(math.floor(q[2] / c)))
        lo, hi = self.lo, self.hi
        r = max(lo[0] - cx, cx - hi[0], lo[1] - cy, cy - hi[1], lo[2] - cz, cz - hi[2], 0)   # rings before are empty
        limit = max(abs(cx - lo[0]), abs(cx - hi[0]), abs(cy - lo[1]), abs(cy - hi[1]),
                    abs(cz - lo[2]), abs(cz - hi[2]))
        found = []
        pts, mp = self.pts, self.map
        while r <= limit:
            for x in range(max(cx - r, lo[0]), min(cx + r, hi[0]) + 1):
                for y in range(max(cy - r, lo[1]), min(cy + r, hi[1]) + 1):
                    if abs(x - cx) == r or abs(y - cy) == r:
                        zs = range(max(cz - r, lo[2]), min(cz + r, hi[2]) + 1)
                    else:
                        zs = [z for z in ((cz - r, cz + r) if r else (cz,)) if lo[2] <= z <= hi[2]]
                    for z in zs:
                        lst = mp.get((x, y, z))
                        if lst:
                            for i in lst:
                                p = pts[i]
                                found.append(((p[0] - q[0]) ** 2 + (p[1] - q[1]) ** 2 + (p[2] - q[2]) ** 2, i))
            if len(found) >= k:
                found.sort()
                if found[k - 1][0] <= (r * c) ** 2:
                    break
            r += 1
        found.sort()
        res = found[:k]
        self.cache[key] = res
        return res

    def nearest(self, q):
        r = self._scan(q, 1)
        return r[0][1] if r else None

    def knn(self, q, k):
        """[(squared distance, index)] of the k nearest points, nearest first."""
        return self._scan(q, k)


BLEND_K = 4


# --------------------------------------------------------------------------
# stripifier (engine convention: even tri (0,1,2), odd tri (1,0,2))
# --------------------------------------------------------------------------
def stripify(tris, max_len=STRIP_MAX, tries=16):
    """Greedy triangle strips (engine convention: strict alternation, so a strip is fixed once its first triangle and
    rotation are chosen).  Compared with the old index-order greedy this starts every strip at the triangle with the
    FEWEST unused neighbours (boundary / leftover triangles first, so they do not end up as 1-triangle strips) and keeps
    the best of `tries` randomised tie-breaks: about 15 % fewer strips on decimated meshes, which is smaller file
    data (a strip costs 4 bytes + 2 extra corners of 6 bytes)."""
    import heapq
    import random
    n = len(tris)
    if n == 0:
        return []
    edge = defaultdict(list)
    for i, (a, b, c) in enumerate(tris):
        edge[(a, b)].append(i)
        edge[(b, c)].append(i)
        edge[(c, a)].append(i)
    adj = [set() for _ in range(n)]
    for (x, y), ts in edge.items():
        for j in edge.get((y, x), ()):
            for i in ts:
                if i != j:
                    adj[i].add(j)

    def third(j, e0, e1):
        a, b, c = tris[j]
        if (a, b) == (e0, e1):
            return c
        if (b, c) == (e0, e1):
            return a
        return b            # (c, a)

    def grow(i, rot, used):
        a, b, c = tris[i]
        L = [a, b, c]
        for _ in range(rot):
            L = L[1:] + L[:1]
        local = {i}
        ids = [i]
        while len(L) < max_len:
            m = len(L) - 2
            need = (L[-2], L[-1]) if m % 2 == 0 else (L[-1], L[-2])
            nxt = None
            for j in edge.get(need, ()):
                if not used[j] and j not in local:
                    nxt = j
                    break
            if nxt is None:
                break
            L.append(third(nxt, need[0], need[1]))
            local.add(nxt)
            ids.append(nxt)
        return L, ids

    def run_order():
        """The original pass: start strips in INPUT order.  Triangles that already come in strip order (re-imported
        donor, a model exported from this tool) are recovered exactly, which the randomised pass below cannot do."""
        used = [False] * n
        strips = []
        for i in range(n):
            if used[i]:
                continue
            best = None
            for rot in range(3):
                L, ids = grow(i, rot, used)
                if best is None or len(L) > len(best[0]):
                    best = (L, ids)
                if len(L) >= max_len:
                    break
            for j in best[1]:
                used[j] = True
            strips.append(best[0])
        return strips

    def run(seed):
        rnd = random.Random(seed)
        used = [False] * n
        deg = [len(x) for x in adj]
        heap = [(deg[i], rnd.random(), i) for i in range(n)]
        heapq.heapify(heap)
        strips = []
        while heap:
            d, _, i = heapq.heappop(heap)
            if used[i] or d != deg[i]:
                continue
            cands = [grow(i, r, used) for r in range(3)]
            m = max(len(c[0]) for c in cands)
            best = rnd.choice([c for c in cands if len(c[0]) == m]) if seed else next(c for c in cands if len(c[0]) == m)
            for j in best[1]:
                used[j] = True
            for j in best[1]:
                for k in adj[j]:
                    if not used[k]:
                        deg[k] -= 1
                        heapq.heappush(heap, (deg[k], rnd.random(), k))
            strips.append(best[0])
        return strips
    best = run_order()
    for seed in range(max(1, tries)):
        st = run(seed)
        if len(st) < len(best):
            best = st
    return best


def strips_to_tris(strips):
    out = []
    for st in strips:
        for i in range(len(st) - 2):
            out.append((st[i], st[i + 1], st[i + 2]) if i % 2 == 0
                       else (st[i + 1], st[i], st[i + 2]))
    return out


# --------------------------------------------------------------------------
# import / patch pipeline
# --------------------------------------------------------------------------
def default_mapping(obj, donor):
    """OBJ/DAE group -> dict(block, bone, color).
    A group named 'blood' goes to the last submesh; a name like 'submesh_3' / 'body_2' / 'part-1' (separator
    + 1-2 digits) goes to that submesh; everything else (e.g. Blender's 'Material.001') goes to submesh 0,
    the donor's main body mesh."""
    mp = OrderedDict()
    nb = len(donor.blocks)
    for name in obj.groups:
        blk = 0
        low = name.lower()
        m = re.search(r'[_\- ](\d{1,2})$', low)
        if 'blood' in low and nb:
            blk = nb - 1
        elif m and int(m.group(1)) < nb and len(obj.groups) > 1:
            blk = int(m.group(1))
        mp[name] = dict(block=blk, bone=None, color=None)
    # Groups without a submesh number (typical .dae: one material per texture) used to ALL collapse into submesh 0.
    # Give each its own submesh, biggest first (body -> submesh 0).  The donor has nb submeshes (the last one is
    # the blood layer); when there are more materials than submeshes the blood submesh is used as well and the
    # two SMALLEST materials share the last submesh (only one texture per submesh is possible).
    named = [n_ for n_ in obj.groups if 'blood' not in n_.lower()]
    plain = [n_ for n_ in named if not re.search(r'[_\- ](\d{1,2})$', n_.lower())]
    if nb > 1 and len(obj.groups) > 1 and len(plain) == len(named):
        order = sorted(plain, key=lambda n_: -len(obj.groups[n_]))
        for i_, n_ in enumerate(order):
            mp[n_]['block'] = min(i_, nb - 1)
    return mp


def _cross(a, b):
    return (a[1] * b[2] - a[2] * b[1], a[2] * b[0] - a[0] * b[2], a[0] * b[1] - a[1] * b[0])


def _group_count(wkey):
    """Skin groups the packer will create for these per-vertex keys (sorted, cut into 128-vertex batches)."""
    ks = sorted(wkey, key=lambda k: (k[3], k[0], k[1], k[2]))
    n = 0
    for s in range(0, len(ks), BATCH_MAX):
        prev = None
        for k in ks[s:s + BATCH_MAX]:
            if k != prev:
                n += 1
                prev = k
    return n


FACE_KEYWORDS = ("face, facial, jaw, chin, brow, brows, eyebrow, eyelid, lid, lids, eye, eyes, eyeball, "
                 "lip, lips, mouth, cheek, nose, nostril, tongue, teeth, tooth, smile")


def face_bone_indices(donor, keywords=None):
    """Donor bones whose name contains one of the keywords as a word (Jaw, L_Eye, LipUpper, eyeBrow_R ...)."""
    kws = set(k.strip().lower() for k in str(keywords or FACE_KEYWORDS).replace(';', ',').split(',') if k.strip())
    out = []
    for i, (nm, _) in enumerate(donor.bones):
        toks = [t.lower() for t in re.findall(r'[A-Z]+(?![a-z])|[A-Z]?[a-z]+', nm)]
        if nm.lower() in kws or any(t in kws for t in toks):
            out.append(i)
    return out


def face_remap(donor, face):
    """{face bone: nearest ancestor that is not a face bone}.  Face bones with no such ancestor are left out."""
    fs, n = set(face), len(donor.bones)
    tgt = {}
    for b in face:
        p, hops = b, 0
        while p in fs and 0 <= donor.bones[p][1] < n and hops < n:
            p, hops = donor.bones[p][1], hops + 1
        if p not in fs:
            tgt[b] = p
    return tgt


def strip_face_weights(wkey, wrec, tgt, keysets, parent):
    """Move every weight on a face bone onto its target bone (in place).  Returns the vertices changed."""
    cache, changed = {}, 0
    for i in range(len(wkey)):
        key, rec = wkey[i], wrec[i]
        if not any(x in tgt for x in key[:3] if x != NO_BONE):
            continue
        ck = (key, rec)
        if ck not in cache:
            nw = defaultdict(float)
            for b, x in decode_weights(key, rec).items():
                nw[tgt.get(b, b)] += x
            cache[ck] = choose_key(dict(nw), keysets, parent)
        wkey[i], wrec[i] = cache[ck]
        changed += 1
    return changed


def choose_key(w, keysets, parent):
    """Skin group key + record for explicit weights {bone: weight}.  Any role order encodes exactly, so the
    donor's own role order is reused when it has a key with the same bones; otherwise (child, parent)
    for related pairs, else by descending weight."""
    top = sorted(w, key=lambda b: -w[b])[:3]
    s = sum(w[b] for b in top)
    w = dict((b, w[b] / s) for b in top)
    if len(top) == 1:
        return (top[0], NO_BONE, NO_BONE, 1), None
    cand = keysets.get(frozenset(top))
    if cand:
        key = cand.most_common(1)[0][0]
    elif len(top) == 2:
        a, b = top
        if parent[a] == b:
            key = (a, b, NO_BONE, 2)
        elif parent[b] == a:
            key = (b, a, NO_BONE, 2)
        else:
            key = (a, b, NO_BONE, 2)
    else:
        key = (top[0], top[1], top[2], 3)
    return key, encode_into_key(key, w)


def fit_group_limit(wkey, wrec, log):
    """The skin table holds at most 255 groups.  If the weights need more, the rarest skin-group keys are
    merged into the most similar existing key (weights are projected onto its bones)."""
    cnt = _group_count(wkey)
    if cnt <= GROUP_MAX:
        return
    nv = len(wkey)
    merged = 0
    errs = []
    while cnt > GROUP_MAX:
        freq = Counter(wkey)
        if len(freq) < 2:
            break
        victim = min(freq, key=lambda k: (freq[k], -k[3]))
        ids = [i for i in range(nv) if wkey[i] == victim]
        vb = set(b for b in victim[:3] if b != NO_BONE)
        cands = [k for k in freq if k != victim and vb & set(b for b in k[:3] if b != NO_BONE)] or \
                [k for k in freq if k != victim]
        sample = ids[:48]
        best, berr = None, 1e30
        for ck in cands:
            e_ = 0.0
            for i in sample:
                w = decode_weights(wkey[i], wrec[i])
                w2 = decode_weights(ck, encode_into_key(ck, w))
                e_ += sum(abs(w.get(b, 0.0) - w2.get(b, 0.0)) for b in set(w) | set(w2))
            if e_ < berr:
                best, berr = ck, e_
        for i in ids:
            w = decode_weights(wkey[i], wrec[i])
            wkey[i] = best
            wrec[i] = encode_into_key(best, w)
            errs.append(sum(abs(w.get(b, 0.0) - x) for b, x in decode_weights(best, wrec[i]).items()))
        merged += 1
        cnt = _group_count(wkey)
    log("WARNING: the weights needed more than %d skin groups; merged %d rare bone combinations into similar "
        "ones (%d vertices changed, mean weight change %.3f)" % (GROUP_MAX, merged, len(errs),
                                                              sum(errs) / max(len(errs), 1)))


TEAR_TOL = 0.10        # coincident vertices are only merged if their skin weights differ by less than this (sum |dw|)


def make_tear(obj):
    """Skin-weight lookup for the weld: position index -> {joint: weight} (the 3 strongest, renormalised - what the
    format can store), or None if the model carries no skin weights (OBJ)."""
    skin = getattr(obj, 'skin', None)
    if not skin:
        return None
    cache = {}

    def wt(vi):
        w = cache.get(vi)
        if w is None:
            top = sorted(((x, j) for j, x in (skin.get(vi) or {}).items() if x > 0), reverse=True)[:3]
            s_ = sum(x for x, _ in top)
            w = dict((j, x / s_) for x, j in top) if s_ > 1e-9 else {}
            cache[vi] = w
        return w
    return wt


def _wdiff(a, b):
    return sum(abs(a.get(j, 0.0) - b.get(j, 0.0)) for j in set(a) | set(b))


def tear_lists(obj, mapping):
    """Forced bone of every triangle, parallel to the triangle lists of the mapped groups (None if no group has one)."""
    items = [(g, c) for g, c in mapping.items() if c.get('block') is not None]
    if not any(c.get('bone') is not None for _, c in items):
        return None
    return [[c.get('bone')] * len(obj.groups[g]) for g, c in items]


def _weld(obj, xf, tri_lists, weld_angle, wt=None, fb_lists=None):
    """Unique DUMY vertices of the given triangles.  A DUMY vertex is position + normal (+ skin weights); UVs
    and colours belong to the corners.  Corners at the same position (to the file's 1/256 precision) whose
    normals differ by less than weld_angle degrees share one vertex whose normal is their mean.
    weld_angle None: one vertex per (position index, normal index) pair, as stored in the model file.
    wt / fb_lists (mesh tear): corners at one position are NOT merged when their skin weights (wt) or the forced bone of
    their group (fb_lists, parallel to tri_lists) differ - e.g. the upper and the lower lip of a closed mouth stay two
    vertices, so the jaw can pull them apart and the inside of the mouth shows.  A merged vertex can only carry ONE
    set of weights, so merging them would glue the lips together."""
    vmap, vkeys, vsum, vsig = {}, [], [], []
    tear = wt is not None or fb_lists is not None
    clusters = defaultdict(list)
    pkey = {}
    cos_t = None if weld_angle is None else (math.cos(math.radians(weld_angle)) - 1e-9 if weld_angle > 0 else 1.0 - 1e-6)
    ncorners = 0

    def pos_key(vi):
        if vi not in pkey:
            p_ = xf.point(obj.V[vi])
            pkey[vi] = (vi,) if cos_t is None else tuple(int(round(max(-128.0, min(127.99, c)) * 256)) for c in p_)
        return pkey[vi]
    for li_, tris in enumerate(tri_lists):
        fbl = fb_lists[li_] if fb_lists is not None else None
        for ti_, t in enumerate(tris):
            fb = fbl[ti_] if fbl is not None else None
            for c_ in t:
                ncorners += 1
                k = (c_[0], c_[2])
                if k in vmap:
                    continue
                n_ = None
                if obj.VN and c_[2] is not None and 0 <= c_[2] < len(obj.VN):
                    n_ = xf.normal(obj.VN[c_[2]])
                vid = None
                sg = None
                if cos_t is not None:
                    if tear:
                        sg = {('F', fb): 1.0} if fb is not None else (wt(c_[0]) if wt is not None else {})
                    for cand in clusters[pos_key(c_[0])]:
                        if tear and _wdiff(vsig[cand], sg) > TEAR_TOL:
                            continue                # different skin weights: keep the two vertices apart
                        s_ = vsum[cand]
                        if n_ is None or s_ is None:
                            if n_ is None and s_ is None:
                                vid = cand
                                break
                            continue
                        l_ = math.sqrt(s_[0] ** 2 + s_[1] ** 2 + s_[2] ** 2) or 1.0
                        if (n_[0] * s_[0] + n_[1] * s_[1] + n_[2] * s_[2]) / l_ >= cos_t:
                            vid = cand
                            break
                if vid is None:
                    vid = len(vkeys)
                    vkeys.append(k)
                    vsum.append(list(n_) if n_ is not None else None)
                    vsig.append(sg)
                    clusters[pos_key(c_[0])].append(vid)
                elif n_ is not None and vsum[vid] is not None:
                    vsum[vid][0] += n_[0]
                    vsum[vid][1] += n_[1]
                    vsum[vid][2] += n_[2]
                vmap[k] = vid
    return vmap, vkeys, vsum, ncorners, cos_t


AUTO_WELD_ANGLES = (0, 30, 45, 60, 90, 120, 180)


def auto_weld_angle(obj, xf, tri_lists, target, log=lambda s: None, wt=None, fb_lists=None):
    """Smallest weld angle that keeps the vertex count within `target` (hard edges are kept where the budget
    allows); the largest angle if none does."""
    last = None
    for a in AUTO_WELD_ANGLES:
        n = len(_weld(obj, xf, tri_lists, a, wt, fb_lists)[1])
        last = (a, n)
        if n <= target:
            log("Auto weld: %g degrees gives %d vertices (target <= %d)" % (a, n, target))
            return a
    # (this used to be `"..." % last + (0,)`, which raised TypeError - i.e. every model that did not fit the budget
    # even fully smoothed made the whole port fail instead of just warning)
    log("WARNING: even fully smoothed (%g degrees) the model has %d vertices (target <= %d): reduce the mesh "
        "(decimate) before porting" %
        (last[0], last[1], target))
    return AUTO_WELD_ANGLES[-1]


def weld_counts(obj, xf, mapping, angles=(0, 30, 60, 90, 180), tear=False):
    """{angle: vertex count} the importer would create for the mapped groups (tear: keep differently weighted
    vertices apart, as the importer does with weights from a .dae)."""
    tl = [obj.groups[g] for g, c in mapping.items() if c.get('block') is not None]
    wt, fb = (make_tear(obj), tear_lists(obj, mapping)) if tear else (None, None)
    return dict((a, len(_weld(obj, xf, tl, a, wt, fb)[1])) for a in angles)


def build_import(donor, obj, mapping, xf, weight_mode='transfer', single_bone=0,
                 restrict=False, log=lambda s: None, colour_mode='opaque', weld_angle=None,
                 no_face_anim=False, face_keywords=None, vert_budget=None, tear_weights=True, extra_blocks=0):
    """
    Convert the OBJ into the arrays Dumy.rebuild() needs.
    extra_blocks: number of NEW face blocks (submeshes) appended after the donor's (their material is the donor's material
                 of the same index, see rebuild(mat_clone=...)); groups may then be mapped to block len(donor.blocks) + k.
    weight_mode: 'transfer' (copy skin record of nearest donor vertex),
                 'blend'    (inverse-distance mix of the 4 nearest donor vertices,
                             re-encoded in the nearest vertex's skin group),
                 'rigid'    (dominant bone of nearest donor vertex, 100%),
                 'single'   (every vertex 100% on single_bone),
                 'file'     (explicit skin weights stored in the model file: .dae)
    colour_mode: 'opaque' | 'transfer' | 'file' (per-corner colours of the model file, nearest palette entry)
    tear_weights: mesh tear (default on): vertices at one position are never merged when their skin weights (weights
                 from a .dae) or the forced bone of their group differ, so e.g. a closed mouth keeps separate upper-lip
                 and lower-lip vertices and can open.  Only has an effect with weight_mode 'file' (or forced bones):
                 with 'transfer' / 'rigid' the weights come from the vertex POSITION, so coincident vertices get the
                 same weights anyway.
    vert_budget: optional vertex cap that weld_angle='auto' aims for (see vertex_target).  None / 0 = no limit (the
                 default): 'auto' then never smooths normals just to save vertices.  Only the hard format cap
                 (MAX_FORMAT_VERTS) applies.
    no_face_anim: after the weights are resolved, every weight on a facial bone (jaw, eyes, brows, lips ... picked by
                 name, see face_keywords) is moved to the nearest non-facial ancestor (normally the head), so
                 facial animation can no longer deform the ported mesh.
    """
    nblocks = len(donor.blocks) + int(extra_blocks)
    # ---- collect triangles per block ------------------------------------
    block_tris = defaultdict(list)       # block -> list of ((vi,ti,ni[,ci])x3)
    block_gname = defaultdict(list)      # block -> group name of each triangle
    block_fb = defaultdict(list)         # block -> forced bone (or None) of each triangle's group
    tri_group = []                        # (group name, tri) for forced bones
    for name, tris in obj.groups.items():
        cfg = mapping.get(name)
        if cfg is None or cfg.get('block') is None:
            continue
        b = cfg['block']
        if not (0 <= b < nblocks):
            raise DumyError("group '%s' mapped to missing submesh %s" % (name, b))
        for t in tris:
            block_tris[b].append(t)
            block_gname[b].append(name)
            block_fb[b].append(cfg.get('bone'))
            tri_group.append((name, t))
    if not block_tris:
        raise DumyError("No triangles are mapped to any submesh")
    for w_ in mapping_warnings(obj, mapping, donor):
        log("WARNING: " + w_)

    # ---- unique vertices -------------------------------------------------------------
    tl_ = [block_tris[b_] for b_ in sorted(block_tris)]
    wt_ = make_tear(obj) if (tear_weights and weight_mode == 'file') else None
    fb_ = [block_fb[b_] for b_ in sorted(block_tris)] if (
        tear_weights and any(x_ is not None for b_ in block_fb for x_ in block_fb[b_])) else None
    if weld_angle == 'auto':
        weld_angle = auto_weld_angle(obj, xf, tl_, vertex_target(donor, vert_budget), log, wt_, fb_)
    vmap, vkeys, vsum, ncorners, cos_t = _weld(obj, xf, tl_, weld_angle, wt_, fb_)
    if cos_t is not None and (wt_ is not None or fb_ is not None):
        n_merged = len(_weld(obj, xf, tl_, weld_angle)[1])
        if len(vkeys) > n_merged:
            log("Mesh tear: %d vertices were kept apart instead of being merged because their skin weights differ "
                "(e.g. upper and lower lip of a closed mouth stay separate, so the mouth can open)" %
                (len(vkeys) - n_merged))
    log("Vertices: %d triangle corners -> %d vertices%s" % (
        ncorners, len(vkeys), "" if cos_t is None else " (corners at one position with normals within %g degrees share a vertex)" % weld_angle))
    nv = len(vkeys)
    if nv > MAX_FORMAT_VERTS:
        raise DumyError("The model has %d vertices after merging; the .dumy format holds at most %d (255 skin groups x "
                        "128-vertex batches - and every distinct bone combination in a batch uses up a group as well, "
                        "so the practical limit is lower). Reduce the mesh (decimate) or raise the normal-merge angle."
                        % (nv, MAX_FORMAT_VERTS))
    pos = [xf.point(obj.V[k[0]]) for k in vkeys]

    # clamp to 8.8 range
    lim = 127.99
    clamped = 0
    for i, p in enumerate(pos):
        q = tuple(max(-128.0, min(lim, c)) for c in p)
        if q != p:
            clamped += 1
            pos[i] = q
    if clamped:
        log("WARNING: %d vertices outside the +-128 range were clamped "
            "(model too large -> lower the scale)" % clamped)

    # ---- winding: signed volume must have the same sign as the donor --------
    def tri_pos(tt):
        return [pos[vmap[(c[0], c[2])]] for c in tt]

    vol = 0.0
    for b in block_tris:
        for tt in block_tris[b]:
            p = tri_pos(tt)
            vol += (p[0][0] * (p[1][1] * p[2][2] - p[1][2] * p[2][1])
                    - p[0][1] * (p[1][0] * p[2][2] - p[1][2] * p[2][0])
                    + p[0][2] * (p[1][0] * p[2][1] - p[1][1] * p[2][0]))
    new_sign = 1 if vol >= 0 else -1
    flip_winding = (new_sign != donor.winding_sign())
    log("Signed mesh volume %s -> %s triangle order" %
        ("positive" if new_sign > 0 else "negative",
         "reversing" if flip_winding else "keeping"))

    # ---- normals (outward, unit) ------------------------------------------------
    nrm = [None] * nv
    if obj.VN:
        for i, (vi, ni) in enumerate(vkeys):
            if vsum[i] is not None:
                s_ = vsum[i]
                l_ = math.sqrt(s_[0] ** 2 + s_[1] ** 2 + s_[2] ** 2) or 1.0
                nrm[i] = (s_[0] / l_, s_[1] / l_, s_[2] / l_)
    need_calc = [i for i in range(nv) if nrm[i] is None]
    if need_calc:
        acc = defaultdict(lambda: [0.0, 0.0, 0.0])
        for b in block_tris:
            for tt in block_tris[b]:
                p = tri_pos(tt)
                cr = _cross((p[1][0] - p[0][0], p[1][1] - p[0][1], p[1][2] - p[0][2]),
                            (p[2][0] - p[0][0], p[2][1] - p[0][1], p[2][2] - p[0][2]))
                for c in tt:
                    a_ = acc[c[0]]
                    a_[0] += cr[0]
                    a_[1] += cr[1]
                    a_[2] += cr[2]
        for i in need_calc:
            a_ = acc[vkeys[i][0]]
            l = math.sqrt(a_[0] ** 2 + a_[1] ** 2 + a_[2] ** 2) or 1.0
            nrm[i] = (new_sign * a_[0] / l, new_sign * a_[1] / l, new_sign * a_[2] / l)
        log("Computed smooth normals for %d vertices (OBJ had no usable vn)" % len(need_calc))

    # ---- UVs -----------------------------------------------------------------
    uv_index, uv_list = {}, []
    missing_uv = 0

    def uv_of(ti):
        nonlocal missing_uv
        if ti is None or ti >= len(obj.VT):
            missing_uv += 1
            u = v = 0.0
        else:
            u, v = obj.VT[ti]
            v = 1.0 - v
        su = max(-32768, min(32767, int(round(u * 1024))))
        sv = max(-32768, min(32767, int(round(v * 1024))))
        k = (su, sv)
        if k not in uv_index:
            uv_index[k] = len(uv_list)
            uv_list.append(k)
        return uv_index[k]

    # ---- bone weights ----------------------------------------------------------
    forced = {}
    for name, t in tri_group:
        fb = mapping[name].get('bone')
        if fb is not None:
            for c in t:
                forced.setdefault(vmap[(c[0], c[2])], fb)
    vblock = {}
    for b in sorted(block_tris, reverse=True):
        for t in block_tris[b]:
            for c in t:
                vblock[vmap[(c[0], c[2])]] = b

    dpts = [donor.pos(i) for i in range(donor.real_vcount)]
    dW = donor.weights()
    grid_all = Grid(dpts)
    grids = {}

    def grid_for(i):
        g = grid_all
        if restrict:
            b = vblock.get(i)
            if b is not None:
                if b not in grids:
                    ids = donor.block_vertices(b) if b < len(donor.blocks) else None
                    grids[b] = Grid(dpts, ids) if ids else grid_all
                g = grids[b]
        return g
    wkey = [None] * nv
    wrec = [None] * nv
    skin = getattr(obj, 'skin', None)
    if weight_mode == 'file' and not skin:
        raise DumyError("The model file has no skin weights (use another weight mode)")
    parent = [donor.bones[b_][1] for b_ in range(donor.bone_count)]
    keysets = defaultdict(Counter)
    for g_ in donor.groups:
        keysets[frozenset(b_ for b_ in (g_.bone, g_.b1, g_.b2) if b_ != NO_BONE)][g_.key()] += g_.D
    bone_by_name = {}
    for b_ in range(donor.bone_count):
        bone_by_name.setdefault(_norm_bone(donor.bones[b_][0]), b_)
    jcache, unmapped, fallback, trunc = {}, set(), [0], [0]

    def joint_bone(jn):
        if jn not in jcache:
            jcache[jn] = bone_by_name.get(_norm_bone(jn))
            if jcache[jn] is None:
                unmapped.add(jn)
        return jcache[jn]

    def file_w(i):
        d = skin.get(vkeys[i][0]) if skin else None
        if not d:
            return None
        w = defaultdict(float)
        for jn, x in d.items():
            b_ = joint_bone(jn)
            if b_ is not None and x > 0:
                w[b_] += x
        s_ = sum(w.values())
        return dict((b_, x / s_) for b_, x in w.items()) if s_ > 1e-9 else None
    for i in range(nv):
        if i and i % 4000 == 0:
            log("  ... skin weights %d / %d vertices" % (i, nv))
        if i in forced or weight_mode == 'single':
            wkey[i] = ((forced.get(i, single_bone)), 0xFFFF, 0xFFFF, 1)
            continue
        if weight_mode == 'file':
            w_ = file_w(i)
            if w_ is not None:
                if len(w_) > 3:
                    trunc[0] += 1
                wkey[i], wrec[i] = choose_key(w_, keysets, parent)
                continue
            fallback[0] += 1
        g = grid_for(i)
        if weight_mode == 'blend':
            nb = g.knn(pos[i], BLEND_K)
            j = nb[0][1]
        else:
            j = g.nearest(pos[i])
        key, rec = donor.vinfo[j]
        if weight_mode == 'rigid':
            w = dW[j]
            wkey[i], wrec[i] = (max(w, key=w.get), 0xFFFF, 0xFFFF, 1), None
        elif weight_mode == 'blend' and key[3] > 1:
            d0 = math.sqrt(nb[0][0])
            lim = (2.0 * d0 + 1.0) ** 2
            roles = [x for x in key[:3] if x != 0xFFFF]
            acc = defaultdict(float)
            for d2, jj in nb:
                if d2 > lim:
                    continue
                f = 1.0 / (d2 + 1e-9)
                for x in roles:
                    acc[x] += f * dW[jj].get(x, 0.0)
            s = sum(acc.values())
            wkey[i] = key
            wrec[i] = encode_into_key(key, dict((x, v / s) for x, v in acc.items())) if s > 1e-9 else rec
        else:
            wkey[i], wrec[i] = key, rec

    if weight_mode == 'file':
        if unmapped:
            log("WARNING: %d joint name(s) of the .dae are not bones of the donor and were ignored: %s" %
                (len(unmapped), ", ".join(sorted(unmapped)[:8]) + (" ..." if len(unmapped) > 8 else "")))
        if fallback[0]:
            log("WARNING: %d vertices had no usable skin weights; they got the nearest donor weights" % fallback[0])
        if trunc[0]:
            log("NOTE: %d vertices had more than 3 influences; the format holds 3, so the weakest were dropped "
                "and the rest renormalised" % trunc[0])
        used_b = set(b_ for w_ in (file_w(i) or {} for i in range(nv)) for b_ in w_)
        log("Skin weights from the model file: %d of the donor's %d bones used" % (len(used_b), donor.bone_count))
    if no_face_anim:
        face = face_bone_indices(donor, face_keywords)
        tgt = face_remap(donor, face)
        if not tgt:
            log("WARNING: 'disable facial animation' is on but no facial bone matched the keywords (%s); "
                "weights unchanged" % (face_keywords or FACE_KEYWORDS))
        else:
            n_ch = strip_face_weights(wkey, wrec, tgt, keysets, parent)
            log("Facial animation disabled: %d face bone(s) [%s] folded into %s; %d of %d vertices re-weighted" % (
                len(tgt), ", ".join(donor.bones[b][0] for b in sorted(tgt)[:8]) + (" ..." if len(tgt) > 8 else ""),
                ", ".join(sorted(set(donor.bones[t][0] for t in tgt.values()))), n_ch, nv))
    fit_group_limit(wkey, wrec, log)

    # ---- per-vertex colour index (palette lookup, constant per vertex in the donor) ----
    pal = donor.palette
    opq = donor.opaque_color_index() if donor.stride == 6 else 0
    vcolor = [None] * nv
    for name, tt in tri_group:
        fc = mapping[name].get('color')
        if fc is not None:
            if not (0 <= fc < max(len(pal), 1)):
                raise DumyError("group '%s': colour index %d is outside the donor palette (0..%d)" %
                                (name, fc, len(pal) - 1))
            for c in tt:
                i = vmap[(c[0], c[2])]
                if vcolor[i] is None:
                    vcolor[i] = fc
    pal_cache = {}
    if colour_mode == 'file' and not getattr(obj, 'VC', None):
        log("WARNING: the model file has no vertex colours; using opaque white")
        colour_mode = 'opaque'

    def pal_of(ci):
        rgba = obj.VC[ci]
        key = tuple(round(x, 4) for x in rgba)
        if key not in pal_cache:
            dist = [sum((pal[k][c_] / 255.0 - rgba[c_]) ** 2 for c_ in range(4)) for k in range(len(pal))]
            best = min(range(len(pal)), key=lambda k: dist[k])
            pal_cache[key] = (best, math.sqrt(dist[best]))
        return pal_cache[key][0]
    if donor.stride == 6:
        if colour_mode == 'transfer':
            for i in range(nv):
                if vcolor[i] is None:
                    j = grid_for(i).nearest(pos[i])
                    vcolor[i] = donor.vcol.get(j, opq)
        else:
            for i in range(nv):
                if vcolor[i] is None:
                    vcolor[i] = opq
        cc = Counter(vcolor)
        if colour_mode == 'file':
            log("Vertex colour: per-corner colours of the model file (opaque white where a corner has none)")
        else:
            log("Vertex colour: %s - %s" % (
                "copied from the nearest donor vertex" if colour_mode == 'transfer' else "opaque white by default",
                ", ".join("idx %d (alpha %d): %d" % (k, pal[k][3], v) for k, v in sorted(cc.items()))))
    else:
        vcolor = [0] * nv

    # ---- order vertices by skin key and cut into FULL 128-vertex batches --------
    # Skin batches hold up to 128 vertices; groups never straddle a batch; slots per batch are a
    # multiple of 16 (the unused slots are zero padding vertices at the end of the batch).
    # Sorting by influence count first keeps rigid -> 2-bone -> 3-bone order inside a batch.
    order = sorted(range(nv), key=lambda i: (wkey[i][3], wkey[i][0], wkey[i][1], wkey[i][2], i))
    newidx = [0] * nv
    groups_spec = []
    batch_plan = []
    for start in range(0, nv, BATCH_MAX):
        cur_key, cur = None, None
        n_before = len(groups_spec)
        chunk = order[start:start + BATCH_MAX]
        for off_, i in enumerate(chunk):
            newidx[i] = start + off_
            if wkey[i] != cur_key:
                cur_key = wkey[i]
                cur = dict(key=cur_key, recs=[])
                groups_spec.append(cur)
            cur['recs'].append(wrec[i])
        batch_plan.append((len(groups_spec) - n_before, al(len(chunk), 16)))
    if len(groups_spec) > GROUP_MAX:
        raise DumyError("This weight setup needs %d skin groups (max %d) for %d vertices in %d skin batches. Use the "
                        "'rigid' weight mode, fold the facial bones (--no-face-anim) or reduce the vertex count." %
                        (len(groups_spec), GROUP_MAX, nv, len(batch_plan)))
    slots_total = sum(s_ for _, s_ in batch_plan)
    if slots_total > 0xFFFF:
        raise DumyError("too many vertices (%d slots, max 65535)" % slots_total)
    if slots_total > int(1.5 * size_ref(donor)):
        log("NOTE: %d vertex slots / %d skin groups / %d skin batches is above what is known to work (the original "
            "files have at most %d slots; a %d-slot port crashed the game). The game's real limit is unknown - "
            "test the result in-game." % (slots_total, len(groups_spec), len(batch_plan), KNOWN_MAX_SLOTS,
                                          KNOWN_CRASH_SLOTS))

    # ---- vertex arrays ------------------------------------------------------------
    verts = [None] * nv
    for i in range(nv):
        p, n = pos[i], nrm[i]
        # normal triple is stored as (n_z, n_x, n_y) * 16 in 8.8 fixed point
        raw = [int(round(c * 256)) for c in p] + \
              [max(-32768, min(32767, int(round(c * 16 * 256)))) for c in (n[2], n[0], n[1])]
        verts[newidx[i]] = tuple(max(-32768, min(32767, r)) for r in raw)

    # ---- face blocks ----------------------------------------------------------------
    blocks = []
    dropped = [0]
    for b in range(nblocks):
        tl = []
        for t_, gname in zip(block_tris.get(b, []), block_gname.get(b, [])):
            fixed = mapping[gname].get('color')
            cs = []
            for c in t_:
                i_ = vmap[(c[0], c[2])]
                col = fixed
                if col is None and colour_mode == 'file' and len(c) > 3 and c[3] is not None:
                    col = pal_of(c[3])
                cs.append((newidx[i_], vcolor[i_] if col is None else col, uv_of(c[1])))
            if flip_winding:
                cs = [cs[0], cs[2], cs[1]]
            if len({c[0] for c in cs}) < 3:
                dropped[0] += 1
                continue                          # degenerate
            tl.append(tuple(cs))
        blocks.append(stripify(tl, max_len=donor.max_strip))
        log("Submesh %d: %d triangles -> %d strips (longest allowed %d = longest in the donor)" %
            (b, len(tl), len(blocks[-1]), donor.max_strip))
    # An empty block (0 strips) never occurs in a donor and is a likely crash cause: give it ONE degenerate
    # strip (3 corners on the same vertex, draws nothing) so the block looks structurally like a normal one.
    first_corner = next((st_[0] for blk_ in blocks for st_ in blk_ if st_), None)
    if first_corner is not None:
        for b_i, blk_ in enumerate(blocks):
            if not blk_:
                blocks[b_i] = [[first_corner, first_corner, first_corner]]
                log("Submesh %d is empty: written as one invisible degenerate triangle instead of 0 strips" % b_i)
    if dropped[0]:
        log("%d zero-area triangle(s) (two corners on one vertex) were dropped" % dropped[0])
    if pal_cache:
        worst = max(d_ for _, d_ in pal_cache.values())
        log("File colours mapped onto %d palette entries; largest difference to the palette %.3f%s" %
            (len(set(k for k, _ in pal_cache.values())), worst,
             " - WARNING: these colours are not in the donor palette" if worst > 0.02 else " (exact)"))
    if missing_uv:
        log("WARNING: %d corners had no UV (set to 0,0)" % missing_uv)

    cnt = Counter(k[3] for k in wkey)
    bbox = compute_bbox(pos)
    stats = dict(verts=nv, slots=slots_total, strips=sum(len(b_) for b_ in blocks), batches=len(batch_plan),
                 uvs=len(uv_list), groups=len(groups_spec), infl1=cnt[1], infl2=cnt[2], infl3=cnt[3],
                 tris=sum(len(v) for v in block_tris.values()), clamped=clamped)
    return dict(verts=verts, uvs=uv_list, groups_spec=groups_spec, blocks=blocks,
                batch_plan=batch_plan, stats=stats, bbox=bbox)


def port_model(donor, obj, mapping, xf, names=None, max_name_bytes=10, extra_slots=None, mat_clone=None, **kw):
    """Full pipeline -> bytes of the patched .dumy.
    extra_slots: {block: texture slot} forced on top of the automatic plan; mat_clone: {block: donor block whose material
    is copied} (needed for NEW blocks, see build_import(extra_blocks=...))."""
    r = build_import(donor, obj, mapping, xf, **kw)
    slots = dict(texture_slot_plan(obj, mapping, donor)[0])
    slots.update(extra_slots or {})
    out = donor.rebuild(verts=r['verts'], uvs=r['uvs'], groups_spec=r['groups_spec'],
                        blocks=r['blocks'], names=names, bbox=r['bbox'], batch_plan=r['batch_plan'],
                        max_name_bytes=max_name_bytes, block_slots=slots, mat_clone=mat_clone)
    return out, r['stats']


# --------------------------------------------------------------------------
# reference export of the donor (so a custom model can be fitted in Blender)
# --------------------------------------------------------------------------
def export_donor_obj(donor, path, include_blood=True, yup=True):
    """Reference OBJ of the donor.  yup=True: Y up, the character faces +Z and its left is +X
    (a 180-degree rotation about X: x, -y, -z - no mirroring) with counter-clockwise faces, as 3D tools
    expect; importing it again with the default transform reproduces the donor exactly."""
    n = donor.real_vcount
    sy, sz = (-1.0, -1.0) if yup else (1.0, 1.0)
    lines = ["# donor exported by DUMY Port Tool (%s)" % ("Y-up, faces +Z, left = +X" if yup else "native frame")]
    for i in range(n):
        p = donor.pos(i)
        lines.append("v %.6f %.6f %.6f" % (p[0], sy * p[1], sz * p[2]))
    for u, v in donor.uvs:
        lines.append("vt %.6f %.6f" % (u / 1024.0, 1.0 - v / 1024.0))
    for i in range(n):
        nx, ny, nz = donor.normal_out(i)
        lines.append("vn %.6f %.6f %.6f" % (nx, sy * ny, sz * nz))
    for b in range(len(donor.blocks)):
        if b == len(donor.blocks) - 1 and not include_blood:
            continue
        lines.append("g submesh_%d" % b)
        for t in donor.triangles(b):
            if max(c[0] for c in t) >= n:
                continue
            cs = [t[0], t[2], t[1]] if yup else list(t)
            lines.append("f " + " ".join("%d/%d/%d" % (c[0] + 1, c[2] + 1, c[0] + 1) for c in cs))
    with open(path, 'w') as fh:
        fh.write("\n".join(lines) + "\n")


def donor_facing(donor):
    """+1 if toes point to +Z, -1 if to -Z, 0 if unknown (uses 'Toe' / 'Foot' bones)."""
    toe = [i for i, (nm, _) in enumerate(donor.bones) if 'toe' in nm.lower()]
    foot = [i for i, (nm, _) in enumerate(donor.bones) if nm.lower().endswith('foot')]
    zt = [donor.pos(i)[2] for i, (k, _) in enumerate(donor.vinfo) if k[0] in toe]
    zf = [donor.pos(i)[2] for i, (k, _) in enumerate(donor.vinfo) if k[0] in foot]
    if not zt or not zf:
        return 0
    d = sum(zt) / len(zt) - sum(zf) / len(zf)
    return 1 if d > 0.05 else (-1 if d < -0.05 else 0)


# --------------------------------------------------------------------------
# .TEX name reader (names only; used to fill the texture-slot table)
# --------------------------------------------------------------------------
def read_tex_names(path):
    raw = open(path, 'rb').read()
    out, pos = [], 0x10
    while pos + 32 <= len(raw):
        if raw[pos + 16:pos + 20].split(b'\0')[0] != b'tpl':
            break
        out.append(raw[pos:pos + 16].split(b'\0')[0].decode('latin1'))
        pos += 32
    return out


# Both sample files hold 2,965 and 3,177 vertices (3,184 slots at most).  A port with 15,424 slots
# (5,810 triangles, 5,097 strips, 121 skin batches) crashed the game.  The real limit is unknown.
KNOWN_MAX_SLOTS = 3184
KNOWN_CRASH_SLOTS = 15424


def size_ref(donor):
    """Reference vertex-slot count for size targets: the largest known-good model, or the donor's own count if
    that is slightly larger (up to 1.5x).  A donor far above that is probably an oversized port and must not
    raise the bar."""
    return donor.vcount if KNOWN_MAX_SLOTS < donor.vcount <= 1.5 * KNOWN_MAX_SLOTS else KNOWN_MAX_SLOTS


def vertex_target(donor, vert_budget=None):
    """Vertex count that 'auto' normal-merging aims for.
    vert_budget None or 0 -> no limit (the default): nothing is merged beyond identical corners, hard edges are kept;
                 N        -> an optional cap of N vertices that the user asked for."""
    if vert_budget is None or vert_budget <= 0:
        return MAX_FORMAT_VERTS
    return int(vert_budget)


def parse_budget(text):
    """'' / 'auto' / 'unlimited' / 'off' / 'max' / '0' -> None (no limit);  '20000' / '20,000' -> 20000.
    Raises ValueError on anything else."""
    t = str(text if text is not None else '').strip().lower().replace(',', '').replace('_', '').replace(' ', '')
    if t in ('', 'auto', 'default', 'unlimited', 'none', 'off', 'max', 'no', 'inf', 'infinite'):
        return None
    n = int(t)
    if n < 0:
        raise ValueError("vertex budget must be >= 0")
    return n or None


def mapping_warnings(obj, mapping, donor):
    """Submeshes that receive far more triangles than the donor's own (in both sample files submeshes 3-5 are
    small overlay layers and the last one is the blood layer)."""
    tri = [sum(len(s) - 2 for s in b) for b in donor.blocks]
    cnt = Counter()
    for g, c in mapping.items():
        if c.get('block') is not None:
            cnt[c['block']] += len(obj.groups[g])
    out = []
    nb = len(donor.blocks)
    for b, n in sorted(cnt.items()):
        if b < nb and b != 0 and n > 3 * max(tri[b], 1) and n > 500:      # submesh 0 = the body: any size is fine there (new submeshes: no check)
            out.append("submesh %d receives %d triangles but the donor's submesh %d has only %d%s. Both sample files "
                       "keep the body in submesh 0 and use the others as small overlay layers; consider mapping the "
                       "body to submesh 0 (Submesh map tab)." %
                       (b, n, b, tri[b], " (it is the BLOOD layer)" if b == nb - 1 and any(
                           'blood' in x[0].lower() for x in donor.names) else ""))
    return out


def budget_warnings(donor, st, vert_budget=None):
    """Size warnings.  There is no built-in size limit any more: nothing is reported unless the user set a vertex cap
    (vert_budget N) and the result is over it.  (The log still carries a plain NOTE for models above the size of the
    original files.)"""
    out = []
    if vert_budget and vert_budget > 0 and st.get('slots', 0) > vert_budget:
        out.append("The model has %d vertex slots, over your vertex cap of %d." % (st['slots'], vert_budget))
    return out


def optimize_dumy(src, dst, weld_angle='auto', log=print, vert_budget=None, tear_weights=True):
    """Rebuild an existing .dumy with welded vertices (fewer vertices, fewer strips, smaller file) without any
    other change: geometry, UVs, colours, weights, submesh assignment and texture names are kept."""
    import tempfile
    raw = open(src, 'rb').read()
    M = Dumy(raw)
    tmpd = tempfile.mkdtemp()
    tp = os.path.join(tmpd, 'o.dae')
    export_dae(M, tp)
    obj = parse_dae(tp)
    pre = dae_xform_preset(obj)
    xf = Xform(1.0, pre['flip'], pre['swap_yz'])
    # --optimize exists to shrink a model, so unlike --port it keeps a shrink target (1.5 x the largest known-good
    # model) unless a cap is given explicitly
    out, st = port_model(M, obj, default_mapping(obj, M), xf, names=[list(x) for x in M.names],
                         weight_mode='file', colour_mode='file', weld_angle=weld_angle, log=log,
                         vert_budget=vert_budget or int(1.5 * size_ref(M)), tear_weights=tear_weights)
    N = Dumy(out)
    bad = [r for r in check_rules(N) if r[1] == 'FAIL']
    if bad:
        raise DumyError("optimized file fails rule %s" % bad[0][0])
    with open(dst, 'wb') as fh:
        fh.write(out)
    log("Optimized %s: %d -> %d vertex slots, %d -> %d strips, %d -> %d bytes" % (
        os.path.basename(src), M.vcount, N.vcount, sum(len(b) for b in M.blocks), sum(len(b) for b in N.blocks),
        len(raw), len(out)))
    return M, N, st


# --------------------------------------------------------------------------
# COLLADA (.dae)
# --------------------------------------------------------------------------
# Axis convention of the files written here: Y_UP, the character faces +Z and its LEFT side is +X.
# This is a pure 180-degree rotation about X of the DUMY frame (x, -y, -z): no mirroring.
# The DUMY frame itself is  X = character's left, Y = down, Z = backwards  (checked on two files).
DAE_NS = "http://www.collada.org/2005/11/COLLADASchema"
DAE_PROFILE = "DUMY_PORT_TOOL"
_ID4 = [1.0, 0, 0, 0, 0, 1.0, 0, 0, 0, 0, 1.0, 0, 0, 0, 0, 1.0]


def _dae_sid(name, used):
    s = re.sub(r'[^A-Za-z0-9_]', '_', name) or 'joint'
    if s[0].isdigit():
        s = 'j_' + s
    base, k = s, 1
    while s in used:
        k += 1
        s = '%s_%d' % (base, k)
    used.add(s)
    return s


def _fl(vals):
    return ' '.join(repr(float(v)) for v in vals)


def _sub(parent, tag, text=None, **attrs):
    e = ET.SubElement(parent, tag, dict((k, str(v)) for k, v in attrs.items()))
    if text is not None:
        e.text = text
    return e


def _dae_source(mesh, sid, floats, stride, names, count=None):
    s = _sub(mesh, 'source', id=sid)
    _sub(s, 'float_array', _fl(floats), id=sid + '-array', count=len(floats))
    tc = _sub(s, 'technique_common')
    acc = _sub(tc, 'accessor', source='#' + sid + '-array', count=count if count is not None else len(floats) // stride,
               stride=stride)
    for n_ in names:
        _sub(acc, 'param', name=n_, type='float')
    return s


def export_dae(donor, path, log=lambda s: None):
    """Write the whole model of a Dumy as COLLADA 1.4.1: mesh, normals, UVs, per-corner colours (the file's
    own palette), one material per face block, skin controller with the decoded weights, the bone hierarchy
    and the DUMY-specific data (texture slots, palette, raw bone bytes) in <extra>."""
    def to(p):
        return (p[0], -p[1], -p[2])
    N = donor.real_vcount
    W = donor.weights()
    pos = [to(donor.pos(i)) for i in range(N)]
    nrm = [to(donor.normal_out(i)) for i in range(N)]
    nm = donor.model_name() or 'model'
    gid = 'geom_' + re.sub(r'[^A-Za-z0-9_]', '_', nm)

    root = ET.Element('COLLADA', {'xmlns': DAE_NS, 'version': '1.4.1'})
    asset = _sub(root, 'asset')
    c = _sub(asset, 'contributor')
    _sub(c, 'authoring_tool', 'DUMY Port Tool')
    now = datetime.datetime.now(datetime.timezone.utc).strftime('%Y-%m-%dT%H:%M:%SZ')
    _sub(asset, 'created', now)
    _sub(asset, 'modified', now)
    _sub(asset, 'unit', name='dumy_unit', meter='1')
    _sub(asset, 'up_axis', 'Y_UP')

    # materials: one per face block
    fx = _sub(root, 'library_effects')
    mats = _sub(root, 'library_materials')
    for b in range(len(donor.blocks)):
        e = _sub(fx, 'effect', id='fx_submesh_%d' % b)
        t = _sub(_sub(_sub(e, 'profile_COMMON'), 'technique', sid='common'), 'lambert')
        _sub(_sub(t, 'diffuse'), 'color', '0.8 0.8 0.8 1')
        m = _sub(mats, 'material', id='mat_submesh_%d' % b, name='submesh_%d' % b)
        _sub(m, 'instance_effect', url='#fx_submesh_%d' % b)

    # geometry
    geoms = _sub(root, 'library_geometries')
    g = _sub(geoms, 'geometry', id=gid, name=nm)
    mesh = _sub(g, 'mesh')
    _dae_source(mesh, gid + '-positions', [x for p in pos for x in p], 3, ['X', 'Y', 'Z'])
    _dae_source(mesh, gid + '-normals', [x for p in nrm for x in p], 3, ['X', 'Y', 'Z'])
    _dae_source(mesh, gid + '-texcoords', [x for u, v in donor.uvs for x in (u / 1024.0, 1.0 - v / 1024.0)],
                2, ['S', 'T'])
    has_col = donor.stride == 6 and donor.palette
    if has_col:
        _dae_source(mesh, gid + '-colors', [x / 255.0 for c_ in donor.palette for x in c_], 4, ['R', 'G', 'B', 'A'])
    vt = _sub(mesh, 'vertices', id=gid + '-vertices')
    _sub(vt, 'input', semantic='POSITION', source='#' + gid + '-positions')
    ntri = 0
    for b in range(len(donor.blocks)):
        tris = list(donor.triangles(b))
        if not tris:
            continue
        ntri += len(tris)
        tr = _sub(mesh, 'triangles', material='submesh_%d' % b, count=len(tris))
        _sub(tr, 'input', semantic='VERTEX', source='#' + gid + '-vertices', offset=0)
        _sub(tr, 'input', semantic='NORMAL', source='#' + gid + '-normals', offset=1)
        _sub(tr, 'input', semantic='TEXCOORD', source='#' + gid + '-texcoords', offset=2, set=0)
        if has_col:
            _sub(tr, 'input', semantic='COLOR', source='#' + gid + '-colors', offset=3, set=0)
        idx = []
        for t in tris:
            for c_ in (t[0], t[2], t[1]):           # reversed: the DUMY draws clockwise, COLLADA expects CCW
                idx += [c_[0], c_[0], c_[2]] + ([c_[1]] if has_col else [])
        _sub(tr, 'p', ' '.join(str(x) for x in idx))

    # skeleton: joint positions are ESTIMATED (centre of each bone's skin influence); the real bone
    # transforms are not decoded.  Only the names are used when a .dae is imported again.
    nb = donor.bone_count
    par = [donor.bones[i][1] if 0 <= donor.bones[i][1] < i else -1 for i in range(nb)]
    acc = {}
    for i, w in enumerate(W):
        for b_, x in w.items():
            a_ = acc.setdefault(b_, [0.0, 0.0, 0.0, 0.0])
            a_[0] += x * pos[i][0]
            a_[1] += x * pos[i][1]
            a_[2] += x * pos[i][2]
            a_[3] += x
    world = [None] * nb
    for b_ in range(nb):
        a_ = acc.get(b_)
        if a_ and a_[3] > 1e-9:
            world[b_] = (a_[0] / a_[3], a_[1] / a_[3], a_[2] / a_[3])
        else:
            world[b_] = world[par[b_]] if par[b_] >= 0 else (0.0, 0.0, 0.0)
    used = set()
    sids = [_dae_sid(donor.bones[b_][0], used) for b_ in range(nb)]
    kids = defaultdict(list)
    for b_ in range(nb):
        kids[par[b_]].append(b_)

    def joint_node(parent_el, b_):
        pw = world[par[b_]] if par[b_] >= 0 else (0.0, 0.0, 0.0)
        loc = [world[b_][k] - pw[k] for k in range(3)]
        n_ = _sub(parent_el, 'node', id='joint_%d' % b_, name=donor.bones[b_][0], sid=sids[b_], type='JOINT')
        _sub(n_, 'matrix', _fl([1, 0, 0, loc[0], 0, 1, 0, loc[1], 0, 0, 1, loc[2], 0, 0, 0, 1]), sid='transform')
        for k_ in kids.get(b_, []):
            joint_node(n_, k_)
        ex = _sub(n_, 'extra')
        te = _sub(ex, 'technique', profile=DAE_PROFILE)
        raw = bytes(donor.data[donor.bone_ptr + 80 * b_:donor.bone_ptr + 80 * b_ + 80])
        _sub(te, 'bone', index=b_, parent_index=donor.bones[b_][1], raw80=raw.hex())
        return n_

    # controller
    ctrls = _sub(root, 'library_controllers')
    cid = 'skin_' + gid
    ct = _sub(ctrls, 'controller', id=cid, name=nm + '_skin')
    sk = _sub(ct, 'skin', source='#' + gid)
    _sub(sk, 'bind_shape_matrix', _fl(_ID4))
    s = _sub(sk, 'source', id=cid + '-joints')
    _sub(s, 'Name_array', ' '.join(sids), id=cid + '-joints-array', count=nb)
    a = _sub(_sub(s, 'technique_common'), 'accessor', source='#' + cid + '-joints-array', count=nb, stride=1)
    _sub(a, 'param', name='JOINT', type='name')
    s = _sub(sk, 'source', id=cid + '-bindposes')
    ibm = []
    for b_ in range(nb):
        x, y, z = world[b_]
        ibm += [1, 0, 0, -x, 0, 1, 0, -y, 0, 0, 1, -z, 0, 0, 0, 1]
    _sub(s, 'float_array', _fl(ibm), id=cid + '-bindposes-array', count=len(ibm))
    a = _sub(_sub(s, 'technique_common'), 'accessor', source='#' + cid + '-bindposes-array', count=nb, stride=16)
    _sub(a, 'param', name='TRANSFORM', type='float4x4')
    wl, vc, vv = [], [], []
    for i in range(N):
        infl = sorted(((b_, x) for b_, x in W[i].items() if x > 1e-7), key=lambda kv: -kv[1])
        vc.append(str(len(infl)))
        for b_, x in infl:
            vv += [str(b_), str(len(wl))]
            wl.append(x)
    s = _sub(sk, 'source', id=cid + '-weights')
    _sub(s, 'float_array', ' '.join('%.9g' % x for x in wl), id=cid + '-weights-array', count=len(wl))
    a = _sub(_sub(s, 'technique_common'), 'accessor', source='#' + cid + '-weights-array', count=len(wl), stride=1)
    _sub(a, 'param', name='WEIGHT', type='float')
    j = _sub(sk, 'joints')
    _sub(j, 'input', semantic='JOINT', source='#' + cid + '-joints')
    _sub(j, 'input', semantic='INV_BIND_MATRIX', source='#' + cid + '-bindposes')
    vw = _sub(sk, 'vertex_weights', count=N)
    _sub(vw, 'input', semantic='JOINT', source='#' + cid + '-joints', offset=0)
    _sub(vw, 'input', semantic='WEIGHT', source='#' + cid + '-weights', offset=1)
    _sub(vw, 'vcount', ' '.join(vc))
    _sub(vw, 'v', ' '.join(vv))

    # scene
    scenes = _sub(root, 'library_visual_scenes')
    vs = _sub(scenes, 'visual_scene', id='Scene', name='Scene')
    arm = _sub(vs, 'node', id='Armature', name='Armature', type='NODE')
    roots = kids.get(-1, [])
    for r_ in roots:
        joint_node(arm, r_)
    mn = _sub(vs, 'node', id='model_node', name=nm, type='NODE')
    ic = _sub(mn, 'instance_controller', url='#' + cid)
    for r_ in roots:
        _sub(ic, 'skeleton', '#joint_%d' % r_)
    mt = _sub(_sub(ic, 'bind_material'), 'technique_common')
    for b in range(len(donor.blocks)):
        _sub(mt, 'instance_material', symbol='submesh_%d' % b, target='#mat_submesh_%d' % b)
    sc = _sub(root, 'scene')
    _sub(sc, 'instance_visual_scene', url='#Scene')

    # DUMY-specific data
    ex = _sub(root, 'extra')
    te = _sub(ex, 'technique', profile=DAE_PROFILE)
    _sub(te, 'note', "Exported by DUMY Port Tool. Axes: Y up, character faces +Z, character's left is +X "
                     "(the DUMY frame rotated 180 degrees about X). Joint positions are ESTIMATED from the skin "
                     "weights (centre of each bone's influence); the file's bone transforms are not decoded and "
                     "are never read back. Bones are matched by name when this file is imported.")
    _sub(te, 'dumy', model_name=nm, vertices=N, slots=donor.vcount, groups=len(donor.groups),
         blocks=len(donor.blocks), bones=nb, uvs=len(donor.uvs), triangles=ntri,
         bbox=' '.join(repr(float(x)) for x in donor.bbox))
    ts = _sub(te, 'texture_slots')
    for i, (n_, e_, _f) in enumerate(donor.names):
        _sub(ts, 'slot', index=i, name=n_, ext=e_)
    pe = _sub(te, 'palette')
    for i, c_ in enumerate(donor.palette):
        _sub(pe, 'color', index=i, rgba=' '.join(str(x) for x in c_))
    if hasattr(ET, 'indent'):
        ET.indent(root)
    ET.ElementTree(root).write(path, encoding='utf-8', xml_declaration=True)
    log("DAE written: %d vertices, %d triangles, %d joints, %d weight entries, %d materials" %
        (N, ntri, nb, len(wl), len(donor.blocks)))


# ---- reading -----------------------------------------------------------------
def _mm4(a, b):
    return [sum(a[r * 4 + k] * b[k * 4 + c] for k in range(4)) for r in range(4) for c in range(4)]


def _apply4(m, p):
    x, y, z = p
    return (m[0] * x + m[1] * y + m[2] * z + m[3], m[4] * x + m[5] * y + m[6] * z + m[7],
            m[8] * x + m[9] * y + m[10] * z + m[11])


def _normal_mat(m):
    a, b, c, d, e, f, g, h, i = m[0], m[1], m[2], m[4], m[5], m[6], m[8], m[9], m[10]
    det = a * (e * i - f * h) - b * (d * i - f * g) + c * (d * h - e * g)
    if abs(det) < 1e-12:
        return (1, 0, 0, 0, 1, 0, 0, 0, 1)
    iv = [(e * i - f * h) / det, (c * h - b * i) / det, (b * f - c * e) / det,
          (f * g - d * i) / det, (a * i - c * g) / det, (c * d - a * f) / det,
          (d * h - e * g) / det, (b * g - a * h) / det, (a * e - b * d) / det]
    return (iv[0], iv[3], iv[6], iv[1], iv[4], iv[7], iv[2], iv[5], iv[8])


def _xf_normal(nm, n):
    q = (nm[0] * n[0] + nm[1] * n[1] + nm[2] * n[2], nm[3] * n[0] + nm[4] * n[1] + nm[5] * n[2],
         nm[6] * n[0] + nm[7] * n[1] + nm[8] * n[2])
    l = math.sqrt(q[0] ** 2 + q[1] ** 2 + q[2] ** 2) or 1.0
    return (q[0] / l, q[1] / l, q[2] / l)


def _node_matrix(el):
    m = list(_ID4)
    for ch in el:
        t = _tag(ch)
        v = [float(x) for x in (ch.text or '').split()]
        if t == 'matrix' and len(v) == 16:
            m = _mm4(m, v)
        elif t == 'translate' and len(v) == 3:
            m = _mm4(m, [1, 0, 0, v[0], 0, 1, 0, v[1], 0, 0, 1, v[2], 0, 0, 0, 1])
        elif t == 'scale' and len(v) == 3:
            m = _mm4(m, [v[0], 0, 0, 0, 0, v[1], 0, 0, 0, 0, v[2], 0, 0, 0, 0, 1])
        elif t == 'rotate' and len(v) == 4:
            x, y, z, ang = v
            l = math.sqrt(x * x + y * y + z * z) or 1.0
            x, y, z = x / l, y / l, z / l
            cs, sn = math.cos(math.radians(ang)), math.sin(math.radians(ang))
            oc = 1 - cs
            m = _mm4(m, [cs + x * x * oc, x * y * oc - z * sn, x * z * oc + y * sn, 0,
                         y * x * oc + z * sn, cs + y * y * oc, y * z * oc - x * sn, 0,
                         z * x * oc - y * sn, z * y * oc + x * sn, cs + z * z * oc, 0, 0, 0, 0, 1])
    return m


def _tag(e):
    t = e.tag
    return t.split('}', 1)[1] if isinstance(t, str) and '}' in t else t


def _norm_bone(s):
    s = re.sub(r'\.\d{3}$', '', s.strip())
    return re.sub(r'[\s_.]+', ' ', s).strip().lower()


def _read_source(el):
    arr = None
    for ch in el:
        if _tag(ch) in ('float_array', 'int_array', 'Name_array', 'IDREF_array', 'bool_array'):
            arr = ch
            break
    if arr is None:
        return None
    txt = (arr.text or '').split()
    kind = _tag(arr)
    data = [float(t) for t in txt] if kind == 'float_array' else ([int(t) for t in txt] if kind == 'int_array' else txt)
    stride, off, params = 1, 0, []
    for acc in el.iter():
        if _tag(acc) == 'accessor':
            stride = int(acc.get('stride', '1'))
            off = int(acc.get('offset', '0'))
            params = [p.get('name') for p in acc if _tag(p) == 'param']
            break
    return dict(data=data, stride=stride, offset=off, params=params)


def _src_items(src, n_comp):
    d, st, off = src['data'], src['stride'], src['offset']
    cnt = (len(d) - off) // st
    return [tuple(d[off + k * st:off + k * st + n_comp]) for k in range(cnt)]


def parse_dae(path):
    """Read a COLLADA file into an ObjModel (positions, normals, UVs, per-corner colours, triangles per
    material) plus skin weights by joint name.  Scene-node and bind-shape transforms are applied."""
    tree = ET.parse(path)
    root = tree.getroot()
    ids = {}
    for e in root.iter():
        i_ = e.get('id')
        if i_ is not None:
            ids[i_] = e

    def ref(u):
        return ids.get(u[1:] if u.startswith('#') else u)
    obj = ObjModel()
    obj.skin = {}
    obj.VC = []
    meta = obj.meta = dict(format='dae', up_axis='Y_UP', unit=1.0, joints=[], tex_slots=None, palette=None,
                           has_skin=False, has_colors=False, meshes=[], estimated_skeleton=False)
    for e in root.iter():
        t = _tag(e)
        if t == 'up_axis' and e.text:
            meta['up_axis'] = e.text.strip().upper()
        elif t == 'unit' and e.get('meter'):
            try:
                meta['unit'] = float(e.get('meter'))
            except ValueError:
                pass
        elif t == 'technique' and e.get('profile') == DAE_PROFILE and _tag(e) == 'technique':
            for ch in e:
                if _tag(ch) == 'texture_slots':
                    meta['tex_slots'] = [(s.get('name', ''), s.get('ext', '')) for s in ch if _tag(s) == 'slot']
                elif _tag(ch) == 'palette':
                    meta['palette'] = [tuple(int(x) for x in c.get('rgba', '').split()) for c in ch]
                elif _tag(ch) == 'note' and 'ESTIMATED' in (ch.text or ''):
                    meta['estimated_skeleton'] = True
    matname = {}
    for e in root.iter():
        if _tag(e) == 'material' and e.get('id'):
            matname[e.get('id')] = e.get('name') or e.get('id')

    # textures: material -> effect -> diffuse <texture> -> sampler -> surface -> image
    def img_stem(img):
        f = None
        for c in img.iter():
            if _tag(c) == 'ref' and c.text and c.text.strip():
                f = c.text
                break
            if _tag(c) == 'init_from' and c.text and c.text.strip():
                f = c.text
                break
        f = f or img.get('name') or img.get('id') or ''
        f = urllib.parse.unquote(f.strip().replace('\\', '/')).split('?')[0].split('/')[-1]
        return f.rsplit('.', 1)[0] if '.' in f else f

    def effect_texture(eff):
        tex = None
        for d_ in eff.iter():
            if _tag(d_) == 'diffuse':
                tex = next((x for x in d_.iter() if _tag(x) == 'texture'), None)
                if tex is not None:
                    break
        if tex is None:
            tex = next((x for x in eff.iter() if _tag(x) == 'texture'), None)
        if tex is None:
            return None
        sids = dict((x.get('sid'), x) for x in eff.iter() if _tag(x) == 'newparam' and x.get('sid'))
        cur = tex.get('texture')
        for _ in range(6):
            if cur in sids:
                nxt = None
                for ch in sids[cur].iter():
                    if _tag(ch) in ('source', 'init_from') and ch.text and ch.text.strip():
                        nxt = ch.text.strip()
                        break
                if nxt is None:
                    break
                cur = nxt
            else:
                break
        img = ids.get(cur)
        if img is not None and _tag(img) == 'image':
            return img_stem(img)
        return None
    mat_tex = {}
    for e in root.iter():
        if _tag(e) == 'material' and e.get('id'):
            ie = next((x for x in e if _tag(x) == 'instance_effect'), None)
            if ie is not None:
                eff = ref(ie.get('url') or '')
                st_ = effect_texture(eff) if eff is not None else None
                if st_:
                    mat_tex[e.get('name') or e.get('id')] = st_
                    mat_tex.setdefault(e.get('id'), st_)
    meta['images'] = [img_stem(e) for e in root.iter() if _tag(e) == 'image']

    # joint nodes: sid / id / name -> display name
    jname = {}
    for e in root.iter():
        if _tag(e) == 'node' and (e.get('type') or '').upper() == 'JOINT':
            nm_ = e.get('name') or e.get('sid') or e.get('id')
            for k in (e.get('sid'), e.get('id'), e.get('name')):
                if k:
                    jname.setdefault(k, nm_)

    # collect geometry instances with their world matrices
    inst = []

    def walk(el, m):
        for ch in el:
            if _tag(ch) != 'node':
                continue
            wm = _mm4(m, _node_matrix(ch))
            for ic in ch:
                tg = _tag(ic)
                if tg in ('instance_geometry', 'instance_controller'):
                    bm = {}
                    for im in ic.iter():
                        if _tag(im) == 'instance_material':
                            tgt = (im.get('target') or '').lstrip('#')
                            bm[im.get('symbol')] = matname.get(tgt, tgt or im.get('symbol'))
                    inst.append((tg, (ic.get('url') or '').lstrip('#'), wm, bm, ch.get('name') or ch.get('id')))
            walk(ch, wm)
    scene_root = None
    for e in root.iter():
        if _tag(e) == 'instance_visual_scene':
            scene_root = ref(e.get('url') or '')
    if scene_root is None:
        for e in root.iter():
            if _tag(e) == 'visual_scene':
                scene_root = e
                break
    if scene_root is not None:
        walk(scene_root, list(_ID4))
    if not inst:   # no scene: take every geometry as it is
        for e in root.iter():
            if _tag(e) == 'geometry':
                inst.append(('instance_geometry', e.get('id'), list(_ID4), {}, e.get('name') or e.get('id')))
    if not inst:
        raise DumyError("The .dae contains no geometry")

    for kind, url, wm, bm, nodename in inst:
        skin_el = None
        geo_el = ref(url)
        bind_shape = list(_ID4)
        if kind == 'instance_controller':
            ctl = geo_el
            if ctl is None:
                continue
            for ch in ctl:
                if _tag(ch) == 'skin':
                    skin_el = ch
            if skin_el is None:
                continue
            geo_el = ref(skin_el.get('source') or '')
            for ch in skin_el:
                if _tag(ch) == 'bind_shape_matrix':
                    v = [float(x) for x in (ch.text or '').split()]
                    if len(v) == 16:
                        bind_shape = v
        if geo_el is None:
            continue
        mesh = next((c for c in geo_el if _tag(c) == 'mesh'), None)
        if mesh is None:
            continue
        full = _mm4(wm, bind_shape)
        nmat = _normal_mat(full)
        srcs = dict((c.get('id'), _read_source(c)) for c in mesh if _tag(c) == 'source')
        vert_el = next((c for c in mesh if _tag(c) == 'vertices'), None)
        vinputs = {}
        if vert_el is not None:
            for c in vert_el:
                if _tag(c) == 'input':
                    vinputs[c.get('semantic')] = (c.get('source') or '').lstrip('#')
        base_v, base_vt, base_vn, base_vc = len(obj.V), len(obj.VT), len(obj.VN), len(obj.VC)
        pos_src = srcs.get(vinputs.get('POSITION'))
        if pos_src is None:
            continue
        P = _src_items(pos_src, 3)
        obj.V += [_apply4(full, p) for p in P]
        # source pools used by this mesh, read lazily (pools are appended once per distinct source id)
        pools = {}

        def pool(sid, ncomp, kindname):
            if (kindname, sid) in pools:
                return pools[(kindname, sid)]
            s = srcs.get(sid)
            if s is None:
                return None
            items = _src_items(s, ncomp)
            if kindname == 'N':
                items = [_xf_normal(nmat, n) for n in items]
                base = len(obj.VN)
                obj.VN += items
            elif kindname == 'T':
                base = len(obj.VT)
                obj.VT += [(it[0], it[1]) for it in items]
            else:
                base = len(obj.VC)
                obj.VC += [(tuple(it) + (1.0,))[:4] for it in items]
                meta['has_colors'] = True
            pools[(kindname, sid)] = (base, len(items))
            return pools[(kindname, sid)]
        # per-vertex attributes declared inside <vertices>
        vattr = {}
        for sem, kn in (('NORMAL', 'N'), ('TEXCOORD', 'T'), ('COLOR', 'C')):
            sid_ = vinputs.get(sem)
            if sid_ and srcs.get(sid_):
                nc = {'N': 3, 'T': 2, 'C': min(4, max(3, srcs[sid_]['stride']))}[kn]
                p_ = pool(sid_, nc, kn)
                if p_:
                    vattr[sem] = p_[0]
        ntri_mesh = 0
        for prim in mesh:
            pt = _tag(prim)
            if pt not in ('triangles', 'polylist', 'polygons'):
                continue
            ins = []
            for c in prim:
                if _tag(c) == 'input':
                    ins.append((c.get('semantic'), int(c.get('offset', '0')), (c.get('source') or '').lstrip('#'),
                                int(c.get('set', '0'))))
            if not ins:
                continue
            stride = max(o for _, o, _, _ in ins) + 1
            off = {}
            sets = {}
            for sem, o, s, st in ins:
                if sem not in off or st < sets.get(sem, 99):
                    off[sem] = (o, s)
                    sets[sem] = st
            pool_idx = {}
            for sem, kn, nc in (('NORMAL', 'N', 3), ('TEXCOORD', 'T', 2), ('COLOR', 'C', 4)):
                if sem in off:
                    ncs = nc
                    if sem == 'COLOR' and srcs.get(off[sem][1]):
                        ncs = min(4, max(3, srcs[off[sem][1]]['stride']))
                    p_ = pool(off[sem][1], ncs, kn)
                    if p_:
                        pool_idx[sem] = p_[0]
            if 'VERTEX' not in off:
                continue
            sym = prim.get('material')
            gname = bm.get(sym) or sym or nodename or 'default'
            # indices
            if pt == 'triangles':
                p = next((c for c in prim if _tag(c) == 'p'), None)
                flat = [int(x) for x in (p.text or '').split()] if p is not None else []
                polys = [flat[i:i + 3 * stride] for i in range(0, len(flat), 3 * stride)]
            elif pt == 'polylist':
                vcl = next((c for c in prim if _tag(c) == 'vcount'), None)
                p = next((c for c in prim if _tag(c) == 'p'), None)
                counts = [int(x) for x in (vcl.text or '').split()] if vcl is not None else []
                flat = [int(x) for x in (p.text or '').split()] if p is not None else []
                polys, pos_ = [], 0
                for cnt in counts:
                    polys.append(flat[pos_:pos_ + cnt * stride])
                    pos_ += cnt * stride
            else:
                polys = [[int(x) for x in (c.text or '').split()] for c in prim if _tag(c) == 'p']
            lst = obj.groups.setdefault(gname, [])
            for poly in polys:
                ncorn = len(poly) // stride
                corners = []
                for k in range(ncorn):
                    row = poly[k * stride:(k + 1) * stride]
                    vi = row[off['VERTEX'][0]]
                    ni = ti = ci = None
                    if 'NORMAL' in pool_idx:
                        ni = pool_idx['NORMAL'] + row[off['NORMAL'][0]]
                    elif 'NORMAL' in vattr:
                        ni = vattr['NORMAL'] + vi
                    if 'TEXCOORD' in pool_idx:
                        ti = pool_idx['TEXCOORD'] + row[off['TEXCOORD'][0]]
                    elif 'TEXCOORD' in vattr:
                        ti = vattr['TEXCOORD'] + vi
                    if 'COLOR' in pool_idx:
                        ci = pool_idx['COLOR'] + row[off['COLOR'][0]]
                    elif 'COLOR' in vattr:
                        ci = vattr['COLOR'] + vi
                    corners.append((base_v + vi, ti, ni, ci))
                for k in range(1, ncorn - 1):
                    lst.append((corners[0], corners[k], corners[k + 1]))
                    ntri_mesh += 1
        meta['meshes'].append((geo_el.get('name') or geo_el.get('id'), len(P), ntri_mesh))
        # skin weights
        if skin_el is not None:
            jsrc = None
            for c in skin_el:
                if _tag(c) == 'joints':
                    for i_ in c:
                        if _tag(i_) == 'input' and i_.get('semantic') == 'JOINT':
                            jsrc = _read_source(ref(i_.get('source')))
            vw = next((c for c in skin_el if _tag(c) == 'vertex_weights'), None)
            if jsrc is not None and vw is not None:
                jn = [jname.get(str(x), str(x)) for x in jsrc['data']]
                meta['joints'] = list(jn) if not meta['joints'] else meta['joints']
                wins = {}
                for c in vw:
                    if _tag(c) == 'input':
                        wins[c.get('semantic')] = (int(c.get('offset', '0')), ref(c.get('source')))
                vcl = next((c for c in vw if _tag(c) == 'vcount'), None)
                vv = next((c for c in vw if _tag(c) == 'v'), None)
                wsrc = _read_source(wins['WEIGHT'][1]) if 'WEIGHT' in wins else None
                if vcl is not None and vv is not None and wsrc is not None and 'JOINT' in wins:
                    counts = [int(x) for x in (vcl.text or '').split()]
                    flat = [int(x) for x in (vv.text or '').split()]
                    st = max(o for o, _ in wins.values()) + 1
                    wd = wsrc['data']
                    pos_ = 0
                    for k, cnt in enumerate(counts):
                        d = {}
                        for _ in range(cnt):
                            row = flat[pos_:pos_ + st]
                            pos_ += st
                            j_, w_ = row[wins['JOINT'][0]], row[wins['WEIGHT'][0]]
                            if j_ >= 0 and w_ < len(wd) and wd[w_] > 0:
                                d[jn[j_]] = d.get(jn[j_], 0.0) + wd[w_]
                        if d:
                            obj.skin[base_v + k] = d
                    meta['has_skin'] = True
    if not obj.groups or not obj.V:
        raise DumyError("The .dae contains no triangles")
    meta['group_textures'] = dict((g_, mat_tex[g_]) for g_ in obj.groups if g_ in mat_tex)
    if not meta['has_skin']:
        obj.skin = None
    if not obj.VC:
        obj.VC = None
    return obj


def dae_xform_preset(obj):
    """Xform flips that map a COLLADA model into the DUMY frame (X=left, Y=down, Z=back)."""
    up = (getattr(obj, 'meta', {}) or {}).get('up_axis', 'Y_UP')
    if up == 'Z_UP':        # Z up, character faces -Y, left = +X  ->  (x, -z, y)
        return dict(flip=(False, True, False), swap_yz=True)
    if up == 'X_UP':
        return dict(flip=(False, True, True), swap_yz=False)
    return dict(flip=(False, True, True), swap_yz=False)


# --------------------------------------------------------------------------
# reports
# --------------------------------------------------------------------------
def donor_report(d):
    L_ = []
    L_.append("DUMY container")
    L_.append("  YOBJ payload size   0x%X  (POF0 at 0x%X, %d pointer locations)" %
              (d.yobj_size, d.pof_off, len(d.ptrs)))
    L_.append("  bones               %d  @0x%X" % (d.bone_count, d.bone_ptr))
    L_.append("  materials           %d  @0x%X" % (d.mat_count, d.mat_ptr))
    L_.append("  texture-name slots  %d  @0x%X" % (d.name_count, d.name_ptr))
    L_.append("")
    L_.append("Model info @0x%X" % d.mp)
    L_.append("  vertices            %d  (%d real + %d dummy)" % (d.vcount, d.real_vcount, d.extra))
    L_.append("  UVs                 %d" % len(d.uvs))
    L_.append("  skin groups         %d" % len(d.groups))
    L_.append("  face blocks         %d  (corner stride %d bytes: %s)" %
              (len(d.blocks), d.stride, "vertex/colour/uv" if d.stride == 6 else "vertex/uv"))
    L_.append("  vertex colours      %d" % d.ncolors)
    L_.append("")
    c = Counter(g.C for g in d.groups)
    cv = Counter()
    for g in d.groups:
        cv[g.C] += g.D
    L_.append("Skinning")
    for k in sorted(c):
        L_.append("  %d-influence groups: %4d  (%d vertices)" % (k, c[k], cv[k]))
    L_.append("")
    L_.append("Submeshes (face blocks)")
    for b, strips in enumerate(d.blocks):
        tri = sum(len(s) - 2 for s in strips)
        L_.append("  [%d] %5d tris in %4d strips, %5d vertices, vertex alpha idx %s%s" %
                  (b, tri, len(strips), len(d.block_vertices(b)),
                   ",".join("%d" % k for k in sorted(set(d.vcol.get(v, 0) for v in d.block_vertices(b)))),
                   "   <- blood" if b == len(d.blocks) - 1 and
                   any('blood' in n[0].lower() for n in d.names) else ""))
    L_.append("")
    L_.append("Texture-name slots")
    for i, (n, e, t) in enumerate(d.names):
        L_.append("  [%2d] %s.%s" % (i, n, e))
    prob = d.layout_problem()
    L_.append("")
    L_.append("")
    L_.append("Vertex colour palette (%d entries): " % len(d.palette) + ", ".join(
        "%d=%s" % (i, ("a%d" % c[3]) if c[:3] == (255, 255, 255) else "%d,%d,%d,a%d" % c) for i, c in enumerate(d.palette)))
    L_.append("")
    L_.append(weight_report(d, top=12))
    L_.append("")
    L_.append(rules_report(d))
    L_.append("")
    L_.append("Layout check: " + ("OK" if not prob else "UNSUPPORTED - " + prob))
    v = d.validate()
    L_.append("Pointer check: " + ("OK" if not v else "; ".join(v[:5])))
    return "\n".join(L_)


def rules_report(d):
    R = check_rules(d)
    L_ = ["Decoded format rules on this file  (%d pass, %d fail)" %
          (sum(1 for r in R if r[1] == 'PASS'), sum(1 for r in R if r[1] == 'FAIL'))]
    for rid, st, txt in R:
        L_.append("  [%s] %-24s %s" % (st, rid, txt))
    return "\n".join(L_)


def compare_files(pa, pb):
    """Field-level comparison of two .dumy files: shows which header / material / name fields
    differ and whether the decoded rules explain the differences."""
    A, B = Dumy(open(pa, 'rb').read()), Dumy(open(pb, 'rb').read())
    L_ = ["A = %s   B = %s" % (os.path.basename(pa), os.path.basename(pb)), ""]

    def row(lbl, a, b, note=""):
        L_.append("  %-26s %-22s %-22s %s%s" % (lbl, a, b, "" if a == b else "<- differs ", note))
    L_.append("root / model info")
    for off in range(0, 0x80, 4):
        wa, wb = A.u32(off), B.u32(off)
        if wa != wb:
            L_.append("  payload+0x%02X  %08X  %08X" % (off, wa, wb))
    L_.append("")
    row("vertices (real+dummy)", "%d+%d" % (A.real_vcount, A.extra), "%d+%d" % (B.real_vcount, B.extra))
    row("uvs", len(A.uvs), len(B.uvs))
    row("skin groups", len(A.groups), len(B.groups))
    row("face blocks", len(A.blocks), len(B.blocks))
    row("bones", A.bone_count, B.bone_count)
    row("materials", A.mat_count, B.mat_count)
    row("name slots", A.name_count, B.name_count)
    row("palette alphas", str([c[3] for c in A.palette]), str([c[3] for c in B.palette]))
    row("bbox block", str(tuple(round(x, 2) for x in A.bbox)), str(tuple(round(x, 2) for x in B.bbox)))
    L_.append("")
    for nm_, M in (("A", A), ("B", B)):
        L_.append("rules on %s:" % nm_)
        L_.append(rules_report(M))
        L_.append("")
    bn = [i for i in range(min(A.bone_count, B.bone_count)) if A.bones[i] != B.bones[i]]
    L_.append("bone table: %s" % ("identical names/parents" if not bn and A.bone_count == B.bone_count
                                  else "%d bones differ (first: %s)" % (len(bn), bn[:8])))
    return "\n".join(L_)


def load_model(path, mode='object'):
    """Load a custom model: .obj or .dae (COLLADA)."""
    if path.lower().endswith('.dae'):
        return parse_dae(path)
    return parse_obj(path, mode)


def maybe_bake_atlas(path, obj, log=print):
    """The DUMY has ONE colour texture for the whole model.  When the .dae uses several textures, bake them into
    one atlas (needs Pillow + atlas_dae.py next to this tool + the images next to the .dae) and return the path
    of the new single-material .dae; otherwise None."""
    gt = (getattr(obj, 'meta', {}) or {}).get('group_textures') or {}
    if len(set(gt.values())) < 2 or path.lower().endswith('_atlas.dae'):
        return None
    try:
        sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
        import atlas_dae
        log("The .dae uses %d textures (%s) but the game has one colour texture: building an atlas ..." %
            (len(set(gt.values())), ", ".join(sorted(set(gt.values())))))
        return atlas_dae.build_atlas(path, 'ATLAS', 1024, log)
    except ImportError as e:
        log("Cannot build the atlas automatically (%s). Install Pillow (pip install pillow) and keep atlas_dae.py "
            "next to this tool, or merge the textures yourself." % e)
    except Exception as e:
        log("Atlas not built: %s" % e)
    return None


def apply_dae_texture_names(obj, names, max_bytes=10, log=print):
    """Texture-slot names stored by this tool's .dae export, applied to a names list in place."""
    ts = (getattr(obj, 'meta', {}) or {}).get('tex_slots')
    if not ts:
        return
    if len(ts) != len(names):
        log("The .dae lists %d texture slots, the donor has %d: slot names left unchanged" % (len(ts), len(names)))
        return
    for i, (n_, e_) in enumerate(ts):
        if len(n_.encode('latin1', 'replace')) + len(e_.encode('latin1', 'replace')) + 2 > max_bytes:
            log("Texture slot %d name '%s.%s' is longer than %d bytes: left unchanged" % (i, n_, e_, max_bytes))
            continue
        names[i][0], names[i][1] = n_, e_


PER_SUBMESH_SLOTS = True     # each colour submesh gets its own texture slot (set False = donor behaviour, all slot 0)


def texture_slot_plan(obj, mapping, donor):
    """(block_slots, slot_stems).  Every face block samples ONE texture slot (u8 at +0x47 of its material blob).
    Colour blocks that hold geometry get the colour slots 0,1,2.. in block order (the last colour slot is shared
    if there are more blocks than slots), the blood block gets the first blood slot.  slot_stems = {slot: texture}.
    Empty when the model has no textured materials."""
    gt = (getattr(obj, 'meta', {}) or {}).get('group_textures') or {}
    if not gt:
        return {}, {}
    nb = len(donor.blocks)
    blood_slots = [i for i, n_ in enumerate(donor.names) if 'blood' in n_[0].lower()]
    col_slots = [i for i in range(len(donor.names)) if i not in blood_slots]
    blood_blk = nb - 1 if (blood_slots and nb > 1) else None
    if blood_blk is not None and any(cfg.get('block') == blood_blk and 'blood' not in g_.lower() and gt.get(g_)
                                     for g_, cfg in mapping.items()):
        blood_blk = None          # a colour material was placed in the last submesh: it is used as a colour layer
    votes = defaultdict(Counter)
    for gname, cfg in mapping.items():
        blk, stem = cfg.get('block'), gt.get(gname)
        if blk is not None and stem and gname in obj.groups:
            votes[blk][stem] += len(obj.groups[gname])
    block_slots, stems = {}, {}
    k = 0
    for blk in sorted(votes):
        stem = votes[blk].most_common(1)[0][0]
        if blk == blood_blk:
            slot = blood_slots[0]
        elif col_slots:
            # The donor uses ONE colour slot (byte 0) for all colour submeshes; slots 0-9 look like runtime
            # colour variants of the same texture, so other slot numbers are not safe (crash). Keep it.
            slot = col_slots[min(k, len(col_slots) - 1)] if PER_SUBMESH_SLOTS else col_slots[0]
            k += 1
        else:
            continue
        block_slots[blk] = slot
        if slot not in stems:
            stems[slot] = stem
    return block_slots, stems


def auto_texture_names(obj, mapping, donor, names, max_bytes=10, log=print):
    """Assign the donor's texture-name slots from the textures of the model's materials (.dae), following
    texture_slot_plan().  Unused colour slots repeat the biggest colour texture, unused blood slots the blood
    texture.  Returns the number of slots changed."""
    block_slots, stems = texture_slot_plan(obj, mapping, donor)
    if not stems:
        return 0
    gt = obj.meta['group_textures']
    for gname, cfg in mapping.items():
        pass
    nb = len(donor.blocks)
    blood_blk = nb - 1 if (nb > 1 and any('blood' in n_[0].lower() for n_ in donor.names)) else None
    if blood_blk is not None and any(c_.get('block') == blood_blk and 'blood' not in g_.lower() and gt.get(g_)
                                     for g_, c_ in mapping.items()):
        blood_blk = None
    tris = Counter()
    for gname, cfg in mapping.items():
        if gt.get(gname) and cfg.get('block') != blood_blk and gname in obj.groups:
            tris[gt[gname]] += len(obj.groups[gname])
    main_tex = tris.most_common(1)[0][0] if tris else None
    blood_tex = next((stems[sl] for b_, sl in block_slots.items() if b_ == blood_blk), None)
    for gname, cfg in mapping.items():
        blk = cfg.get('block')
        if blk in block_slots and gt.get(gname) and gt[gname] != stems[block_slots[blk]]:
            log("Material '%s' (texture %s) shares submesh %d with '%s' and will show that texture instead: the donor "
                "has only %d colour submeshes. Merge materials/textures in Blender to avoid this." %
                (gname, gt[gname], blk, stems[block_slots[blk]], len([b_ for b_ in range(nb) if b_ != blood_blk])))
    # A slot holds 'name\0ext\0' in max_bytes bytes, so a long texture name (e.g. 'Jpants' + 'tga' = 11 > 10) cannot
    # be written as is.  Skipping it left that slot with the donor's old name, i.e. one texture silently missing.
    # Shorten it instead (unique among the textures in use) and tell the user which file name the game will look for.
    used = set(s_.lower() for s_ in stems.values())
    shortened = {}

    def fit(stem, ext):
        room = max_bytes - len(ext) - 2
        if len(stem.encode('latin1', 'replace')) <= room:
            return stem
        key = (stem, room)
        if key not in shortened:
            cand = stem[:max(room, 1)]
            n = 0
            while cand.lower() in used and cand.lower() != stem.lower() and n < 99:
                n += 1
                sfx = str(n)
                cand = stem[:max(room - len(sfx), 1)] + sfx
            used.add(cand.lower())
            shortened[key] = cand
        return shortened[key]

    changed, assigned = 0, []
    for i, dn in enumerate(donor.names):
        is_blood = 'blood' in dn[0].lower()
        stem = stems.get(i) or (blood_tex if is_blood else main_tex)
        if not stem:
            continue
        ext = names[i][1]
        full = stem
        stem = fit(full, ext)
        if stem != full and ('log', full) not in shortened:
            shortened[('log', full)] = stem
            log("Texture '%s' does not fit a %d-byte slot ('%s.%s' needs %d bytes), so slot %d is written as '%s.%s'. "
                "Rename the image to '%s.%s' (and in the DAE/Blender material) - or tick 'allow up to 16 bytes' "
                "(not verified in any sample) to keep the full name." % (
                    full, max_bytes, full, ext, len(full) + len(ext) + 2, i, stem, ext, stem, ext))
        assigned.append("%d=%s" % (i, stem))
        if names[i][0] != stem:
            names[i][0] = stem
            changed += 1
    log("Submesh -> texture slot: %s" % ", ".join("%d->%d" % kv for kv in sorted(block_slots.items())))
    log("Texture slots assigned: %s" % ", ".join(assigned))
    return changed


def dae_summary(obj):
    m = obj.meta
    return ("COLLADA loaded: up axis %s, unit %g m, %d mesh(es) %s | %d verts, %d normals, %d uvs, %s colours, "
            "%d triangles in %d material group(s): %s | skin weights: %s%s | texture slots: %s" % (
                m['up_axis'], m['unit'], len(m['meshes']), [x[0] for x in m['meshes']][:3], len(obj.V), len(obj.VN),
                len(obj.VT), len(obj.VC) if obj.VC else "no", obj.tri_count, len(obj.groups),
                ", ".join(list(obj.groups)[:8]),
                ("%d vertices, %d joints" % (len(obj.skin), len(m['joints']))) if obj.skin else "none",
                " (this tool's export: skeleton positions are estimates and are not read)"
                if m.get('estimated_skeleton') else "",
                len(m['tex_slots']) if m['tex_slots'] else "none"))


def pal_label(c):
    return "alpha %d" % c[3] if c[:3] == (255, 255, 255) else "rgb %d,%d,%d alpha %d" % c


def bone_usage(d):
    """{bone: (vertices with weight > 0.5%, summed weight)} from the decoded records."""
    cnt, mass = Counter(), defaultdict(float)
    for w in d.weights():
        for b, v in w.items():
            if v > 0.005:
                cnt[b] += 1
            mass[b] += v
    return dict((b, (cnt[b], mass[b])) for b in mass)


def weight_report(d, top=18):
    L_ = ["Skin weights (decoded)",
          "  1 influence : 100% on 'bone'",
          "  2 influences: w[b1] = hi/4096,   w[bone] = 1 - w[b1]",
          "  3 influences: w[b2] = lo/4096,   w[b1] = (1-w[b2])*hi/4096,   w[bone] = (1-w[b2])*(1-hi/4096)",
          "                (record u32 = hi<<16 | lo; sequential lerp bone -> b1 -> b2)", ""]
    W = d.weights()
    bad = sum(1 for w in W if any(v < -1e-9 or v > 1 + 1e-9 for v in w.values()) or abs(sum(w.values()) - 1) > 1e-6)
    L_.append("  vertices with invalid weights: %d of %d" % (bad, len(W)))
    use = bone_usage(d)
    L_.append("")
    L_.append("  %-22s %8s %9s" % ("bone", "verts", "w-mass"))
    for b, (n, m) in sorted(use.items(), key=lambda kv: -kv[1][1])[:top]:
        L_.append("  %-22s %8d %9.1f" % (d.bones[b][0] if b < len(d.bones) else "#%d" % b, n, m))
    if len(use) > top:
        L_.append("  ... %d more bones" % (len(use) - top))
    return "\n".join(L_)


def vertex_weight_text(d, i, blockmap=None):
    key, rec = d.vinfo[i]
    w = sorted(d.weights()[i].items(), key=lambda kv: -kv[1])
    nm = lambda b: d.bones[b][0] if b < len(d.bones) else "#%d" % b
    p = d.pos(i)
    txt = " + ".join("%s %.0f%%" % (nm(b), 100 * v) for b, v in w if v >= 0.005)
    return "donor vertex %d (%.1f, %.1f, %.1f)%s: %s   [%d-influence, key %s, record %s]" % (
        i, p[0], p[1], p[2], "" if blockmap is None or i not in blockmap else ", submesh %d" % blockmap[i], txt,
        key[3], "/".join(nm(b) for b in key[:3] if b != 0xFFFF),
        "-" if rec is None else "0x%08X" % rec)


def compare_report(old, new):
    out = ["Patched fields (donor -> output)"]

    def row(lbl, a, b):
        out.append("  %-22s %-12s -> %s%s" % (lbl, a, b, "" if a == b else "   *"))
    row("YOBJ payload size", "0x%X" % old.yobj_size, "0x%X" % new.yobj_size)
    row("file size", "0x%X" % len(old.raw), "0x%X" % len(new.raw))
    row("vertex count", old.vcount, new.vcount)
    row("UV count", len(old.uvs), len(new.uvs))
    row("skin groups", len(old.groups), len(new.groups))
    row("face blocks", len(old.blocks), len(new.blocks))
    row("triangles", sum(len(s) - 2 for b in old.blocks for s in b),
        sum(len(s) - 2 for b in new.blocks for s in b))
    row("POF0 pointer count", len(old.ptrs), len(new.ptrs))
    row("POF0 length", old.pof_len, new.pof_len)
    out.append("  bounding block: %s -> %s" % (tuple(round(x, 2) for x in old.bbox),
                                              tuple(round(x, 2) for x in new.bbox)))
    for nm in ('vptr', 'skin_ptr', 'ftab_ptr', 'uv_ptr', 'tail_start', 'name_ptr', 'mat_ptr'):
        row(nm, "0x%X" % getattr(old, nm), "0x%X" % getattr(new, nm))
    nb = bone_usage(new)
    c = Counter(k[3] for k, _ in new.vinfo)
    out.append("Skinning: %d vertices (1-bone %d, 2-bone %d, 3-bone %d) over %d bones" %
               (new.real_vcount, c[1], c[2], c[3], len(nb)))
    top = sorted(nb.items(), key=lambda kv: -kv[1][1])[:8]
    out.append("  heaviest: " + ", ".join("%s(%d)" % (new.bones[b][0] if b < len(new.bones) else b, n[0])
                                          for b, n in top))
    return "\n".join(out)


def verify_file(path):
    raw = open(path, 'rb').read()
    d = Dumy(raw)
    msgs = []
    prob = d.layout_problem()
    if prob:
        msgs.append("layout: " + prob)
    msgs += d.validate()
    ident = None
    if not prob:
        try:
            ident = (d.rebuild() == raw)
        except DumyError as e:
            msgs.append(str(e))
    return d, msgs, ident


# --------------------------------------------------------------------------
# synthetic OBJ for the self-test
# --------------------------------------------------------------------------
def write_test_sphere(path, nlat=24, nlon=36):
    V, VT, VN, F = [], [], [], []
    for i in range(nlat + 1):
        th = math.pi * i / nlat
        for j in range(nlon + 1):
            ph = 2 * math.pi * j / nlon
            x, y, z = 0.25 * math.sin(th) * math.cos(ph), 0.9 * math.cos(th), 0.12 * math.sin(th) * math.sin(ph)
            V.append((x, y, z))
            VT.append((j / float(nlon), 1 - i / float(nlat)))
            n = (x / 0.0625, y / 0.81, z / 0.0144)
            l = math.sqrt(sum(c * c for c in n)) or 1
            VN.append((n[0] / l, n[1] / l, n[2] / l))
    ix = lambda i, j: i * (nlon + 1) + j + 1
    for i in range(nlat):
        for j in range(nlon):
            a, b, c, d = ix(i, j), ix(i + 1, j), ix(i + 1, j + 1), ix(i, j + 1)
            F += [(a, b, c), (a, c, d)]
    with open(path, 'w') as f:
        f.write("o body\n")
        for v in V:
            f.write("v %f %f %f\n" % v)
        for v in VT:
            f.write("vt %f %f\n" % v)
        for v in VN:
            f.write("vn %f %f %f\n" % v)
        for t in F:
            f.write("f " + " ".join("%d/%d/%d" % (k, k, k) for k in t) + "\n")


def selftest(donor_path, log=print):
    import tempfile
    ok = True

    def check(name, cond, extra=""):
        nonlocal ok
        log("  [%s] %s %s" % ("PASS" if cond else "FAIL", name, extra))
        ok = ok and bool(cond)
    raw = open(donor_path, 'rb').read()
    d = Dumy(raw)
    log("Self-test on %s" % os.path.basename(donor_path))
    check("donor layout supported", d.layout_problem() is None, d.layout_problem() or "")
    check("POF0 pointers inside payload", not d.validate())
    check("parse -> rebuild is byte-identical", d.rebuild() == raw)
    tmp = tempfile.mkdtemp()
    ref = os.path.join(tmp, "ref.obj")
    export_donor_obj(d, ref)
    obj = parse_obj(ref)
    obj0 = obj
    out, st = port_model(d, obj, default_mapping(obj, d), Xform(), weight_mode='transfer')
    n = Dumy(out)

    def geo(M, b):
        return sorted(tuple(sorted((M.verts[c[0]][:3], M.uvs[c[2]]) for c in t)) for t in M.triangles(b))
    W = d.weights()
    check("every weight record decodes to valid weights (0..1, sum 1)",
          all(abs(sum(w.values()) - 1) < 1e-6 and min(w.values()) > -1e-9 and max(w.values()) < 1 + 1e-9 for w in W))
    rt = all(k[3] <= 1 or (lambda a, b: abs((a >> 16) - (b >> 16)) <= 1 and abs((a & 0xFFFF) - (b & 0xFFFF)) <= 1)(
        r, encode_into_key(k, decode_weights(k, r))) for k, r in d.vinfo)
    check("encode(decode(record)) reproduces every record", rt)
    # plausibility: neighbouring vertices of different skin groups must have closer weights
    # than the same records shuffled inside their group (a wrong decode cannot do that)
    import random
    rnd = random.Random(5)
    shuf = defaultdict(list)
    for k, r in d.vinfo:
        if k[3] == 3:
            shuf[k].append(r)
    for v in shuf.values():
        rnd.shuffle(v)
    used, W2 = Counter(), []
    for k, r in d.vinfo:
        if k[3] == 3:
            r = shuf[k][used[k]]
            used[k] += 1
        W2.append(decode_weights(k, r))

    def l1(a, b):
        return sum(abs(a.get(x, 0) - b.get(x, 0)) for x in set(a) | set(b))
    ed = [(u, v) for u, v in d.edges() if d.vinfo[u][0] != d.vinfo[v][0] and 3 in (d.vinfo[u][0][3], d.vinfo[v][0][3])]
    if len(ed) > 50:
        real = sum(l1(W[u], W[v]) for u, v in ed) / len(ed)
        fake = sum(l1(W2[u], W2[v]) for u, v in ed) / len(ed)
        check("decoded weights are spatially coherent (not noise)", real < 0.85 * fake,
              "(neighbour L1 %.2f vs %.2f shuffled)" % (real, fake))
    rl = check_rules(d)
    check("every decoded format rule holds on the donor", all(s != 'FAIL' for _, s, _ in rl),
          "(%d rules)" % sum(1 for _, s, _ in rl if s == 'PASS'))
    for rid, s, txt in rl:
        if s == 'FAIL':
            log("      FAILED RULE %s: %s" % (rid, txt))
    check("donor OBJ re-import: geometry + UVs identical",
          all(geo(d, b) == geo(n, b) for b in range(len(d.blocks))))
    ws = lambda M: sorted((M.verts[i][:3], k, r) for i, (k, r) in enumerate(M.vinfo))
    check("donor OBJ re-import: skin weights identical", ws(d) == ws(n))
    nb_ = Dumy(port_model(d, obj, default_mapping(obj, d), Xform(), weight_mode='blend')[0])
    dwm = defaultdict(list)
    for i in range(d.real_vcount):
        dwm[d.verts[i][:3]].append(d.weights()[i])
    off = 0
    for i, w in enumerate(nb_.weights()):
        off += min(max(abs(c.get(b, 0) - w.get(b, 0)) for b in set(c) | set(w)) for c in dwm[nb_.verts[i][:3]]) > 0.02
    check("blend mode reproduces donor weights on an identical mesh", off == 0, "(%d vertices off)" % off)
    check("re-imported file is valid + rebuild-stable", n.validate() == [] and n.rebuild() == out)
    sp = os.path.join(tmp, "sphere.obj")
    write_test_sphere(sp)
    obj = parse_obj(sp)
    xf = Xform()
    auto_fit(d, obj, xf)
    for mode in ('transfer', 'blend', 'rigid', 'single'):
        out, st = port_model(d, obj, default_mapping(obj, d), xf, weight_mode=mode, single_bone=3)
        n = Dumy(out)
        check("custom sphere port (%s weights)" % mode,
              n.validate() == [] and n.rebuild() == out and n.vcount == st['verts'] + n.extra,
              "verts=%d groups=%d" % (n.vcount, len(n.groups)))
    dp = os.path.join(tmp, "roundtrip.dae")
    export_dae(d, dp)
    dobj = parse_dae(dp)
    pre = dae_xform_preset(dobj)
    outd, _ = port_model(d, dobj, default_mapping(dobj, d), Xform(1.0, pre['flip'], pre['swap_yz']),
                         weight_mode='file', colour_mode='file')
    nd = Dumy(outd)
    check("DAE round trip: geometry + UVs identical", all(geo(d, b) == geo(nd, b) for b in range(len(d.blocks))))
    cols_ = lambda M: sorted((M.verts[c[0]][:3], M.uvs[c[2]], c[1]) for bl in M.blocks for s_ in bl for c in s_)
    check("DAE round trip: per-corner colours identical", cols_(d) == cols_(nd))
    dwp = defaultdict(list)
    for i in range(d.real_vcount):
        dwp[d.verts[i][:3]].append(d.weights()[i])
    wd = max(min(max(abs(c.get(b_, 0) - w.get(b_, 0)) for b_ in set(c) | set(w)) for c in dwp[nd.verts[i][:3]])
             for i, w in enumerate(nd.weights()))
    check("DAE round trip: skin weights preserved (max difference %.5f)" % wd, wd < 1.0 / 2048)
    check("DAE round trip: output satisfies every decoded rule", all(s != 'FAIL' for _, s, _ in check_rules(nd)))
    # ---- regressions from the hang / oversized-port report ----
    import random
    import time as _time
    rnd = random.Random(11)
    pts = [(rnd.uniform(-40, 40), rnd.uniform(-100, 0), rnd.uniform(-12, 8)) for _ in range(3000)]
    gr = Grid(pts)
    t0 = _time.time()
    ok_ = True
    for _q in range(150):
        far = rnd.choice((0, 1, 1, 2))
        q = (rnd.uniform(-60, 60) * (1 + 15 * far), rnd.uniform(-120, 20) * (1 + 15 * far),
             rnd.uniform(-30, 30) * (1 + 15 * far))
        j = gr.nearest(q)
        bf = min(range(len(pts)), key=lambda i: (pts[i][0] - q[0]) ** 2 + (pts[i][1] - q[1]) ** 2 + (pts[i][2] - q[2]) ** 2)
        ok_ = ok_ and abs(sum((pts[j][k] - q[k]) ** 2 for k in range(3)) -
                          sum((pts[bf][k] - q[k]) ** 2 for k in range(3))) < 1e-9
    dt = _time.time() - t0
    check("nearest-vertex search is exact, also for queries up to 1000 units away", ok_ and dt < 15, "(%.2fs)" % dt)
    # flat-shaded triangle soup of the donor: every corner gets its own face normal
    soup = ObjModel()
    soup.V, soup.VT = list(obj0.V), list(obj0.VT)
    for gname, tris in obj0.groups.items():
        lst = []
        for tri in tris:
            p3 = [soup.V[c[0]] for c in tri]
            e1 = [p3[1][k] - p3[0][k] for k in range(3)]
            e2 = [p3[2][k] - p3[0][k] for k in range(3)]
            cr = (e1[1] * e2[2] - e1[2] * e2[1], e1[2] * e2[0] - e1[0] * e2[2], e1[0] * e2[1] - e1[1] * e2[0])
            l_ = math.sqrt(sum(c * c for c in cr)) or 1.0
            soup.VN.append((cr[0] / l_, cr[1] / l_, cr[2] / l_))
            lst.append(tuple((c[0], c[1], len(soup.VN) - 1) for c in tri))
        soup.groups[gname] = lst
    t0 = _time.time()
    msoup = default_mapping(soup, d)
    r_none = build_import(d, soup, msoup, Xform(), weld_angle=None, restrict=True)
    r_auto = build_import(d, soup, msoup, Xform(), weld_angle='auto', restrict=True)
    dt = _time.time() - t0
    check("flat-shaded mesh: welding cuts vertices (%d -> %d, %d triangles)" %
          (r_none['stats']['verts'], r_auto['stats']['verts'], r_none['stats']['tris']),
          r_auto['stats']['verts'] < 0.5 * r_none['stats']['verts'] and
          r_auto['stats']['verts'] <= 1.5 * size_ref(d), "(%.1fs)" % dt)
    check("flat-shaded mesh: fewer, longer strips after welding", r_auto['stats']['strips'] < r_none['stats']['strips'])
    class _O(object):
        groups = OrderedDict([("Material.001", [1]), ("Material.002", [1]), ("submesh_3", [1]), ("blood_layer", [1])])
    mp_ = default_mapping(_O, d)
    check("default mapping: Blender names -> submesh 0, 'submesh_3' -> 3, blood -> last",
          [mp_[k]['block'] for k in _O.groups] == [0, 0, 3, len(d.blocks) - 1])
    # texture names from a .dae's materials
    txt = open(dp).read()
    imgs = ('<library_images><image id="t1" name="t1"><init_from>a/b/bodyc.png</init_from></image>'
            '<image id="t2" name="t2"><init_from>blodx.png</init_from></image></library_images>')

    def fxrep(m):
        b_ = int(m.group(1))
        im = "t2" if b_ == len(d.blocks) - 1 else "t1"
        return ('<effect id="fx_submesh_%d"><profile_COMMON><newparam sid="%s-s"><surface type="2D"><init_from>%s'
                '</init_from></surface></newparam><newparam sid="%s-p"><sampler2D><source>%s-s</source></sampler2D>'
                '</newparam><technique sid="common"><lambert><diffuse><texture texture="%s-p" texcoord="UV"/>'
                '</diffuse></lambert></technique></profile_COMMON></effect>' % (b_, im, im, im, im, im))
    txt = re.sub(r'<effect id="fx_submesh_(\d+)">.*?</effect>', fxrep, txt, flags=re.S).replace(
        '<library_effects>', imgs + '<library_effects>', 1)
    tp = os.path.join(tmp, "tex.dae")
    open(tp, 'w').write(txt)
    tobj = parse_dae(tp)
    tn = [list(x) for x in d.names]
    auto_texture_names(tobj, default_mapping(tobj, d), d, tn, 10, lambda s_: None)
    check("texture names assigned from the .dae materials (colour -> bodyc, blood -> blodx)",
          all(n_[0] == ('blodx' if 'blood' in d.names[i][0] else 'bodyc') for i, n_ in enumerate(tn)))
    nm = [list(x) for x in d.names]
    nm[0][0] = "mycol"
    out, st = port_model(d, obj, default_mapping(obj, d), xf, names=nm)
    n = Dumy(out)
    def batches_ok(M):
        return all(b_['slots'] % 16 == 0 and b_['slots'] <= BATCH_MAX and b_['real'] + b_['pad'] == b_['slots']
                   for b_ in M.batches)
    check("skin batches: <=128 slots, multiples of 16, padding recorded", batches_ok(n))
    nr = check_rules(n)
    check("ported file satisfies every decoded rule (incl. bounding block)", all(s != 'FAIL' for _, s, _ in nr),
          "(bbox error %.4f)" % max(abs(a - b) for a, b in zip(n.mesh_bbox(), n.bbox)))
    check("longest strip does not exceed the donor's longest (%d)" % d.max_strip, n.max_strip <= d.max_strip)
    check("vertex colour is opaque white by default",
          n.vcol_consistent and set(n.vcol.values()) <= {d.opaque_color_index()})
    check("vertex slot count is a multiple of 16", n.vcount % 16 == 0, "(%d)" % n.vcount)
    check("texture name patched", n.names[0][0] == "mycol" and n.names[1][0] == d.names[1][0])
    return ok


# --------------------------------------------------------------------------
# GUI
# --------------------------------------------------------------------------
BG, PANEL, FIELD, BORDER = "#202020", "#2d2d2d", "#262626", "#454545"
FG, MUTED, ACCENT, GOOD = "#ffffff", "#a0a0a0", "#60CDFF", "#a6e3a1"


def run_gui(driver=None):
    import threading
    import queue
    import tkinter as tk
    from tkinter import ttk, filedialog, messagebox

    class App(tk.Tk):
        def __init__(self):
            tk.Tk.__init__(self)
            self.title("WWE 13 DUMY Port Tool")
            self.geometry("1280x820")
            self.minsize(1050, 700)
            self.configure(bg=BG)
            self.donor = self.obj = None
            self.donor_path = self.obj_path = None
            self.mapping = OrderedDict()
            self.names = []
            self.tex_names = []
            self.q = queue.Queue()
            self.busy = False
            self.yaw, self.pitch, self.zoom = 0.4, 0.15, 1.0
            self.pan = [0.0, 0.0]
            self._drag = None
            self._cust_pts = None
            self._cust_edges = []
            self._don_edges = []
            self._redraw_job = None
            self._heat = None
            self._heat_bone = None
            self._proj = []
            self._sel_vertex = None
            self._press = None
            self._modal = None          # Blender-style grab / scale in progress
            self._xf_undo = []
            self._vstate = None
            self._blockmap = {}
            self._style()
            self._build()
            self.after(100, self._poll)

        # ---------------------------------------------------------- style
        def _style(self):
            s = ttk.Style(self)
            try:
                s.theme_use('clam')
            except tk.TclError:
                pass
            s.configure('.', background=PANEL, foreground=FG, fieldbackground=FIELD,
                        bordercolor=BORDER, lightcolor=PANEL, darkcolor=PANEL, troughcolor=BG,
                        font=("Segoe UI", 9))
            s.configure('TFrame', background=PANEL)
            s.configure('Bg.TFrame', background=BG)
            s.configure('TLabel', background=PANEL, foreground=FG)
            s.configure('Muted.TLabel', foreground=MUTED)
            s.configure('Head.TLabel', background=BG, foreground=FG, font=("Segoe UI", 15, "bold"))
            s.configure('Sub.TLabel', background=BG, foreground=MUTED)
            s.configure('TButton', background="#3a3a3a", foreground=FG, padding=(10, 5), borderwidth=1)
            s.map('TButton', background=[('active', '#4a4a4a'), ('disabled', '#2a2a2a')],
                  foreground=[('disabled', '#777')])
            s.configure('Accent.TButton', background=ACCENT, foreground="#000", font=("Segoe UI", 9, "bold"))
            s.map('Accent.TButton', background=[('active', '#4CB0E5'), ('disabled', '#2c5a70')],
                  foreground=[('disabled', '#222')])
            s.configure('TNotebook', background=BG, borderwidth=0)
            s.configure('TNotebook.Tab', background="#333", foreground=MUTED, padding=(12, 6))
            s.map('TNotebook.Tab', background=[('selected', PANEL)], foreground=[('selected', ACCENT)])
            s.configure('TCheckbutton', background=PANEL, foreground=FG)
            s.configure('TRadiobutton', background=PANEL, foreground=FG)
            s.map('TCheckbutton', background=[('active', PANEL)])
            s.map('TRadiobutton', background=[('active', PANEL)])
            s.configure('TEntry', fieldbackground=FIELD, foreground=FG, insertcolor=FG)
            s.configure('TCombobox', fieldbackground=FIELD, foreground=FG, arrowcolor=FG)
            s.map('TCombobox', fieldbackground=[('readonly', FIELD)], foreground=[('readonly', FG)])
            s.configure('TSpinbox', fieldbackground=FIELD, foreground=FG, arrowcolor=FG)
            s.configure('Treeview', background=FIELD, fieldbackground=FIELD, foreground=FG, rowheight=22,
                        borderwidth=0)
            s.configure('Treeview.Heading', background="#383838", foreground=FG, relief='flat')
            s.map('Treeview', background=[('selected', '#1d5b78')], foreground=[('selected', FG)])
            s.configure('TLabelframe', background=PANEL, bordercolor=BORDER)
            s.configure('TLabelframe.Label', background=PANEL, foreground=ACCENT)
            s.configure('Horizontal.TProgressbar', background=ACCENT, troughcolor=BG)
            s.configure('TPanedwindow', background=BG)
            self.option_add('*TCombobox*Listbox.background', FIELD)
            self.option_add('*TCombobox*Listbox.foreground', FG)

        # ---------------------------------------------------------- layout
        def _build(self):
            hdr = ttk.Frame(self, style='Bg.TFrame')
            hdr.pack(fill='x', padx=14, pady=(10, 4))
            ttk.Label(hdr, text="WWE 13  DUMY Port Tool", style='Head.TLabel').pack(side='left')
            ttk.Label(hdr, text="   port a custom OBJ into a donor .dumy and patch skin weights, "
                                "texture names, header and POF0", style='Sub.TLabel').pack(side='left')

            bar = ttk.Frame(self, style='Bg.TFrame')
            bar.pack(fill='x', padx=14, pady=4)
            ttk.Button(bar, text="1  Load donor", command=self.load_donor).pack(side='left', padx=(0, 6))
            self.btn_obj = ttk.Button(bar, text="2  Load .obj / .dae", command=self.load_obj, state='disabled')
            self.btn_obj.pack(side='left', padx=6)
            self.btn_tex = ttk.Button(bar, text="3  Load .tex", command=self.load_tex,
                                      state='disabled')
            self.btn_tex.pack(side='left', padx=6)
            self.btn_ref = ttk.Button(bar, text="Export .obj", command=self.export_ref, state='disabled')
            self.btn_ref.pack(side='left', padx=6)
            self.btn_dae = ttk.Button(bar, text="Export .dae", command=self.export_dae_clicked, state='disabled')
            self.btn_dae.pack(side='left', padx=6)
            ttk.Button(bar, text="Optimize .dumy", command=self.optimize_clicked).pack(side='left', padx=6)
            self.btn_ver = ttk.Button(bar, text="Verify a .dumy", command=self.verify_any)
            self.btn_ver.pack(side='left', padx=6)
            self.btn_st = ttk.Button(bar, text="Self-test", command=self.run_selftest, state='disabled')
            self.btn_st.pack(side='left', padx=6)
            self.btn_go = ttk.Button(bar, text="PORT & SAVE PATCHED DUMY", style='Accent.TButton',
                                     command=self.port_and_save, state='disabled')
            self.btn_go.pack(side='right')
            self.lbl_files = ttk.Label(self, text="no donor loaded", style='Sub.TLabel')
            self.lbl_files.pack(fill='x', padx=16)

            pw = ttk.PanedWindow(self, orient='horizontal')
            pw.pack(fill='both', expand=True, padx=14, pady=6)
            left = ttk.Frame(pw, style='Bg.TFrame')
            right = ttk.Frame(pw, style='Bg.TFrame')
            pw.add(left, weight=3)
            pw.add(right, weight=2)

            self.nb = ttk.Notebook(left)
            self.nb.pack(fill='both', expand=True)
            self._tab_donor()
            self._tab_map()
            self._tab_xform()
            self._tab_weights()
            self._tab_tex()

            # preview
            top = ttk.Frame(right, style='Bg.TFrame')
            top.pack(fill='x')
            ttk.Label(top, text="Preview", style='Sub.TLabel').pack(side='left')
            self.v_show_d = tk.BooleanVar(value=True)
            self.v_show_c = tk.BooleanVar(value=True)
            for t, v in (("donor", self.v_show_d), ("custom", self.v_show_c)):
                ttk.Checkbutton(top, text=t, variable=v, command=self.redraw).pack(side='left', padx=8)
            ttk.Button(top, text="Scale (S)", command=lambda: self.modal_start('scale')).pack(side='left', padx=(10, 2))
            ttk.Button(top, text="Grab (G)", command=lambda: self.modal_start('grab')).pack(side='left', padx=2)
            ttk.Button(top, text="Reset view", command=self.reset_view).pack(side='right')
            ttk.Button(top, text="Alpha", command=self.heat_alpha).pack(side='right', padx=6)
            self.cv = tk.Canvas(right, bg="#111", highlightthickness=1, highlightbackground=BORDER)
            self.cv.pack(fill='both', expand=True, pady=(4, 0))
            ttk.Label(right, text="drag: rotate  wheel: zoom  right-drag: pan  click: vertex weights   |   "
                                  "hover + G: grab (move)   S: scale   Ctrl+Z: undo",
                      style='Sub.TLabel', wraplength=480, justify='left').pack(anchor='w')
            self.cv.bind("<ButtonPress-1>", lambda e: self._d0(e, 'rot', 1))
            self.cv.bind("<ButtonPress-3>", lambda e: self._d0(e, 'pan', 3))
            self.cv.bind("<ButtonPress-2>", lambda e: self._d0(e, 'pan', 2))
            self.cv.bind("<Motion>", self._modal_motion)
            self.cv.bind("<KeyPress>", self._key)
            self.bind_all("<KeyPress>", self._key_global)
            self.cv.bind("<B1-Motion>", self._d1)
            self.cv.bind("<B3-Motion>", self._d1)
            self.cv.bind("<B2-Motion>", self._d1)
            self.cv.bind("<ButtonRelease-1>", self._d2)
            self.cv.bind("<ButtonRelease-3>", self._d2)
            self.cv.bind("<ButtonRelease-2>", self._d2)
            self.cv.bind("<MouseWheel>", self._wheel)
            self.cv.bind("<Button-4>", lambda e: self._zoom(1.1))
            self.cv.bind("<Button-5>", lambda e: self._zoom(1 / 1.1))
            self.cv.bind("<Configure>", lambda e: self.redraw())

            logf = ttk.Frame(self, style='Bg.TFrame')
            logf.pack(fill='x', padx=14, pady=(0, 10))
            self.log_t = tk.Text(logf, height=9, bg="#161616", fg="#cfcfcf", insertbackground=FG,
                                 relief='flat', font=("Consolas", 9), wrap='word',
                                 highlightthickness=1, highlightbackground=BORDER)
            sb = ttk.Scrollbar(logf, command=self.log_t.yview)
            self.log_t.configure(yscrollcommand=sb.set)
            sb.pack(side='right', fill='y')
            self.log_t.pack(fill='x')
            self.log_t.tag_config('err', foreground="#f38ba8")
            self.log_t.tag_config('ok', foreground=GOOD)
            self.log_t.tag_config('warn', foreground="#f9e2af")
            self.log("Ready. Load a donor .dumy first (any character model whose skeleton you want to keep).")

        def _tab_donor(self):
            f = ttk.Frame(self.nb)
            self.nb.add(f, text="Donor")
            self.txt_donor = tk.Text(f, bg=FIELD, fg="#d8d8d8", relief='flat', font=("Consolas", 9),
                                     wrap='none', height=10)
            sb = ttk.Scrollbar(f, command=self.txt_donor.yview)
            self.txt_donor.configure(yscrollcommand=sb.set)
            sb.pack(side='right', fill='y')
            self.txt_donor.pack(fill='both', expand=True, padx=6, pady=6)
            self.txt_donor.insert('1.0', "Load a donor .dumy to see its structure.")
            self.txt_donor.configure(state='disabled')

        def _tab_map(self):
            f = ttk.Frame(self.nb)
            self.nb.add(f, text="Submesh map")
            ttk.Label(f, text="Each OBJ object/group goes into one donor submesh (face block). "
                              "Name groups ending in a number (e.g. body_2) to auto-map.",
                      style='Muted.TLabel', wraplength=520).pack(anchor='w', padx=8, pady=(8, 4))
            cols = ('grp', 'tris', 'blk', 'bone', 'col')
            self.tv_map = ttk.Treeview(f, columns=cols, show='headings', height=8, selectmode='extended')
            for c, t, w in (('grp', 'OBJ group', 170), ('tris', 'tris', 60), ('blk', 'donor submesh', 110),
                            ('bone', 'forced bone', 130), ('col', 'vertex alpha', 120)):
                self.tv_map.heading(c, text=t)
                self.tv_map.column(c, width=w, anchor='w')
            self.tv_map.pack(fill='both', expand=True, padx=8)
            self.tv_map.bind('<<TreeviewSelect>>', self._map_sel)
            row = ttk.Frame(f)
            row.pack(fill='x', padx=8, pady=8)
            ttk.Label(row, text="submesh").grid(row=0, column=0, sticky='w', pady=3)
            self.cb_blk = ttk.Combobox(row, state='readonly', width=18)
            self.cb_blk.grid(row=0, column=1, padx=6, sticky='w')
            ttk.Label(row, text="forced bone").grid(row=0, column=2, sticky='w')
            self.cb_bone = ttk.Combobox(row, state='readonly', width=26)
            self.cb_bone.grid(row=0, column=3, padx=6, sticky='w')
            ttk.Label(row, text="vertex alpha").grid(row=1, column=0, sticky='w', pady=3)
            self.sp_col = ttk.Combobox(row, state='readonly', width=16, values=['auto'])
            self.sp_col.grid(row=1, column=1, padx=6, sticky='w')
            ttk.Button(row, text="Apply to selected", command=self.map_apply).grid(row=1, column=2, padx=6, sticky='w')
            ttk.Button(row, text="Auto map", command=self.map_auto).grid(row=1, column=3, padx=6, sticky='w')
            ag = ttk.LabelFrame(f, text="Vertex alpha of custom vertices (auto)")
            ag.pack(fill='x', padx=8, pady=(0, 6))
            self.v_cmode = tk.StringVar(value='opaque')
            ttk.Radiobutton(ag, text="opaque (palette entry with alpha 255 - what most of the donor body uses)",
                            value='opaque', variable=self.v_cmode).pack(anchor='w', padx=8, pady=2)
            ttk.Radiobutton(ag, text="copy from the nearest donor vertex (keeps the donor's alpha pattern)",
                            value='transfer', variable=self.v_cmode).pack(anchor='w', padx=8, pady=2)
            ttk.Radiobutton(ag, text="from the model file — per-corner colours of the .dae, nearest donor palette entry",
                            value='file', variable=self.v_cmode).pack(anchor='w', padx=8, pady=2)
            wg = ttk.LabelFrame(f, text="Vertices")
            wg.pack(fill='x', padx=8, pady=(0, 6))
            self.v_weld_on = tk.BooleanVar(value=True)
            self.v_weld = tk.StringVar(value="auto")
            wr = ttk.Frame(wg)
            wr.pack(fill='x', padx=8, pady=3)
            ttk.Checkbutton(wr, text="merge vertices at one position whose normals differ by less than",
                            variable=self.v_weld_on).pack(side='left')
            ttk.Entry(wr, textvariable=self.v_weld, width=5).pack(side='left', padx=4)
            ttk.Label(wr, text="degrees (auto = smallest that fits the vertex cap)").pack(side='left')
            self.v_budget = tk.StringVar(value="unlimited")
            br = ttk.Frame(wg)
            br.pack(fill='x', padx=8, pady=3)
            ttk.Label(br, text="Vertex cap:").pack(side='left')
            ttk.Entry(br, textvariable=self.v_budget, width=10).pack(side='left', padx=4)
            ttk.Label(br, text="unlimited (default) or a number - no triangle limit is applied. Only the format "
                               "itself stops at %s vertices." % "{:,}".format(MAX_FORMAT_VERTS),
                      style='Muted.TLabel', wraplength=420).pack(side='left')
            self.v_tear = tk.BooleanVar(value=True)
            ttk.Checkbutton(wg, text="Tear the mesh where skin weights differ (never merge e.g. upper and lower lip, so "
                                     "the mouth can open and the inside shows; needs weights from a .dae)",
                            variable=self.v_tear).pack(anchor='w', padx=8, pady=3)
            ttk.Label(wg, text="Flat-shaded / split-normal meshes have a separate vertex per triangle corner (a "
                              "15,000-vertex port crashed the game). Merging keeps hard edges above the angle.",
                      style='Muted.TLabel', wraplength=520).pack(anchor='w', padx=8, pady=(0, 4))
            ttk.Label(f, text="forced bone: all vertices of that group get 100% on one bone instead of the "
                              "nearest-donor weights.\nvertex alpha: palette entry used by every vertex of the group (auto = the "
                              "global choice below). Palette alpha is per vertex in the donor.",
                      style='Muted.TLabel', wraplength=520).pack(anchor='w', padx=8, pady=(0, 8))

        def _tab_xform(self):
            f = ttk.Frame(self.nb)
            self.nb.add(f, text="Transform / fit")
            self.v_scale = tk.StringVar(value="1.0")
            self.v_off = [tk.StringVar(value="0.0") for _ in range(3)]
            self.v_ax = [tk.StringVar(value="1.0") for _ in range(3)]
            self.v_flip = [tk.BooleanVar(value=False), tk.BooleanVar(value=True), tk.BooleanVar(value=True)]
            self.v_swap = tk.BooleanVar(value=False)
            self.v_xf_on = tk.BooleanVar(value=True)
            self._xf_widgets = []
            ttk.Checkbutton(f, text="Enable transform & fit (when off, the model's own coordinates are used "
                                    "as-is: scale 1, no flip / swap, no offset, no auto-fit)",
                            variable=self.v_xf_on, command=self.xf_toggle).pack(anchor='w', padx=10, pady=(8, 0))
            g = ttk.LabelFrame(f, text="OBJ -> donor space")
            g.pack(fill='x', padx=8, pady=8)
            ttk.Label(g, text="scale").grid(row=0, column=0, sticky='w', padx=6, pady=4)
            w_ = ttk.Entry(g, textvariable=self.v_scale, width=12)
            w_.grid(row=0, column=1, padx=6)
            self._xf_widgets.append(w_)
            for i, a in enumerate("XYZ"):
                ttk.Label(g, text="offset " + a).grid(row=1, column=2 * i, sticky='w', padx=6, pady=4)
                w_ = ttk.Entry(g, textvariable=self.v_off[i], width=10)
                w_.grid(row=1, column=2 * i + 1, padx=6)
                self._xf_widgets.append(w_)
                w_ = ttk.Checkbutton(g, text="flip " + a, variable=self.v_flip[i], command=self.xf_changed)
                w_.grid(row=2, column=2 * i, columnspan=2, sticky='w', padx=6)
                self._xf_widgets.append(w_)
            w_ = ttk.Checkbutton(g, text="swap Y/Z (Z-up OBJ)", variable=self.v_swap, command=self.xf_changed)
            w_.grid(row=3, column=0, columnspan=4, sticky='w', padx=6, pady=4)
            self._xf_widgets.append(w_)
            for i, a in enumerate("XYZ"):
                ttk.Label(g, text="stretch " + a).grid(row=4, column=2 * i, sticky='w', padx=6, pady=4)
                w_ = ttk.Entry(g, textvariable=self.v_ax[i], width=10)
                w_.grid(row=4, column=2 * i + 1, padx=6)
                self._xf_widgets.append(w_)
            for v in [self.v_scale] + self.v_off + self.v_ax:
                v.trace_add('write', lambda *a: self.xf_changed())
            b = ttk.Frame(f)
            b.pack(fill='x', padx=8)
            w_ = ttk.Button(b, text="Auto-fit to donor", command=self.auto_fit_clicked)
            w_.pack(side='left')
            self._xf_widgets.append(w_)
            w_ = ttk.Button(b, text="Y-up, faces +Z (default)", command=lambda: self.preset(False, True, True, False))
            w_.pack(side='left', padx=6)
            self._xf_widgets.append(w_)
            w_ = ttk.Button(b, text="Z-up, faces -Y (Blender)", command=lambda: self.preset(False, True, False, True))
            w_.pack(side='left')
            self._xf_widgets.append(w_)
            w_ = ttk.Button(b, text="native (Y-down)", command=lambda: self.preset(False, False, False, False))
            w_.pack(side='left', padx=6)
            self._xf_widgets.append(w_)
            b2 = ttk.Frame(f)
            b2.pack(fill='x', padx=8, pady=(6, 0))
            w_ = ttk.Button(b2, text="Grab (G)", command=lambda: self.modal_start('grab'))
            w_.pack(side='left')
            self._xf_widgets.append(w_)
            w_ = ttk.Button(b2, text="Scale (S)", command=lambda: self.modal_start('scale'))
            w_.pack(side='left', padx=6)
            self._xf_widgets.append(w_)
            w_ = ttk.Button(b2, text="Undo (Ctrl+Z)", command=self.xf_undo)
            w_.pack(side='left')
            self._xf_widgets.append(w_)
            ttk.Label(b2, text="  scale pivot").pack(side='left')
            self.cb_pivot = ttk.Combobox(b2, state='readonly', width=22, values=PIVOTS)
            self.cb_pivot.set(PIVOTS[0])
            self.cb_pivot.pack(side='left', padx=6)
            self._xf_widgets.append(self.cb_pivot)
            self.lbl_fit = ttk.Label(f, text="", style='Muted.TLabel', justify='left', wraplength=520)
            self.lbl_fit.pack(anchor='w', padx=8, pady=10)
            ttk.Label(f, text="The donor frame is Y-down and 8.8 fixed point (range ±128). "
                              "'Auto-fit' scales the custom model to the donor's height and centres "
                              "its bounding box on the donor's. The cyan preview is the custom mesh "
                              "after this transform — check that it overlays the grey donor "
                              "(same facing, standing upright).\n\n"
                              "Blender-style editing: hover the preview and press G (grab / relocate) or S (scale), "
                              "move the mouse, then click or Enter to confirm, right-click or Esc to cancel. "
                              "While it runs: X / Y / Z constrain to an axis (press again to release), "
                              "Shift+X/Y/Z lock that axis out, type a number for an exact value "
                              "(Tab = next field when grabbing), hold Shift for fine control, "
                              "Ctrl to snap. A constrained scale fills the 'stretch' fields.",
                      style='Muted.TLabel', wraplength=520).pack(anchor='w', padx=8)

        def _tab_weights(self):
            f = ttk.Frame(self.nb)
            self.nb.add(f, text="Bone weights")
            self.v_wmode = tk.StringVar(value='transfer')
            g = ttk.LabelFrame(f, text="How the custom vertices get skin weights")
            g.pack(fill='x', padx=8, pady=8)
            for val, txt in (('file', "From the model file — the skin weights stored in the .dae (bones matched by name)"),
                             ('transfer', "Transfer — copy the skin record (bones + blend weights) of the "
                                          "nearest donor vertex (exact, safest)"),
                             ('blend', "Blend — inverse-distance mix of the 4 nearest donor vertices (smoother)"),
                             ('rigid', "Rigid — 100% on the dominant bone of the nearest donor vertex "
                                       "(fewest skin groups, no blending)"),
                             ('single', "Single bone — every vertex 100% on one bone")):
                ttk.Radiobutton(g, text=txt, value=val, variable=self.v_wmode).pack(anchor='w', padx=8, pady=3)
            r = ttk.Frame(g)
            r.pack(fill='x', padx=8, pady=(2, 8))
            ttk.Label(r, text="bone for 'single':").pack(side='left')
            self.cb_single = ttk.Combobox(r, state='readonly', width=28)
            self.cb_single.pack(side='left', padx=6)
            self.v_restrict = tk.BooleanVar(value=False)
            ttk.Checkbutton(f, text="Transfer only from the matching donor submesh "
                                    "(head mesh copies head weights, etc.)",
                            variable=self.v_restrict).pack(anchor='w', padx=10, pady=4)
            self.v_noface = tk.BooleanVar(value=False)
            self.v_facekw = tk.StringVar(value=FACE_KEYWORDS)
            ff = ttk.LabelFrame(f, text="Facial animation")
            ff.pack(fill='x', padx=8, pady=(0, 4))
            ttk.Checkbutton(ff, text="Disable facial animation - fold the weights of face bones (jaw, eyes, brows, "
                                     "lips ...) into the nearest non-face parent bone (e.g. head), so the face "
                                     "stays rigid",
                            variable=self.v_noface, command=self.face_info).pack(anchor='w', padx=8, pady=3)
            fr = ttk.Frame(ff)
            fr.pack(fill='x', padx=8, pady=(0, 2))
            ttk.Label(fr, text="face-bone words:").pack(side='left')
            ttk.Entry(fr, textvariable=self.v_facekw).pack(side='left', fill='x', expand=True, padx=6)
            ttk.Button(fr, text="Default", width=8,
                       command=lambda: self.v_facekw.set(FACE_KEYWORDS)).pack(side='left')
            self.lbl_face = ttk.Label(ff, text="", style='Muted.TLabel', wraplength=500, justify='left')
            self.lbl_face.pack(anchor='w', padx=8, pady=(0, 6))
            self.v_facekw.trace_add('write', lambda *a: self.face_info())
            ttk.Label(f, text="An OBJ carries no skin weights, so they are inferred from where each vertex sits "
                              "relative to the donor (Blend re-encodes the mix with the decoded weight format; "
                              "Transfer copies raw records). A .dae carries real weights: 'From the model file' "
                              "uses them (bones matched by name, at most 3 influences per vertex, at most 255 "
                              "skin groups). Vertices are re-sorted into skin groups "
                              "(max 128 vertices per group, 255 groups) and the group table, per-vertex "
                              "weight records, batch flags and group/vertex counts are rebuilt. "
                              "Transfer works best when the custom body has the same pose and proportions "
                              "as the donor (use Auto-fit).",
                      style='Muted.TLabel', wraplength=520).pack(anchor='w', padx=8, pady=8)
            hb = ttk.Frame(f)
            hb.pack(fill='x', padx=8)
            ttk.Label(hb, text="Donor bones (select one to heat-map its weight)", style='Muted.TLabel').pack(side='left')
            self.v_heat = tk.BooleanVar(value=True)
            ttk.Checkbutton(hb, text="heat-map", variable=self.v_heat, command=self.set_heat).pack(side='right')
            self.tv_bones = ttk.Treeview(f, columns=('i', 'n', 'p', 'v', 'm'), show='headings', height=8)
            for c, t, w in (('i', '#', 40), ('n', 'bone', 170), ('p', 'parent', 140), ('v', 'verts', 60),
                            ('m', 'w-mass', 70)):
                self.tv_bones.heading(c, text=t)
                self.tv_bones.column(c, width=w, anchor='w')
            self.tv_bones.pack(fill='both', expand=True, padx=8, pady=(2, 8))
            self.tv_bones.bind('<<TreeviewSelect>>', self.set_heat)

        def face_info(self):
            if not self.donor:
                self.lbl_face.configure(text="")
                return
            face = face_bone_indices(self.donor, self.v_facekw.get())
            tgt = face_remap(self.donor, face)
            if not face:
                txt = "No donor bone name matches these words."
            else:
                names = ", ".join(self.donor.bones[b][0] for b in face[:14]) + (" ..." if len(face) > 14 else "")
                to = sorted(set(self.donor.bones[t][0] for t in tgt.values()))
                txt = "%d matching bone(s): %s%s" % (len(face), names,
                                                     ("   ->  " + ", ".join(to)) if to else "   (no non-face parent found)")
            if not self.v_noface.get():
                txt += "   [option is off]"
            self.lbl_face.configure(text=txt)

        def _tab_tex(self):
            f = ttk.Frame(self.nb)
            self.nb.add(f, text="Texture names")
            ttk.Label(f, text="Texture-name slots in the DUMY. The game looks these up in the character's "
                              ".tex by name, so they must match the entry names in your .tex.",
                      style='Muted.TLabel', wraplength=520).pack(anchor='w', padx=8, pady=(8, 4))
            self.tv_tex = ttk.Treeview(f, columns=('i', 'n', 'e'), show='headings', height=10,
                                       selectmode='extended')
            for c, t, w in (('i', 'slot', 50), ('n', 'name', 200), ('e', 'ext', 80)):
                self.tv_tex.heading(c, text=t)
                self.tv_tex.column(c, width=w, anchor='w')
            self.tv_tex.pack(fill='both', expand=True, padx=8)
            self.tv_tex.bind('<<TreeviewSelect>>', self._tex_sel)
            r = ttk.Frame(f)
            r.pack(fill='x', padx=8, pady=(8, 2))
            self.v_tname, self.v_text = tk.StringVar(), tk.StringVar(value="tga")
            ttk.Label(r, text="name").pack(side='left')
            self.cb_tname = ttk.Combobox(r, textvariable=self.v_tname, width=18)
            self.cb_tname.pack(side='left', padx=6)
            ttk.Label(r, text="ext").pack(side='left')
            ttk.Entry(r, textvariable=self.v_text, width=6).pack(side='left', padx=6)
            r2 = ttk.Frame(f)
            r2.pack(fill='x', padx=8, pady=(2, 8))
            ttk.Button(r2, text="Set selected", command=self.tex_set).pack(side='left')
            ttk.Button(r2, text="Set all non-blood", command=lambda: self.tex_set_all(False)).pack(side='left', padx=6)
            ttk.Button(r2, text="Set blood slots", command=lambda: self.tex_set_all(True)).pack(side='left')
            ttk.Button(r2, text="Reset", command=self.tex_reset).pack(side='left', padx=6)
            ttk.Button(r2, text="Auto-assign from model", command=self.tex_auto).pack(side='left')
            self.lbl_tex = ttk.Label(f, text="", style='Muted.TLabel', wraplength=520)
            self.lbl_tex.pack(anchor='w', padx=8)
            self.v_long = tk.BooleanVar(value=False)
            ttk.Checkbutton(f, text="allow up to 16 bytes (not seen in any sample file - unverified)",
                            variable=self.v_long).pack(anchor='w', padx=8)
            self.v_mtl = tk.BooleanVar(value=True)
            ttk.Checkbutton(f, text="patch texture names from the OBJ's .mtl (map_Kd) when an .obj is loaded",
                            variable=self.v_mtl).pack(anchor='w', padx=8)
            ttk.Label(f, text="Slot = 'name\\0ext\\0' + filler bytes the game ignores. Both samples use only "
                              "10 bytes (color.tga / blood.tga), so that is the verified limit.",
                      style='Muted.TLabel', wraplength=520).pack(anchor='w', padx=8, pady=4)

        # ---------------------------------------------------------- helpers
        def log(self, msg, tag=None):
            self.log_t.insert('end', msg + "\n", tag or ())
            self.log_t.see('end')

        def _poll(self):
            try:
                while True:
                    kind, payload = self.q.get_nowait()
                    if kind == 'log':
                        self.log(*payload)
                    elif kind == 'warnbox':
                        messagebox.showwarning("Model size", payload)
                    elif kind == 'done':
                        self.busy = False
                        self.btn_go.configure(state='normal')
                        self.config(cursor="")
                        payload()
            except queue.Empty:
                pass
            self.after(100, self._poll)

        def bone_label(self, i):
            n, p = self.donor.bones[i]
            return "%d  %s" % (i, n)

        # ---------------------------------------------------------- loading
        def load_donor(self):
            p = filedialog.askopenfilename(title="Donor DUMY", filetypes=[("DUMY", "*.dumy"), ("All", "*.*")])
            if not p:
                return
            try:
                d = Dumy(open(p, 'rb').read())
            except Exception as e:
                messagebox.showerror("Donor", "Cannot parse this file:\n%s" % e)
                return
            self.donor, self.donor_path = d, p
            self.names = [list(x) for x in d.names]
            for b in (self.btn_obj, self.btn_tex, self.btn_ref, self.btn_dae, self.btn_st):
                b.configure(state='normal')
            self.txt_donor.configure(state='normal')
            self.txt_donor.delete('1.0', 'end')
            self.txt_donor.insert('1.0', donor_report(d))
            self.txt_donor.configure(state='disabled')
            labels = [self.bone_label(i) for i in range(len(d.bones))]
            self.cb_single.configure(values=labels)
            self.cb_single.current(min(3, len(labels) - 1) if labels else 0)
            self.cb_bone.configure(values=['auto (transfer)'] + labels)
            self.cb_bone.current(0)
            self.cb_blk.configure(values=['skip'] + ["submesh %d" % i for i in range(len(d.blocks))])
            self.cb_blk.current(1)
            self.sp_col.configure(values=['auto'] + ["%d (%s)" % (i, pal_label(c)) for i, c in enumerate(d.palette)])
            self.sp_col.current(0)
            for r in self.tv_bones.get_children():
                self.tv_bones.delete(r)
            use = bone_usage(d)
            self._heat = None
            self._blockmap = {}
            for b_, strips in enumerate(d.blocks):
                for st in strips:
                    for c in st:
                        self._blockmap.setdefault(c[0], b_)
            for i, (n, par) in enumerate(d.bones):
                u = use.get(i, (0, 0.0))
                self.tv_bones.insert('', 'end', values=(i, n, d.bones[par][0] if 0 <= par < len(d.bones) else '-',
                                                        u[0], "%.1f" % u[1]))
            self.fill_tex()
            self.face_info()
            self._don_edges = self._edges_from_donor()
            self.lbl_files.configure(text="donor: %s    |    custom: %s" %
                                     (os.path.basename(p), os.path.basename(self.obj_path) if self.obj_path else "-"))
            self.log("Donor loaded: %s — %d verts, %d bones, %d skin groups, %d submeshes" %
                     (os.path.basename(p), d.real_vcount, d.bone_count, len(d.groups), len(d.blocks)), 'ok')
            prob = d.layout_problem()
            if prob:
                self.log("This donor has an unsupported layout: " + prob, 'err')
            for rid, st, txt in check_rules(d):
                if st == 'FAIL':
                    self.log("Decoded rule FAILS on this donor - %s: %s" % (rid, txt), 'err')
            if self.obj:
                self.map_auto()
            self.reset_view()
            self.update_go()

        def load_obj(self):
            if not self.donor:
                return
            p = filedialog.askopenfilename(title="Custom model", filetypes=[
                ("OBJ or COLLADA", "*.obj *.dae"), ("OBJ", "*.obj"), ("COLLADA", "*.dae"), ("All", "*.*")])
            if not p:
                return
            try:
                self.obj = load_obj_mtl(p, self.v_mtl.get(), lambda s_: self.log(s_, 'warn'))
                if False and p.lower().endswith('.dae'):          # atlas is opt-in (CLI --atlas) only
                    _ap = maybe_bake_atlas(p, self.obj, lambda s_: self.log(s_, 'warn'))
                    if _ap:
                        p = _ap
                        self.obj = load_model(p, 'object')
            except Exception as e:
                messagebox.showerror("Model", str(e))
                return
            self.obj_path = p
            self.lbl_files.configure(text="donor: %s    |    custom: %s" %
                                     (os.path.basename(self.donor_path), os.path.basename(p)))
            is_dae = p.lower().endswith('.dae')
            if is_dae:
                self.log(dae_summary(self.obj), 'ok')
                pre = dae_xform_preset(self.obj)
                for v, val in zip(self.v_flip, pre['flip']):
                    v.set(val)
                self.v_swap.set(pre['swap_yz'])
                self.v_wmode.set('file' if self.obj.skin else ('transfer' if self.v_wmode.get() == 'file'
                                                                else self.v_wmode.get()))
                self.v_cmode.set('file' if self.obj.VC else ('opaque' if self.v_cmode.get() == 'file'
                                                             else self.v_cmode.get()))
                nb = 16 if self.v_long.get() else 10
                apply_dae_texture_names(self.obj, self.names, nb, lambda s: self.log(s, 'warn'))
                self.map_auto()
                auto_texture_names(self.obj, self.mapping, self.donor, self.names, nb,
                                   lambda s: self.log(s, 'warn' if 'too long' in s else 'ok'))
                self.fill_tex()
                if self.obj.meta.get('tex_slots'):
                    self.log("Texture-slot names taken from the .dae (Texture names tab).")
            else:
                self.log("OBJ loaded: %d verts, %d uvs, %d normals, %d tris in %d group(s): %s" %
                         (len(self.obj.V), len(self.obj.VT), len(self.obj.VN), self.obj.tri_count,
                          len(self.obj.groups), ", ".join(list(self.obj.groups)[:8])), 'ok')
                if self.v_wmode.get() == 'file':
                    self.v_wmode.set('transfer')
                if self.v_cmode.get() == 'file':
                    self.v_cmode.set('opaque')
                if self.v_mtl.get() and self.obj.meta.get('group_textures'):
                    self.map_auto()
                    auto_texture_names(self.obj, self.mapping, self.donor, self.names,
                                       16 if self.v_long.get() else 10,
                                       lambda s_: self.log(s_, 'warn' if 'does not fit' in s_ else 'ok'))
                    self.fill_tex()
            if not self.obj.VN:
                self.log("The model has no normals: smooth normals will be computed.", 'warn')
            if not self.obj.VT:
                self.log("The model has no UVs: every corner would get UV (0,0).", 'warn')
            self.map_auto()
            self.auto_fit_clicked()
            self.log_weld_counts()
            self.update_go()

        def log_weld_counts(self):
            try:
                wc = weld_counts(self.obj, self.cur_xf(), self.mapping,
                                 tear=bool(self.v_tear.get() and self.v_wmode.get() == 'file'))
            except Exception as e:      # noqa
                return
            try:
                lim = vertex_target(self.donor, parse_budget(self.v_budget.get()))
            except ValueError:
                lim = vertex_target(self.donor)
            self.log("Vertex count by normal-weld angle: " + ",  ".join("%g deg: %d" % (a, n) for a, n in wc.items()) +
                     "   (the donor has %d; the original files have at most %d; a 15,424-vertex port crashed the "
                     "game)" % (self.donor.real_vcount, KNOWN_MAX_SLOTS) +
                     ("   - EXCEEDS the format's hard cap of %d vertices, decimate the mesh" % MAX_FORMAT_VERTS
                      if min(wc.values()) > MAX_FORMAT_VERTS else ""),
                     'warn' if min(wc.values()) > lim else None)

        def load_tex(self):
            p = filedialog.askopenfilename(title="TEX file", filetypes=[("TEX", "*.tex"), ("All", "*.*")])
            if not p:
                return
            try:
                self.tex_names = read_tex_names(p)
            except Exception as e:
                messagebox.showerror("TEX", str(e))
                return
            self.cb_tname.configure(values=self.tex_names)
            self.lbl_tex.configure(text="TEX entries: " + ", ".join(self.tex_names))
            self.log("TEX read: %d entries (%s)" % (len(self.tex_names), ", ".join(self.tex_names)), 'ok')
            col = [n for n in self.tex_names if 'color' in n.lower()]
            if col:
                self.v_tname.set(col[0])
            self.nb.select(4)

        def export_ref(self):
            p = filedialog.asksaveasfilename(defaultextension=".obj", initialfile="donor_reference.obj",
                                             filetypes=[("OBJ", "*.obj")])
            if p:
                export_donor_obj(self.donor, p)
                self.log("Reference OBJ written (Y up, faces +Z, left = +X, one group per submesh): " + p, 'ok')
                self.log("Fit / pose your custom model over it, keep one group per submesh, export OBJ.")

        def optimize_clicked(self):
            p = filedialog.askopenfilename(title=".dumy to optimize", filetypes=[("DUMY", "*.dumy"), ("All", "*.*")])
            if not p:
                return
            base = os.path.splitext(os.path.basename(p))[0]
            o = filedialog.asksaveasfilename(defaultextension=".dumy", initialfile=base + "_OPT.dumy",
                                             filetypes=[("DUMY", "*.dumy")])
            if not o or os.path.abspath(o) == os.path.abspath(p):
                return
            q = self.q

            def work():
                try:
                    optimize_dumy(p, o, 'auto', log=lambda s: q.put(('log', (s, 'warn' if s.startswith('WARNING') else None))))
                    q.put(('log', ("Saved " + o, 'ok')))
                except Exception as e:      # noqa
                    q.put(('log', ("Optimize failed: %s" % e, 'err')))
                q.put(('done', lambda: None))
            self.busy = True
            threading.Thread(target=work, daemon=True).start()

        def export_dae_clicked(self):
            base = os.path.splitext(os.path.basename(self.donor_path))[0]
            p = filedialog.asksaveasfilename(defaultextension=".dae", initialfile=base + ".dae",
                                             filetypes=[("COLLADA", "*.dae")])
            if not p:
                return
            try:
                export_dae(self.donor, p, log=lambda s: self.log(s, 'ok'))
            except Exception as e:
                self.log("DAE export failed: %s" % e, 'err')
                return
            self.log("Y up, character faces +Z, left = +X (no mirroring). Joint positions are estimates; weights, "
                     "UVs, colours, normals and submeshes are exact. Re-import it with 'Load custom .obj / .dae'.")

        # ---------------------------------------------------------- mapping tab
        def map_auto(self):
            if not (self.donor and self.obj):
                return
            self.mapping = default_mapping(self.obj, self.donor)
            self.fill_map()

        def fill_map(self):
            for r in self.tv_map.get_children():
                self.tv_map.delete(r)
            for name, c in self.mapping.items():
                self.tv_map.insert('', 'end', iid=name, values=self._maprow(name, c))
            for w_ in mapping_warnings(self.obj, self.mapping, self.donor):
                self.log("WARNING: " + w_, 'warn')
            self.xf_changed()

        def _maprow(self, name, c):
            bone = '-' if c['bone'] is None else self.bone_label(c['bone'])
            col = 'auto'
            if c['color'] is not None:
                pal = self.donor.palette
                col = "%d (%s)" % (c['color'], pal_label(pal[c['color']]) if c['color'] < len(pal) else "?")
            return (name, len(self.obj.groups[name]),
                    'skip' if c['block'] is None else "submesh %d" % c['block'], bone, col)

        def _map_sel(self, _e=None):
            sel = self.tv_map.selection()
            if not sel:
                return
            c = self.mapping[sel[0]]
            self.cb_blk.current(0 if c['block'] is None else c['block'] + 1)
            self.cb_bone.current(0 if c['bone'] is None else c['bone'] + 1)
            self.sp_col.current(0 if c['color'] is None else c['color'] + 1)

        def map_apply(self):
            for iid in self.tv_map.selection():
                c = self.mapping[iid]
                i = self.cb_blk.current()
                c['block'] = None if i <= 0 else i - 1
                j = self.cb_bone.current()
                c['bone'] = None if j <= 0 else j - 1
                k = self.sp_col.current()
                c['color'] = None if k <= 0 else k - 1
                self.tv_map.item(iid, values=self._maprow(iid, c))
            self.xf_changed()

        # ---------------------------------------------------------- transform
        def xf_enabled(self):
            v = getattr(self, 'v_xf_on', None)
            return True if v is None else bool(v.get())

        def xf_toggle(self):
            if self._modal is not None:
                self.modal_end(False)
            on = self.xf_enabled()
            for w in self._xf_widgets:
                w.state(['!disabled'] if on else ['disabled'])
            if on:
                self.log("Transform & fit enabled (your scale / offset / flip values are used again; "
                         "press 'Auto-fit to donor' to refit).")
            else:
                self.log("Transform & fit disabled: the custom model's coordinates are used as-is "
                         "(scale 1, no flip / swap, offset 0, no auto-fit).", 'warn')
            self.xf_changed()
            if self.donor and self.obj:
                self.log_weld_counts()

        def cur_xf(self):
            if not self.xf_enabled():
                return Xform(1.0, (False, False, False), False, (0.0, 0.0, 0.0))

            def fl(s, default):
                try:
                    return float(s)
                except ValueError:
                    return default
            return Xform(fl(self.v_scale.get(), 1.0), [v.get() for v in self.v_flip], self.v_swap.get(),
                         [fl(v.get(), 0.0) for v in self.v_off], [fl(v.get(), 1.0) for v in self.v_ax])

        def preset(self, fx, fy, fz, sw):
            for v, val in zip(self.v_flip, (fx, fy, fz)):
                v.set(val)
            self.v_swap.set(sw)
            self.auto_fit_clicked()

        def auto_fit_clicked(self):
            if not (self.donor and self.obj) or not self.xf_enabled():
                return
            self._xf_push()
            xf = auto_fit(self.donor, self.obj, self.cur_xf())
            self._silent = True
            self.v_scale.set("%.5f" % xf.scale)
            for v in self.v_ax:
                v.set("1.0")
            for v, o in zip(self.v_off, xf.offset):
                v.set("%.4f" % o)
            self._silent = False
            self.xf_changed()

        def xf_changed(self):
            if getattr(self, '_silent', False) or not (self.donor and self.obj):
                return
            xf = self.cur_xf()
            used = set()
            self._cust_edges = []
            seen = set()
            for name, tris in self.obj.groups.items():
                if self.mapping.get(name, {}).get('block') is None:
                    continue
                for t in tris:
                    ids = [c[0] for c in t]
                    used.update(ids)
                    for a, b in ((0, 1), (1, 2), (2, 0)):
                        e = (min(ids[a], ids[b]), max(ids[a], ids[b]))
                        if e not in seen:
                            seen.add(e)
                            self._cust_edges.append(e)
            self._cust_pts = {i: xf.point(self.obj.V[i]) for i in used}
            if used:
                lo, hi = bbox(list(self._cust_pts.values()))
                dl, dh = bbox([self.donor.pos(i) for i in range(self.donor.real_vcount)])
                over = any(abs(c) > 127.99 for p in (lo, hi) for c in p)
                self.lbl_fit.configure(
                    text="custom bbox  x %.1f..%.1f   y %.1f..%.1f   z %.1f..%.1f\n"
                         "donor  bbox  x %.1f..%.1f   y %.1f..%.1f   z %.1f..%.1f%s" %
                         (lo[0], hi[0], lo[1], hi[1], lo[2], hi[2], dl[0], dh[0], dl[1], dh[1], dl[2], dh[2],
                          "\nWARNING: custom mesh leaves the ±128 range and will be clamped" if over else ""))
            self.schedule_redraw()

        # ------------------------------------------- Blender-style grab / scale
        def _xf_snapshot(self):
            return dict(scale=self.v_scale.get(), ax=[v.get() for v in self.v_ax],
                        off=[v.get() for v in self.v_off], flip=[v.get() for v in self.v_flip],
                        swap=self.v_swap.get())

        def _xf_restore(self, sn):
            self._silent = True
            self.v_scale.set(sn['scale'])
            for v, x in zip(self.v_ax, sn['ax']):
                v.set(x)
            for v, x in zip(self.v_off, sn['off']):
                v.set(x)
            for v, x in zip(self.v_flip, sn['flip']):
                v.set(x)
            self.v_swap.set(sn['swap'])
            self._silent = False

        def _xf_push(self, sn=None):
            self._xf_undo.append(sn or self._xf_snapshot())
            del self._xf_undo[:-50]

        def xf_undo(self):
            if self._modal is not None or not self._xf_undo:
                return
            self._xf_restore(self._xf_undo.pop())
            self.xf_changed()
            self.log("Transform: undo.")

        def _cv_pointer(self):
            return (self.cv.winfo_pointerx() - self.cv.winfo_rootx(),
                    self.cv.winfo_pointery() - self.cv.winfo_rooty())

        def _proj_pt(self, p):
            """Same projection as redraw(): donor-space point -> canvas pixels."""
            w, h, ctr, sc = self._vstate
            cy, sy = math.cos(self.yaw), math.sin(self.yaw)
            cp, sp = math.cos(self.pitch), math.sin(self.pitch)
            x, y, z = p[0] - ctr[0], p[1] - ctr[1], p[2] - ctr[2]
            x, z = x * cy + z * sy, -x * sy + z * cy
            y, z = y * cp - z * sp, y * sp + z * cp
            return (w / 2 + self.pan[0] + x * sc, h / 2 + self.pan[1] + y * sc)

        def modal_start(self, kind):
            if self._modal is not None:
                return
            if not (self.donor and self.obj):
                self.log("Load a donor and a custom model first.", 'warn')
                return
            if not self.xf_enabled():
                self.log("Transform & fit is disabled - tick 'Enable transform & fit' to grab / scale.", 'warn')
                return
            if not self._cust_pts or not self._vstate:
                self.log("Nothing to move: no OBJ group is mapped to a submesh.", 'warn')
                return
            px, py = self._cv_pointer()
            inside = 0 <= px < self.cv.winfo_width() and 0 <= py < self.cv.winfo_height()
            xf = self.cur_xf()
            self._modal = dict(kind=kind, snap=self._xf_snapshot(), base=(xf.scale, xf.stretch, xf.offset),
                               pivot=pivot_point(list(self._cust_pts.values()), self.cb_pivot.get()),
                               start=(px, py) if inside else None, last=(px, py), acc=[0.0, 0.0],
                               axis=None, excl=False, buf=['', '', ''], idx=0, ctrl=False, shift=False,
                               val=(0.0, 0.0, 0.0), k=1.0)
            self.cv.focus_set()
            self.cv.configure(cursor='fleur' if kind == 'grab' else 'sizing')
            self.redraw(fast=True)

        def modal_end(self, confirm):
            m, self._modal = self._modal, None
            if m is None:
                return
            self.cv.configure(cursor='')
            if confirm:
                self._xf_push(m['snap'])
                self.log("%s confirmed:  scale %.5f   stretch %s   offset %s" % (
                    'Grab' if m['kind'] == 'grab' else 'Scale', float(self.v_scale.get()),
                    " ".join(v.get() for v in self.v_ax), " ".join(v.get() for v in self.v_off)))
            else:
                self._xf_restore(m['snap'])
            self.xf_changed()

        @staticmethod
        def _num(s):
            try:
                return float(s)
            except ValueError:
                return None

        def _modal_motion(self, e):
            m = self._modal
            if m is None:
                return
            m['ctrl'], m['shift'] = bool(e.state & 0x4), bool(e.state & 0x1)
            if m['start'] is None:
                m['start'] = (e.x, e.y)
            else:
                f = 0.1 if m['shift'] else 1.0
                m['acc'][0] += (e.x - m['last'][0]) * f
                m['acc'][1] += (e.y - m['last'][1]) * f
            m['last'] = (e.x, e.y)
            self._modal_update()

        def _modal_update(self):
            m = self._modal
            if m is None or m['start'] is None:
                return
            scale0, stretch0, off0 = m['base']
            typed = [self._num(b) for b in m['buf']]
            sc = self._vstate[3]
            if m['kind'] == 'grab':
                d = grab_delta(m['acc'][0], m['acc'][1], sc, view_basis(self.yaw, self.pitch),
                               m['axis'], m['excl'], typed, m['ctrl'])
                m['val'] = d
                scale, stretch, off = scale0, stretch0, tuple(off0[i] + d[i] for i in range(3))
            else:
                if typed[0] is not None:
                    k = typed[0]
                else:
                    pv = self._proj_pt(m['pivot'])
                    vx, vy = m['start'][0] + m['acc'][0], m['start'][1] + m['acc'][1]
                    d0 = max(math.hypot(m['start'][0] - pv[0], m['start'][1] - pv[1]), 10.0)
                    k = math.hypot(vx - pv[0], vy - pv[1]) / d0
                    if m['ctrl']:
                        k = max(round(k * 10) / 10.0, 0.1)
                m['k'] = k
                K = scale_factors(k, m['axis'], m['excl'])
                scale, stretch, off = apply_scale(scale0, stretch0, off0, m['pivot'], K, m['axis'] is None)
            self._silent = True
            self.v_scale.set("%.5f" % scale)
            for v, x in zip(self.v_ax, stretch):
                v.set("%.5f" % x)
            for v, x in zip(self.v_off, off):
                v.set("%.4f" % x)
            self._silent = False
            xf = self.cur_xf()
            V = self.obj.V
            self._cust_pts = {i: xf.point(V[i]) for i in self._cust_pts}
            self.redraw(fast=True)

        def _key(self, e):
            m = self._modal
            ks, low, ctrl, shift = e.keysym, e.keysym.lower(), bool(e.state & 0x4), bool(e.state & 0x1)
            if m is None:
                if ctrl and low == 'z':
                    self.xf_undo()
                    return 'break'
                if not ctrl and low in ('g', 's'):
                    self.modal_start('grab' if low == 'g' else 'scale')
                    return 'break'
                return None
            if ks in ('Return', 'KP_Enter'):
                self.modal_end(True)
            elif ks == 'Escape':
                self.modal_end(False)
            elif low in ('x', 'y', 'z') and not ctrl:
                k = 'xyz'.index(low)
                if m['axis'] == k and m['excl'] == shift:
                    m['axis'], m['excl'] = None, False
                else:
                    m['axis'], m['excl'] = k, shift
                m['buf'] = ['', '', '']
                m['idx'] = k if (m['kind'] == 'grab' and m['axis'] is not None and not m['excl']) else 0
                self._modal_update()
            elif ks == 'Tab':
                if m['kind'] == 'grab' and not (m['axis'] is not None and not m['excl']):
                    m['idx'] = (m['idx'] + 1) % 3
                    self.redraw(fast=True)
            elif ks == 'BackSpace':
                b = m['buf']
                b[m['idx']] = b[m['idx']][:-1]
                self._modal_update()
            elif e.char and e.char in '0123456789.':
                m['buf'][m['idx']] += e.char
                self._modal_update()
            elif ks in ('minus', 'KP_Subtract'):
                b = m['buf']
                b[m['idx']] = b[m['idx']][1:] if b[m['idx']].startswith('-') else '-' + b[m['idx']]
                self._modal_update()
            return 'break'

        def _key_global(self, e):
            """Window-wide key hook: G / S / Ctrl+Z act while the pointer is over the preview and no text field
            has the keyboard focus (so typing in the scale / offset boxes is never hijacked)."""
            try:
                foc = self.focus_get()
            except Exception:       # noqa  (Tk can raise for combobox popdowns)
                foc = None
            if foc is self.cv:
                return None         # the canvas binding already handled it
            if self._modal is not None:
                self.cv.focus_set()
                return self._key(e)
            if foc is not None and foc.winfo_class() in ('Entry', 'TEntry', 'Text', 'TCombobox', 'Spinbox',
                                                         'TSpinbox'):
                return None
            try:
                over = self.winfo_containing(*self.winfo_pointerxy()) is self.cv
            except Exception:       # noqa
                over = False
            if not over:
                return None
            r = self._key(e)
            if r:
                self.cv.focus_set()
            return r

        def _draw_modal(self, cv, w, h, proj, ext):
            m = self._modal
            col = ('#f38ba8', '#a6e3a1', '#89b4fa')
            if m['axis'] is not None and not m['excl']:
                a = [0.0, 0.0, 0.0]
                a[m['axis']] = ext * 2
                c = m['pivot']
                p0 = proj((c[0] - a[0], c[1] - a[1], c[2] - a[2]))
                p1 = proj((c[0] + a[0], c[1] + a[1], c[2] + a[2]))
                cv.create_line(p0[0], p0[1], p1[0], p1[1], fill=col[m['axis']], dash=(6, 4))
            if m['kind'] == 'grab':
                d = m['val']
                txt = "Grab   dX %.3f   dY %.3f   dZ %.3f" % d
            else:
                txt = "Scale   x %.3f" % m['k']
                if m['k'] < 0.001:
                    txt += "   (min 0.001 - use the flip boxes to mirror)"
            if m['axis'] is not None:
                txt += "    [%s%s]" % ('not ' if m['excl'] else '', 'XYZ'[m['axis']])
            if any(m['buf']):
                txt += "    typed: " + " | ".join(b or "_" for b in m['buf']) if m['kind'] == 'grab' \
                    else "    typed: " + (m['buf'][0] or "_")
            if m['start'] is None:
                txt += "    (move the mouse over the preview)"
            cv.create_text(10, h - 26, anchor='sw', fill="#ffffff", font=("Segoe UI", 10, "bold"), text=txt)
            cv.create_text(10, h - 8, anchor='sw', fill="#9aa0a6", font=("Segoe UI", 8), width=max(w - 20, 100),
                           text="X/Y/Z axis (Shift = exclude)   type a value   Tab next field   Shift fine   "
                                "Ctrl snap   click/Enter confirm   right-click/Esc cancel")

        # ---------------------------------------------------------- textures tab
        def fill_tex(self):
            for r in self.tv_tex.get_children():
                self.tv_tex.delete(r)
            for i, (n, e, t) in enumerate(self.names):
                self.tv_tex.insert('', 'end', iid=str(i), values=(i, n, e))

        def _tex_sel(self, _e=None):
            sel = self.tv_tex.selection()
            if sel:
                n, e, _ = self.names[int(sel[0])]
                self.v_tname.set(n)
                self.v_text.set(e)

        def _tex_ok(self, n, e):
            lim = 16 if self.v_long.get() else 10
            if len((n.encode('latin1', 'replace') + b'\0' + e.encode('latin1', 'replace') + b'\0')) > lim or not n:
                messagebox.showerror("Texture name", "'%s.%s' needs more than %d bytes (name + ext + 2 terminators). "
                                     "Both sample files only show names up to 10 bytes." % (n, e, lim))
                return False
            return True

        def tex_set(self):
            n, e = self.v_tname.get().strip(), self.v_text.get().strip()
            if not self._tex_ok(n, e):
                return
            for iid in self.tv_tex.selection():
                self.names[int(iid)][0], self.names[int(iid)][1] = n, e
            self.fill_tex()

        def tex_set_all(self, blood):
            n, e = self.v_tname.get().strip(), self.v_text.get().strip()
            if not self._tex_ok(n, e):
                return
            for i, nm in enumerate(self.names):
                is_blood = 'blood' in self.donor.names[i][0].lower()
                if is_blood == blood:
                    nm[0], nm[1] = n, e
            self.fill_tex()

        def tex_auto(self):
            if not (self.donor and self.obj):
                messagebox.showinfo("Texture names", "Load a donor and a .dae first.")
                return
            nb = 16 if self.v_long.get() else 10
            n = auto_texture_names(self.obj, self.mapping, self.donor, self.names, nb,
                                   lambda s: self.log(s, 'warn' if ('too long' in s or 'does not fit' in s) else None))
            if not (getattr(self.obj, 'meta', {}) or {}).get('group_textures'):
                self.log("The model's materials reference no textures (use a .dae whose materials have image "
                         "textures, or an .obj whose .mtl has map_Kd lines).", 'warn')
            self.fill_tex()

        def tex_reset(self):
            self.names = [list(x) for x in self.donor.names]
            self.fill_tex()

        # ---------------------------------------------------------- heat-map / inspector
        def set_heat(self, _e=None):
            if not self.donor:
                return
            sel = self.tv_bones.selection()
            if sel and self.v_heat.get():
                b = int(self.tv_bones.item(sel[0], 'values')[0])
                self._heat = [w.get(b, 0.0) for w in self.donor.weights()]
                self._heat_bone = b
            else:
                self._heat = None
            self.redraw()

        def heat_alpha(self):
            if not self.donor or self.donor.stride != 6:
                return
            d = self.donor
            self._heat = [(d.palette[d.vcol.get(i, 0)][3] / 255.0) if d.vcol.get(i, 0) < len(d.palette) else 0.0
                          for i in range(d.real_vcount)]
            self._heat_bone = None
            self.v_show_d.set(True)
            self.redraw()

        @staticmethod
        def heat_color(t):
            if t < 0.01:
                return "#3a3f4a"
            stops = [(0.0, (40, 90, 255)), (0.25, (0, 200, 255)), (0.5, (60, 220, 90)),
                     (0.75, (255, 220, 0)), (1.0, (255, 50, 40))]
            for (t0, c0), (t1, c1) in zip(stops, stops[1:]):
                if t <= t1:
                    f = (t - t0) / (t1 - t0)
                    return "#%02x%02x%02x" % tuple(int(c0[k] + (c1[k] - c0[k]) * f) for k in range(3))
            return "#ff3228"

        def pick(self, x, y):
            if not (self.donor and self.v_show_d.get() and self._proj):
                return
            best, bd = None, 12 ** 2
            for i, (sx, sy) in enumerate(self._proj):
                d = (sx - x) ** 2 + (sy - y) ** 2
                if d < bd:
                    best, bd = i, d
            if best is None:
                return
            self._sel_vertex = best
            self.log(vertex_weight_text(self.donor, best, self._blockmap))
            self.redraw()

        # ---------------------------------------------------------- preview
        def reset_view(self):
            self.yaw, self.pitch, self.zoom, self.pan = 0.4, 0.15, 1.0, [0.0, 0.0]
            self.redraw()

        def _d0(self, e, mode, btn=1):
            if self._modal is not None:         # LMB confirms, RMB cancels (Blender)
                if btn == 1:
                    self.modal_end(True)
                elif btn == 3:
                    self.modal_end(False)
                self._drag = self._press = None
                return
            self._drag = (mode, e.x, e.y)
            self._press = (mode, e.x, e.y)

        def _d1(self, e):
            if not self._drag:
                return
            mode, x0, y0 = self._drag
            dx, dy = e.x - x0, e.y - y0
            if mode == 'rot':
                self.yaw += dx * 0.01
                self.pitch = max(-1.5, min(1.5, self.pitch + dy * 0.01))
            else:
                self.pan[0] += dx
                self.pan[1] += dy
            self._drag = (mode, e.x, e.y)
            self.redraw(fast=True)

        def _d2(self, e):
            self._drag = None
            pr, self._press = self._press, None
            if pr and pr[0] == 'rot' and abs(e.x - pr[1]) + abs(e.y - pr[2]) < 4:
                self.pick(e.x, e.y)
            else:
                self.redraw()

        def _wheel(self, e):
            self._zoom(1.1 if e.delta > 0 else 1 / 1.1)

        def _zoom(self, f):
            self.zoom = max(0.1, min(20, self.zoom * f))
            self.redraw(fast=True)
            self.schedule_redraw()

        def _edges_from_donor(self):
            d = self.donor
            seen, out = set(), []
            n = d.real_vcount
            for b in range(len(d.blocks)):
                for t in d.triangles(b):
                    ids = [c[0] for c in t]
                    if max(ids) >= n:
                        continue
                    for a, c in ((0, 1), (1, 2), (2, 0)):
                        e = (min(ids[a], ids[c]), max(ids[a], ids[c]))
                        if e not in seen:
                            seen.add(e)
                            out.append(e)
            return out

        def schedule_redraw(self):
            if self._redraw_job:
                self.after_cancel(self._redraw_job)
            self._redraw_job = self.after(60, self.redraw)

        def redraw(self, fast=False):
            self._redraw_job = None
            cv = self.cv
            cv.delete('all')
            w, h = max(cv.winfo_width(), 50), max(cv.winfo_height(), 50)
            if not self.donor:
                cv.create_text(w // 2, h // 2, text="load a donor to preview", fill="#555")
                return
            cy, sy = math.cos(self.yaw), math.sin(self.yaw)
            cp, sp = math.cos(self.pitch), math.sin(self.pitch)
            dpts = [self.donor.pos(i) for i in range(self.donor.real_vcount)]
            lo, hi = bbox(dpts)
            ctr = [(lo[k] + hi[k]) / 2 for k in range(3)]
            ext = max(hi[k] - lo[k] for k in range(3)) or 1.0
            sc = min(w, h) * 0.9 / ext * self.zoom
            self._vstate = (w, h, ctr, sc)

            def proj(p):
                x, y, z = p[0] - ctr[0], p[1] - ctr[1], p[2] - ctr[2]
                x, z = x * cy + z * sy, -x * sy + z * cy
                y, z = y * cp - z * sp, y * sp + z * cp
                return (w / 2 + self.pan[0] + x * sc, h / 2 + self.pan[1] + y * sc)

            def draw(pts, edges, color, limit, P=None):
                step = 1
                if fast and len(edges) > limit:
                    step = len(edges) // limit + 1
                P = {} if P is None else P
                for k in range(0, len(edges), step):
                    a, b = edges[k]
                    if a not in P:
                        P[a] = proj(pts[a])
                    if b not in P:
                        P[b] = proj(pts[b])
                    col = color((a, b)) if callable(color) else color
                    cv.create_line(P[a][0], P[a][1], P[b][0], P[b][1], fill=col)

            self._proj = []
            if self.v_show_d.get():
                self._proj = [proj(p) for p in dpts]
                P = dict(enumerate(self._proj))
                heat = self._heat
                if heat is not None and len(heat) == len(dpts):
                    draw(dpts, self._don_edges,
                         lambda e: self.heat_color((heat[e[0]] + heat[e[1]]) / 2.0), 5000, P)
                    cv.create_text(10, 10, anchor='nw', fill="#dddddd", font=("Segoe UI", 9),
                                   text=("weight of %s" % self.donor.bones[self._heat_bone][0])
                                   if self._heat_bone is not None else "vertex alpha (palette)")
                    for k in range(40):
                        cv.create_rectangle(10 + k * 4, 28, 14 + k * 4, 36, outline="",
                                            fill=self.heat_color(k / 39.0))
                    cv.create_text(10, 38, anchor='nw', fill="#888", font=("Segoe UI", 8), text="0")
                    cv.create_text(170, 38, anchor='ne', fill="#888", font=("Segoe UI", 8), text="1")
                else:
                    draw(dpts, self._don_edges, "#6b7280", 5000, P)
                if self._sel_vertex is not None and self._sel_vertex < len(self._proj):
                    sx, sy = self._proj[self._sel_vertex]
                    cv.create_oval(sx - 5, sy - 5, sx + 5, sy + 5, outline="#ffffff", width=2)
            if self.v_show_c.get() and self._cust_pts:
                draw(self._cust_pts, self._cust_edges, ACCENT, 5000)
            # axes
            o = (lo[0] - ext * 0.1, hi[1] + ext * 0.05, lo[2])
            for axis, col, tgt in (('x', '#f38ba8', (ext * 0.15, 0, 0)), ('y', '#a6e3a1', (0, -ext * 0.15, 0)),
                                   ('z', '#89b4fa', (0, 0, ext * 0.15))):
                a, b = proj(o), proj((o[0] + tgt[0], o[1] + tgt[1], o[2] + tgt[2]))
                cv.create_line(a[0], a[1], b[0], b[1], fill=col, width=2)
                cv.create_text(b[0], b[1], text=axis, fill=col, anchor='sw')
            if self._modal is not None:
                self._draw_modal(cv, w, h, proj, ext)

        # ---------------------------------------------------------- port
        def update_go(self):
            ok = bool(self.donor and self.obj and not self.busy and not self.donor.layout_problem())
            self.btn_go.configure(state='normal' if ok else 'disabled')

        def port_and_save(self):
            if self.busy:
                return
            if not any(c['block'] is not None for c in self.mapping.values()):
                messagebox.showerror("Port", "No OBJ group is mapped to a submesh.")
                return
            base = os.path.splitext(os.path.basename(self.donor_path))[0]
            p = filedialog.asksaveasfilename(defaultextension=".dumy", initialfile=base + "_PORTED.dumy",
                                             filetypes=[("DUMY", "*.dumy")])
            if not p:
                return
            if os.path.abspath(p) == os.path.abspath(self.donor_path):
                messagebox.showerror("Port", "Refusing to overwrite the donor file. Pick another name.")
                return
            xf = self.cur_xf()
            wm = self.v_wmode.get()
            sb = max(self.cb_single.current(), 0)
            restrict = self.v_restrict.get()
            noface, facekw = self.v_noface.get(), self.v_facekw.get()
            cmode = self.v_cmode.get()
            nbytes = 16 if self.v_long.get() else 10
            wtxt = self.v_weld.get().strip().lower()
            try:
                weld = ('auto' if wtxt in ('', 'auto') else float(wtxt)) if self.v_weld_on.get() else None
            except ValueError:
                weld = 'auto'
            tear = bool(self.v_tear.get())
            try:
                vbud = parse_budget(self.v_budget.get())
            except ValueError:
                messagebox.showerror("Port", "Vertex cap: enter 'unlimited' or a whole number (e.g. 20000).")
                return

            names = [list(x) for x in self.names]
            mapping = OrderedDict((k, dict(v)) for k, v in self.mapping.items())
            donor, obj = self.donor, self.obj
            self.busy = True
            self.btn_go.configure(state='disabled')
            self.config(cursor="watch")
            q = self.q

            def work():
                try:
                    lg = lambda s: q.put(('log', (s, 'warn' if s.startswith('WARNING') else None)))
                    lg("Porting (weights: %s, restrict=%s) ..." % (wm, restrict))
                    out, st = port_model(donor, obj, mapping, xf, names=names, weight_mode=wm,
                                         single_bone=sb, restrict=restrict, log=lg, colour_mode=cmode,
                                         max_name_bytes=nbytes, weld_angle=weld,
                                         no_face_anim=noface, face_keywords=facekw, vert_budget=vbud,
                                         tear_weights=tear)
                    new = Dumy(out)
                    prob = new.layout_problem() or "; ".join(new.validate())
                    if prob or new.rebuild() != out:
                        raise DumyError("Output failed self-check: " + (prob or "rebuild mismatch"))
                    with open(p, 'wb') as fh:
                        fh.write(out)
                    q.put(('log', (compare_report(donor, new), None)))
                    q.put(('log', ("Saved %s (%d bytes). Output re-parsed and POF0 verified." % (p, len(out)), 'ok')))
                    warns = budget_warnings(donor, st, vbud)
                    for w_ in warns:
                        q.put(('log', ("WARNING: " + w_, 'warn')))
                    if warns:
                        q.put(('warnbox', "\n\n".join(warns)))
                except Exception as e:      # noqa
                    q.put(('log', ("Port failed: %s" % e, 'err')))
                q.put(('done', self.update_go))
            threading.Thread(target=work, daemon=True).start()

        def verify_any(self):
            p = filedialog.askopenfilename(title="DUMY to verify", filetypes=[("DUMY", "*.dumy"), ("All", "*.*")])
            if not p:
                return
            try:
                d, msgs, ident = verify_file(p)
            except Exception as e:
                self.log("Verify failed: %s" % e, 'err')
                return
            self.log("Verify %s: %d verts, %d groups, %d blocks, %d POF0 pointers — %s" %
                     (os.path.basename(p), d.vcount, len(d.groups), len(d.blocks), len(d.ptrs),
                      "OK" if not msgs and ident is not False else "PROBLEMS"),
                     'ok' if not msgs and ident is not False else 'err')
            for m in msgs[:10]:
                self.log("   " + m, 'err')
            if ident is False:
                self.log("   parse->rebuild differs (file has data this tool does not model)", 'warn')

        def run_selftest(self):
            self.log("--- self-test ---")
            try:
                ok = selftest(self.donor_path, log=lambda s: self.log(s, 'err' if 'FAIL' in s else None))
                self.log("SELF-TEST " + ("PASSED" if ok else "FAILED"), 'ok' if ok else 'err')
            except Exception as e:
                self.log("Self-test crashed: %s" % e, 'err')

    app = App()
    if driver:
        driver(app)
    else:
        app.mainloop()


# --------------------------------------------------------------------------
# CLI
# --------------------------------------------------------------------------
def main(argv=None):
    import argparse
    ap = argparse.ArgumentParser(description="WWE 13 DUMY Port Tool (GUI when run without arguments)")
    ap.add_argument('--selftest', nargs='+', metavar='DONOR.dumy', help='run the self-test on one or more donors')
    ap.add_argument('--atlas', action='store_true', help='bake all .dae textures into one atlas first (needs Pillow)')
    ap.add_argument('--one-slot', action='store_true',
                    help='donor behaviour: every colour submesh uses texture slot 0 (one texture on the whole model)')
    ap.add_argument('--long-names', action='store_true', help='allow 16-byte texture-name slots (unverified)')
    ap.add_argument('--no-mtl', action='store_true',
                    help="do not patch texture names from an .obj's .mtl (map_Kd); default is to patch them")
    ap.add_argument('--verify', metavar='FILE.dumy')
    ap.add_argument('--export-donor', nargs=2, metavar=('DONOR.dumy', 'OUT.obj'))
    ap.add_argument('--port', nargs=3, metavar=('DONOR.dumy', 'MODEL.obj', 'OUT.dumy'))
    ap.add_argument('--weights', choices=('file', 'transfer', 'blend', 'rigid', 'single'), default=None,
                    help="default: 'file' for a .dae that has skin weights, else 'transfer'")
    ap.add_argument('--colour', choices=('opaque', 'transfer', 'file'), default=None,
                    help="vertex colour of custom vertices (default: 'file' for a .dae with colours, else 'opaque')")
    ap.add_argument('--weld-angle', default='auto', help="merge vertices whose normals differ by less than this many degrees; 'auto' (default) = smallest angle that fits the size budget")
    ap.add_argument('--max-verts', default='unlimited', metavar='N|unlimited',
                    help="optional vertex cap for the 'auto' weld. Default: unlimited - no triangle/vertex limit is "
                         "applied (only the format's own cap of %d vertices stops a port)." % MAX_FORMAT_VERTS)
    ap.add_argument('--no-tear', action='store_true',
                    help="merge coincident vertices even when their skin weights differ (default: they are kept apart, "
                         "so a closed mouth can open - upper and lower lip stay separate vertices)")
    ap.add_argument('--no-weld', action='store_true', help='one vertex per (position, normal) pair, as stored in the model file')
    ap.add_argument('--optimize', nargs=2, metavar=('IN.dumy', 'OUT.dumy'), help='weld the vertices of an existing .dumy (smaller file, fewer vertices)')
    ap.add_argument('--export-dae', nargs=2, metavar=('FILE.dumy', 'OUT.dae'), help="write the whole model as COLLADA")
    ap.add_argument('--rules', metavar='FILE.dumy', help="check every decoded format rule on a .dumy")
    ap.add_argument('--compare', nargs=2, metavar=('A.dumy', 'B.dumy'), help="field-level comparison of two .dumy files")
    ap.add_argument('--weight-report', metavar='FILE.dumy', help="print the decoded skin weights of a .dumy")
    ap.add_argument('--bone', type=int, default=0, help="bone index for --weights single")
    ap.add_argument('--no-restrict', action='store_true')
    ap.add_argument('--no-face-anim', action='store_true',
                    help="disable facial animation: fold the weights of face bones (jaw, eyes, brows, lips ...) "
                         "into their nearest non-face parent bone")
    ap.add_argument('--face-keywords', default=None, metavar='LIST',
                    help="comma-separated bone-name words that count as facial (default: %s)" % FACE_KEYWORDS)
    ap.add_argument('--no-fit', action='store_true', help="use --scale/--offset instead of auto-fit")
    ap.add_argument('--no-transform', action='store_true',
                    help="disable transform and fit entirely: use the model's coordinates as-is "
                         "(ignores --scale/--offset/--flip/--swap-yz and the .dae up-axis preset)")
    ap.add_argument('--scale', type=float, default=1.0)
    ap.add_argument('--offset', type=float, nargs=3, default=(0, 0, 0))
    ap.add_argument('--stretch', type=float, nargs=3, default=(1, 1, 1), metavar=('X', 'Y', 'Z'),
                    help="extra per-axis scale in donor space (use with --no-fit; auto-fit resets it to 1)")
    ap.add_argument('--flip', default=None, help="axes to flip, e.g. 'yz' (default for OBJ; .dae uses its up axis) or '-'")
    ap.add_argument('--swap-yz', action='store_true')
    ap.add_argument('--tex', action='append', default=[], metavar='SLOT=NAME[.EXT]',
                    help="rename texture slot, e.g. --tex 0=mycolor --tex 10=myblood")
    a = ap.parse_args(argv)
    try:
        vbud = parse_budget(a.max_verts)
    except ValueError:
        ap.error("--max-verts: use 'unlimited' or a whole number")
    if a.selftest:
        res = [selftest(p_) for p_ in a.selftest]
        sys.exit(0 if all(res) else 1)
    if a.rules:
        print(rules_report(Dumy(open(a.rules, 'rb').read())))
        return
    if a.compare:
        print(compare_files(*a.compare))
        return
    if a.weight_report:
        print(weight_report(Dumy(open(a.weight_report, 'rb').read()), top=40))
        return
    if a.verify:
        d, msgs, ident = verify_file(a.verify)
        print("%s: %d verts, %d groups, %d blocks, %d POF0 ptrs; rebuild-identical=%s" %
              (a.verify, d.vcount, len(d.groups), len(d.blocks), len(d.ptrs), ident))
        for m in msgs:
            print("  PROBLEM:", m)
        sys.exit(1 if msgs else 0)
    if a.optimize:
        optimize_dumy(a.optimize[0], a.optimize[1],
                      None if a.no_weld else ('auto' if str(a.weld_angle).lower() == 'auto' else float(a.weld_angle)),
                      vert_budget=vbud, tear_weights=not a.no_tear)
        return
    if a.export_dae:
        export_dae(Dumy(open(a.export_dae[0], 'rb').read()), a.export_dae[1], log=print)
        return
    if a.export_donor:
        export_donor_obj(Dumy(open(a.export_donor[0], 'rb').read()), a.export_donor[1])
        print("written", a.export_donor[1])
        return
    if a.port:
        d = Dumy(open(a.port[0], 'rb').read())
        obj = load_obj_mtl(a.port[1], not a.no_mtl, print)
        global PER_SUBMESH_SLOTS
        PER_SUBMESH_SLOTS = not a.one_slot
        if a.atlas and a.port[1].lower().endswith('.dae'):
            _ap = maybe_bake_atlas(a.port[1], obj, print)
            if _ap:
                a.port[1] = _ap
                obj = load_model(_ap)
        is_dae = a.port[1].lower().endswith('.dae')
        if a.flip is None and is_dae:
            pre = dae_xform_preset(obj)
            xf = Xform(a.scale, pre['flip'], pre['swap_yz'] or a.swap_yz, a.offset, a.stretch)
            print(dae_summary(obj))
        else:
            fl = (a.flip if a.flip is not None else 'yz').lower()
            xf = Xform(a.scale, ('x' in fl, 'y' in fl, 'z' in fl), a.swap_yz, a.offset, a.stretch)
        wmode = a.weights or ('file' if getattr(obj, 'skin', None) else 'transfer')
        cmode = a.colour or ('file' if getattr(obj, 'VC', None) else 'opaque')
        if a.no_transform:
            xf = Xform(1.0, (False, False, False), False, (0.0, 0.0, 0.0))
        elif not a.no_fit:
            auto_fit(d, obj, xf)
        names = [list(x) for x in d.names]
        if is_dae:
            apply_dae_texture_names(obj, names, 16 if a.long_names else 10, print)
            auto_texture_names(obj, default_mapping(obj, d), d, names, 16 if a.long_names else 10, print)
        elif obj.meta.get('group_textures') and not a.no_mtl:
            auto_texture_names(obj, default_mapping(obj, d), d, names, 16 if a.long_names else 10, print)
        for spec in a.tex:
            slot, _, val = spec.partition('=')
            nm, _, ext = val.partition('.')
            names[int(slot)][0] = nm
            if ext:
                names[int(slot)][1] = ext
        out, st = port_model(d, obj, default_mapping(obj, d), xf, names=names, weight_mode=wmode,
                             single_bone=a.bone, restrict=not a.no_restrict, log=print,
                             colour_mode=cmode, max_name_bytes=16 if a.long_names else 10,
                             no_face_anim=a.no_face_anim, face_keywords=a.face_keywords,
                             weld_angle=None if a.no_weld else ('auto' if str(a.weld_angle).lower() == 'auto' else float(a.weld_angle)),
                             vert_budget=vbud, tear_weights=not a.no_tear)
        open(a.port[2], 'wb').write(out)
        print(compare_report(d, Dumy(out)))
        for w_ in budget_warnings(d, st, vbud):
            print("WARNING:", w_)
        print("saved", a.port[2], len(out), "bytes")
        return
    run_gui()


if __name__ == '__main__':
    main()
