package app.wwe2k.towii;

import android.app.Activity;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.ContentResolver;
import android.content.ContentValues;
import android.content.Context;
import android.content.Intent;
import android.database.Cursor;
import android.net.Uri;
import android.os.Bundle;
import android.os.Environment;
import android.provider.MediaStore;
import android.provider.OpenableColumns;
import android.util.Log;
import android.view.WindowManager;
import android.webkit.JavascriptInterface;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Toast;

import com.chaquo.python.PyObject;
import com.chaquo.python.Python;
import com.chaquo.python.android.AndroidPlatform;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedOutputStream;
import java.io.ByteArrayInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.Arrays;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.zip.Deflater;
import java.util.zip.ZipEntry;
import java.util.zip.ZipOutputStream;

/**
 * The tool as a native Android app: the page (assets/index.html, the same UI as the browser version) runs in a WebView,
 * the converter runs as real CPython (Chaquopy) with numpy / scipy / Pillow on a background thread.
 * Files are picked with the system file picker and copied into the app's private folder; results are saved to Downloads/WWE2K_to_Wii.
 */
public class MainActivity extends Activity {
    static final String HOST = "appassets.androidplatform.net";
    static final String TAG = "WWE2K";
    static final int REQ_CHAR = 101, REQ_DONOR = 102, REQ_HAIR = 103;

    private WebView web;
    private File baseDir, inDir, outDir;
    private final ExecutorService py = Executors.newSingleThreadExecutor();     // all Python work, one job at a time
    private final ExecutorService io = Executors.newCachedThreadPool();         // file copies / saving
    private volatile int gen = 0;                                                // bumped by Cancel: results of older jobs are dropped
    private volatile PyObject mod = null;
    private final Sink sink = new Sink(this);

    /** Python calls sink.log(line) for every line of the converter's log. */
    public static class Sink {
        private final MainActivity act;
        volatile int jobGen = 0;

        Sink(MainActivity a) {
            act = a;
        }

        public void log(String s) {
            if (jobGen != act.gen) {
                return;
            }
            act.sendLog(s);
        }
    }

    // ------------------------------------------------------------------------------------------ life cycle
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        baseDir = new File(getFilesDir(), "wwe");
        inDir = new File(baseDir, "in");
        outDir = new File(baseDir, "out");
        inDir.mkdirs();
        outDir.mkdirs();

        web = new WebView(this);
        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setAllowFileAccess(false);
        s.setAllowContentAccess(false);
        WebView.setWebContentsDebuggingEnabled(true);
        web.addJavascriptInterface(new Bridge(), "NativeBridge");
        web.setWebViewClient(new WebViewClient() {
            @Override
            public WebResourceResponse shouldInterceptRequest(WebView view, WebResourceRequest request) {
                return serve(request.getUrl());
            }

            @Override
            public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                return !HOST.equals(request.getUrl().getHost());                 // nothing leaves the app
            }
        });
        setContentView(web);
        web.loadUrl("https://" + HOST + "/index.html");
    }

    @Override
    public void onBackPressed() {
        moveTaskToBack(true);                                                    // a running conversion keeps going
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        if (web != null) {
            web.destroy();
        }
    }

    // ------------------------------------------------------------------------------------------ serving the page and the results
    private WebResourceResponse serve(Uri u) {
        if (!HOST.equals(u.getHost())) {
            return notFound();
        }
        String p = u.getPath();
        if (p == null || p.equals("/") || p.equals("/index.html")) {
            try {
                return new WebResourceResponse("text/html", "utf-8", getAssets().open("index.html"));
            } catch (IOException e) {
                return notFound();
            }
        }
        if (p.startsWith("/out/")) {
            File f = new File(outDir, new File(p.substring(5)).getName());           // getName(): no sub-folders / ".."
            if (f.isFile()) {
                try {
                    return new WebResourceResponse(mimeFor(f.getName()), null, new FileInputStream(f));
                } catch (IOException e) {
                    return notFound();
                }
            }
        }
        return notFound();
    }

    private static WebResourceResponse notFound() {
        return new WebResourceResponse("text/plain", "utf-8", 404, "Not Found", null, new ByteArrayInputStream(new byte[0]));
    }

    static String mimeFor(String name) {
        String n = name.toLowerCase();
        if (n.endsWith(".png")) {
            return "image/png";
        }
        if (n.endsWith(".zip")) {
            return "application/zip";
        }
        if (n.endsWith(".html")) {
            return "text/html";
        }
        return "application/octet-stream";
    }

    // ------------------------------------------------------------------------------------------ messages to the page
    private void toJs(final JSONObject m) {
        final String js = "window.__nativeMsg && window.__nativeMsg(" + JSONObject.quote(m.toString()) + ")";
        runOnUiThread(new Runnable() {
            @Override
            public void run() {
                if (web != null) {
                    web.evaluateJavascript(js, null);
                }
            }
        });
    }

    private void callJs(final String code) {
        runOnUiThread(new Runnable() {
            @Override
            public void run() {
                if (web != null) {
                    web.evaluateJavascript(code, null);
                }
            }
        });
    }

    private void send(String t, Object... kv) {
        JSONObject m = new JSONObject();
        try {
            m.put("t", t);
            for (int i = 0; i + 1 < kv.length; i += 2) {
                m.put((String) kv[i], kv[i + 1]);
            }
        } catch (JSONException e) {
            Log.e(TAG, "json", e);
        }
        toJs(m);
    }

    void sendLog(String s) {
        send("log", "s", s);
    }

    private void fail(int g, String where, Throwable e) {
        Log.e(TAG, where, e);
        if (g != gen) {
            return;
        }
        String msg = String.valueOf(e.getMessage());
        send("error", "where", where, "s", msg);
    }

    private void toast(final String s) {
        runOnUiThread(new Runnable() {
            @Override
            public void run() {
                Toast.makeText(MainActivity.this, s, Toast.LENGTH_LONG).show();
            }
        });
    }

    // ------------------------------------------------------------------------------------------ the bridge the page calls
    public class Bridge {
        @JavascriptInterface
        public void post(String json) {
            try {
                JSONObject m = new JSONObject(json);
                String cmd = m.optString("cmd");
                final int g = gen;
                if (cmd.equals("init")) {
                    py.execute(new Runnable() {
                        @Override
                        public void run() {
                            doInit(g);
                        }
                    });
                } else if (cmd.equals("rm")) {
                    new File(inDir, new File(m.optString("name")).getName()).delete();
                } else if (cmd.equals("detect")) {
                    py.execute(new Runnable() {
                        @Override
                        public void run() {
                            doDetect(g);
                        }
                    });
                } else if (cmd.equals("run")) {
                    final String opts = m.getJSONObject("opts").toString();
                    py.execute(new Runnable() {
                        @Override
                        public void run() {
                            doRun(g, opts);
                        }
                    });
                }
            } catch (JSONException e) {
                fail(gen, "post", e);
            }
        }

        @JavascriptInterface
        public void cancel() {
            gen++;                                                               // whatever the running job reports from now on is dropped
            io.execute(new Runnable() {
                @Override
                public void run() {
                    try {
                        PyObject m = mod;
                        if (m != null) {
                            m.callAttr("cancel");
                        }
                    } catch (Throwable e) {
                        Log.w(TAG, "cancel", e);
                    }
                }
            });
        }

        @JavascriptInterface
        public void pick(final String key) {
            runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    Intent i = new Intent(Intent.ACTION_OPEN_DOCUMENT);
                    i.addCategory(Intent.CATEGORY_OPENABLE);
                    i.setType("*/*");
                    startActivityForResult(i, reqFor(key));
                }
            });
        }

        @JavascriptInterface
        public void save(final String name) {
            io.execute(new Runnable() {
                @Override
                public void run() {
                    try {
                        File f = new File(outDir, new File(name).getName());
                        InputStream in = new FileInputStream(f);
                        try {
                            saveToDownloads(f.getName(), mimeFor(f.getName()), in);
                        } finally {
                            in.close();
                        }
                        String msg = "Saved " + f.getName() + " to Downloads/WWE2K_to_Wii";
                        toast(msg);
                        callJs("window.__nativeSaved && window.__nativeSaved(" + JSONObject.quote(msg) + ")");
                    } catch (Exception e) {
                        Log.e(TAG, "save", e);
                        toast("Could not save: " + e.getMessage());
                    }
                }
            });
        }

        @JavascriptInterface
        public void saveAll(final String zipName) {
            io.execute(new Runnable() {
                @Override
                public void run() {
                    try {
                        saveZipToDownloads(zipName);
                        String msg = "Saved " + zipName + " to Downloads/WWE2K_to_Wii";
                        toast(msg);
                        callJs("window.__nativeSaved && window.__nativeSaved(" + JSONObject.quote(msg) + ")");
                    } catch (Exception e) {
                        Log.e(TAG, "saveAll", e);
                        toast("Could not save: " + e.getMessage());
                    }
                }
            });
        }

        @JavascriptInterface
        public void keepAwake(final boolean on) {
            runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    if (on) {
                        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
                    } else {
                        getWindow().clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
                    }
                }
            });
        }

        @JavascriptInterface
        public void copy(final String text) {
            runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    ClipboardManager cm = (ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);
                    if (cm != null) {
                        cm.setPrimaryClip(ClipData.newPlainText("log", text));
                        Toast.makeText(MainActivity.this, "Log copied", Toast.LENGTH_SHORT).show();
                    }
                }
            });
        }
    }

    // ------------------------------------------------------------------------------------------ Python jobs (background thread)
    private void doInit(int g) {
        try {
            if (!Python.isStarted()) {
                Python.start(new AndroidPlatform(MainActivity.this));
            }
            mod = Python.getInstance().getModule("android_main");
            sink.jobGen = g;
            String ver = mod.callAttr("init", baseDir.getAbsolutePath(), sink).toString();
            if (g == gen) {
                send("ready", "version", ver + " (native)");
            }
        } catch (Throwable e) {
            fail(g, "init", e);
        }
    }

    private void doDetect(int g) {
        try {
            sink.jobGen = g;
            String json = mod.callAttr("detect").toString();
            if (g == gen) {
                send("detected", "json", json);
            }
        } catch (Throwable e) {
            fail(g, "detect", e);
        }
    }

    private void doRun(int g, String optsJson) {
        try {
            sink.jobGen = g;
            String res = mod.callAttr("run", optsJson).toString();
            if (g != gen) {
                return;
            }
            JSONArray arr = new JSONArray(res);
            for (int i = 0; i < arr.length(); i++) {
                JSONObject o = arr.getJSONObject(i);
                send("file", "name", o.getString("name"), "size", o.getLong("size"));
            }
            send("finished");
        } catch (Throwable e) {
            fail(g, "run", e);
        }
    }

    // ------------------------------------------------------------------------------------------ picking files
    private static int reqFor(String key) {
        return key.equals("char") ? REQ_CHAR : key.equals("donor") ? REQ_DONOR : REQ_HAIR;
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (resultCode != RESULT_OK || data == null || data.getData() == null) {
            return;
        }
        final String key, target;
        if (requestCode == REQ_CHAR) {
            key = "char";
            target = "char.zip";
        } else if (requestCode == REQ_DONOR) {
            key = "donor";
            target = "donor.pac";
        } else if (requestCode == REQ_HAIR) {
            key = "hair";
            target = "hair.pac";
        } else {
            return;
        }
        final Uri uri = data.getData();
        io.execute(new Runnable() {
            @Override
            public void run() {
                copyPicked(key, target, uri);
            }
        });
    }

    private void copyPicked(String key, String target, Uri uri) {
        File part = new File(inDir, target + ".part");
        try {
            String name = target;
            long size = -1;
            Cursor c = getContentResolver().query(uri, null, null, null, null);
            if (c != null) {
                try {
                    if (c.moveToFirst()) {
                        int ni = c.getColumnIndex(OpenableColumns.DISPLAY_NAME);
                        int si = c.getColumnIndex(OpenableColumns.SIZE);
                        if (ni >= 0 && !c.isNull(ni)) {
                            name = c.getString(ni);
                        }
                        if (si >= 0 && !c.isNull(si)) {
                            size = c.getLong(si);
                        }
                    }
                } finally {
                    c.close();
                }
            }
            InputStream in = getContentResolver().openInputStream(uri);
            if (in == null) {
                throw new IOException("cannot open the file");
            }
            long done = 0;
            int lastPct = -1;
            OutputStream out = new FileOutputStream(part);
            try {
                byte[] buf = new byte[1 << 16];
                int n;
                while ((n = in.read(buf)) > 0) {
                    out.write(buf, 0, n);
                    done += n;
                    if (size > 0) {
                        int pct = (int) (done * 100 / size);
                        if (pct != lastPct && pct % 5 == 0) {
                            lastPct = pct;
                            callJs("window.__nativeProgress && window.__nativeProgress(" + JSONObject.quote(key) + "," + pct + ")");
                        }
                    }
                }
            } finally {
                out.close();
                in.close();
            }
            File dst = new File(inDir, target);
            dst.delete();
            if (!part.renameTo(dst)) {
                throw new IOException("cannot store the file");
            }
            callJs("window.__nativePicked && window.__nativePicked(" + JSONObject.quote(key) + "," + JSONObject.quote(name) + "," + dst.length() + ")");
        } catch (Exception e) {
            Log.e(TAG, "pick", e);
            part.delete();
            callJs("window.__nativeFailed && window.__nativeFailed(" + JSONObject.quote(key) + "," + JSONObject.quote("Could not read the file: " + e.getMessage()) + ")");
        }
    }

    // ------------------------------------------------------------------------------------------ saving results
    private OutputStream openDownload(String displayName, String mime, Uri[] uriOut) throws IOException {
        ContentResolver cr = getContentResolver();
        ContentValues v = new ContentValues();
        v.put(MediaStore.MediaColumns.DISPLAY_NAME, displayName);
        v.put(MediaStore.MediaColumns.MIME_TYPE, mime);
        v.put(MediaStore.MediaColumns.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS + "/WWE2K_to_Wii");
        Uri uri = cr.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, v);
        if (uri == null) {
            throw new IOException("cannot create " + displayName + " in Downloads");
        }
        uriOut[0] = uri;
        OutputStream out = cr.openOutputStream(uri);
        if (out == null) {
            throw new IOException("cannot write " + displayName);
        }
        return out;
    }

    private void saveToDownloads(String displayName, String mime, InputStream in) throws IOException {
        Uri[] u = new Uri[1];
        OutputStream out = openDownload(displayName, mime, u);
        try {
            byte[] buf = new byte[1 << 16];
            int n;
            while ((n = in.read(buf)) > 0) {
                out.write(buf, 0, n);
            }
        } finally {
            out.close();
        }
    }

    private void saveZipToDownloads(String zipName) throws IOException {
        File[] files = outDir.listFiles();
        if (files == null || files.length == 0) {
            throw new IOException("there are no result files");
        }
        Arrays.sort(files);
        Uri[] u = new Uri[1];
        OutputStream raw = openDownload(zipName, "application/zip", u);
        ZipOutputStream zip = new ZipOutputStream(new BufferedOutputStream(raw));
        try {
            zip.setLevel(Deflater.BEST_SPEED);
            byte[] buf = new byte[1 << 16];
            for (File f : files) {
                if (!f.isFile()) {
                    continue;
                }
                zip.putNextEntry(new ZipEntry(f.getName()));
                InputStream in = new FileInputStream(f);
                try {
                    int n;
                    while ((n = in.read(buf)) > 0) {
                        zip.write(buf, 0, n);
                    }
                } finally {
                    in.close();
                }
                zip.closeEntry();
            }
        } finally {
            zip.close();
        }
    }
}
