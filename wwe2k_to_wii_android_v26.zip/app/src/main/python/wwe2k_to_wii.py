#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
WWE 2K to Wii Model Converter  -  by Jatin Talwar (Mod Place Wii)
WWE 2K26 -> WWE character porter (WWE 13 Wii donors and 3-submesh donors such as ch342.pac)
===========================================================================================
Takes a WWE 2K26 character folder / zip (baseModel.mcd + attire .mcd + DDS textures) and a character .pac used as
DONOR (WWE 13 Wii ch102.pac, or the 3-submesh Wii ch342.pac), and writes a new .pac:

  * donor      : the layout is detected.  ch102-style (6 submeshes: body / legs / boots + kept mouth + kept eyes + blood
                 layer) or any other layout (e.g. ch342: 3 submeshes, no eye / mouth / blood submesh) - then every
                 submesh receives the new body and each new triangle goes to the nearest donor submesh.
  * limits     : the donor's own maximum is filled, not just approached: vertices, triangles (and, up to --size-limit,
                 DUMY bytes).  Face / torso / hands get more triangles than legs and than skin hidden under clothes.
  * culling    : skin hidden under clothing is removed conservatively (head, neck and hands are never touched, a margin of
                 skin stays under every cloth edge, only cloth that faces the same way counts as cover).
  * pose       : ONLY the legs and the finger chains are rotated to the donor's rest pose (rotation about the joints,
                 no scaling, arms / torso / head untouched).  --pose full brings back the old full-limb retarget.
  * skin       : 2K bone weights are mapped onto the Wii biped skeleton (max 3 influences).
  * materials  : 2K 'combinations' (hair / beard cards) become a hair material or a separate hair DUMY.
  * shading    : vertex colours and - by default - vertex normals are taken from the donor's nearest vertices.
  * texture    : all 2K colour maps are packed into the donor's 512x512 CMPR 'color' atlas; the same layout is also
                 exported at full resolution as <out>_atlas_4k.png (4096x4096).
  * pac        : DUMY + texture archive are re-packed (BPE) into a new EPK8/PACH, everything else untouched.

Needs: python 3.8+, numpy, scipy, Pillow  and dumy_port_tool.py (next to this file).
"""
import argparse
import collections
import fnmatch
import math
import os
import re
import shutil
import struct
import sys
import tempfile
import zipfile

import numpy as np

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)

import dumy_port_tool as T            # noqa: E402
import mcd_reader as R                # noqa: E402
import gxtex                          # noqa: E402
import pacio                          # noqa: E402
import qem                            # noqa: E402
import pose                           # noqa: E402
import texarchive                     # noqa: E402
from bonemap import map_bone, is_fallback          # noqa: E402

try:
    from scipy.spatial import cKDTree
except ImportError:                    # pragma: no cover
    cKDTree = None

# --------------------------------------------------------------------------------------------------
# configuration
# --------------------------------------------------------------------------------------------------
SKIP_MESHES = {'m_head_caruncle', 'm_tongue', 'm_teeth', 'm_mouthbag', 'm_transb_eyelash', 'm_transb_eyeshadow'}
SKIP_MATERIALS = {'lambert1', 'belt_aps', 'eye_overlay'}
ATLAS = 512
ATLAS_FOCUS = 1.0           # --atlas-focus default: 0 = the old layout (area based), 1 = head and body get a clearly larger share of the 512 atlas
SEAM_WELD = 0.3             # --seam-weld default (2K cm): vertices on open borders closer than this are merged (0 = off)
SHARPEN = 0.6               # --sharpen default: unsharp mask on the colour patches after they are shrunk into the 512 atlas (0 = off)
KEEP_TOP_ROWS = 64                   # donor atlas rows holding eye / mouth art (kept as is)
DONOR_COLOR_ENTRY = 'color'
EYE_RECT = (0, 0, 32, 64)            # atlas area of the donor's eye art (u 0..61, v 3..120 of 1024)
BLOOD_OFFSET = 0.06                  # donor units: blood layer is pushed out of the face by this much


HAIR_RECT = []
BEARD_TEX_NAME = 'trans'                       # the Wii names its hair texture 'trans'
BEARD_UV_PATCH = (0.60, 0.96, 0.45, 0.85)        # u0, u1, v0, v1: the dense strand field of combinations_rai


class Part(object):
    """One 2K material of one mesh, ready for processing (2K coordinates: Y down, feet at 0)."""
    def __init__(self):
        self.name = ''
        self.role = 'cloth'          # skin | cloth | hair
        self.tex = None              # atlas key
        self.P = None                # (n,3)
        self.N = None                # (n,3)
        self.UV = None               # (n,2)  raw 2K uv
        self.W = None                # per vertex {wii bone: w}
        self.T = None                # (m,3)
        self.block = 0
        self.alpha = False           # transparent cloth (mesh / fishnet / '_alpha' material): never counts as cover
        self.cov = None              # per vertex 1.0 = skin lies under clothing (set by the culling step)
        self.imp = None              # per vertex decimation priority


# --------------------------------------------------------------------------------------------------
# source (zip or folder)
# --------------------------------------------------------------------------------------------------
MODEL_EXT = ('.mcd', '.mdl')          # 2K26 models are .mcd (MCD!), the older 2K24 exports are .mdl (MDL!)


class Source(object):
    def __init__(self, path, log):
        self.tmp = None
        if os.path.isfile(path) and zipfile.is_zipfile(path):
            self.tmp = tempfile.mkdtemp(prefix='wwe2k_')
            log("Extracting %s ..." % os.path.basename(path))
            with zipfile.ZipFile(path) as z:
                z.extractall(self.tmp)
            path = self.tmp
        self.root = path
        self.files = {}
        for dp, dn, fn in os.walk(path):
            for f in fn:
                full = os.path.join(dp, f)
                self.files[os.path.relpath(full, path).replace('\\', '/').lower()] = full

    def close(self):
        if self.tmp:
            shutil.rmtree(self.tmp, ignore_errors=True)

    def find(self, suffix):
        suffix = suffix.lower()
        return [v for k, v in sorted(self.files.items()) if k.endswith(suffix)]

    def attires(self):
        out = []
        for k, v in sorted(self.files.items()):
            if k.endswith(MODEL_EXT) and 'basemodel' not in os.path.basename(k):
                out.append(v)
        return out

    def base(self):
        b = [v for k, v in sorted(self.files.items()) if os.path.basename(k) in ('basemodel.mcd', 'basemodel.mdl')]
        if not b:
            raise SystemExit("baseModel.mcd (or baseModel.mdl) not found in the 2K character folder")
        return b[0]

    def raw_texture(self, mcd_path, filename):
        """any texture file by its exact name ('combinations_rai.dds'), next to the mcd first, else anywhere"""
        want = filename.lower()
        d = os.path.dirname(mcd_path).lower()
        for k, v in sorted(self.files.items()):
            if os.path.basename(k) == want and os.path.dirname(v).lower().startswith(d):
                return v
        for k, v in sorted(self.files.items()):
            if os.path.basename(k) == want:
                return v
        return None

    def normal_texture(self, mcd_path, name):
        """tangent-space normal map '<name>_nrm.dds' (or _normal / _n) next to the mcd's Textures folder, else anywhere"""
        d = os.path.dirname(mcd_path).lower()
        for suffix in ('_nrm', '_normal', '_n'):
            want = (name + suffix + '.dds').lower()
            hits = [v for k, v in sorted(self.files.items()) if os.path.basename(k) == want]
            near = [v for v in hits if os.path.dirname(v).lower().startswith(d)]
            if near or hits:
                return (near or hits)[0]
        return None

    def texture(self, mcd_path, name):
        """colour texture '<name>_color.dds' next to the mcd's Textures folder (or anywhere in the character)."""
        want = (name + '_color.dds').lower()
        d = os.path.dirname(mcd_path)
        for cand in (os.path.join(d, 'Textures', want), os.path.join(d, want)):
            for k, v in self.files.items():
                if v.lower() == cand.lower():
                    return v
        for k, v in self.files.items():
            if os.path.basename(k) == want:
                return v
        return None


# --------------------------------------------------------------------------------------------------
# 2K -> parts
# --------------------------------------------------------------------------------------------------
def _top3(w):
    items = sorted(w.items(), key=lambda kv: -kv[1])[:3]
    s = sum(v for _, v in items) or 1.0
    return dict((k, v / s) for k, v in items)


def classify(mesh_name, base):
    """(role, texture key, alpha) of one mesh/material combination"""
    alpha = '_alpha' in base.lower()
    low = base.lower().replace('_alpha', '')
    if low.startswith('combinations') or low == 'hair':           # beard (combinations) and head hair (hair): strand cards
        return 'hair', 'hair', alpha
    if mesh_name.lower() == 'm_eye':
        return 'eye', 'eye', alpha
    if low in ('body', 'head'):
        return 'skin', low, alpha
    return 'cloth', low, alpha


def strand_name(base):
    """name of the strand map ('<name>_rai.dds') a hair material uses: 'combinations_ALPHA' -> 'combinations', 'hair_ALPHA' -> 'hair'"""
    low = base.lower().replace('_alpha', '')
    return 'combinations' if low.startswith('combinations') else low


VARIANT_SUFFIXES = ('_entrance', '_withbelt')


def variant_meshes(mesh_names):
    """meshes that are only alternative copies of another mesh of the same attire (M_Hair_Entrance, M_Jacket_withBelt): off by default"""
    names = set(n.lower() for n in mesh_names)
    out = {}
    for n in mesh_names:
        low = n.lower()
        if low.startswith('s_'):                                  # hidden physics helpers are skipped anyway
            continue
        for suf in VARIANT_SUFFIXES:
            if low.endswith(suf) and low[:-len(suf)] in names:
                out[n] = "%s variant of %s (off by default - tick it / use --variants to port it)" % (
                    suf[1:].replace('with', 'with '), n[:-len(suf)])
    return out


def _pat_match(pat, *names):
    """a pattern matches a name exactly (case-insensitive) or, with * / ?, as a wildcard"""
    pat = pat.strip().lower()
    if not pat:
        return False
    for n in names:
        n = n.lower()
        if pat == n:
            return True
        if ('*' in pat or '?' in pat) and fnmatch.fnmatchcase(n, pat.replace('[', '[[]')):
            return True
    return False


def split_patterns(vals):
    """--only / --exclude accept repeated options and comma separated lists"""
    out = []
    for v in (vals or []):
        out += [x.strip() for x in str(v).split(',') if x.strip()]
    return out


def part_selected(name, only=None, exclude=None):
    """name = 'Mesh/material'; a pattern may name the whole thing, only the mesh or only the material"""
    mesh, _, mat = name.partition('/')
    if only and not any(_pat_match(p, name, mesh, mat) for p in only):
        return False
    if exclude and any(_pat_match(p, name, mesh, mat) for p in exclude):
        return False
    return True


def mesh_to_parts(mcd, path, log, select=None, variants=False):
    parts = []
    names = mcd.strs
    mouth = []
    variant = {} if variants else variant_meshes([m.name for m in mcd.meshes])
    for mi, me in enumerate(mcd.meshes):
        if me.name in variant:
            log("  skip %-16s (%s)" % (me.name, variant[me.name]))
            continue
        if me.name.lower() in SKIP_MESHES:
            log("  skip %-16s (donor keeps its own eyes / mouth)" % me.name)
            if me.name.lower() in ('m_teeth', 'm_tongue', 'm_mouthbag'):
                mouth.append(me.streams['POSITION'][:, :3].astype(np.float64))     # keeps a beard from covering the mouth
            continue
        lod = mcd.lods[0][mi]
        idx = lod['idx'].reshape(-1, 3)
        subs = []
        for sub in lod['subs']:
            base = mcd.materials[sub['mat']].split(':')[0]
            if base.lower() in SKIP_MATERIALS:
                continue
            if select is not None and not select('%s/%s' % (me.name, base)):
                log("  not selected: %s/%s" % (me.name, base))
                continue
            subs.append((sub, base))
        if not subs:
            continue
        # per-vertex wii weights
        W = []
        lost, wtot = collections.defaultdict(float), 0.0
        for v in range(me.nv):
            acc = collections.defaultdict(float)
            for j in range(me.wpv):
                w = float(me.weights[v, j])
                if w > 0:
                    bn = names[me.bone_idx[v, j]]
                    acc[map_bone(bn)] += w
                    wtot += w
                    if is_fallback(bn):
                        lost[bn] += w
            W.append(_top3(acc) if acc else {'Bip': 1.0})
        if wtot and sum(lost.values()) > 0.02 * wtot:
            log("  WARNING: %s: %.0f %% of its skin weight sits on bones the Wii skeleton has no match for (%s) - they fall back to the root "
                "bone 'Bip', so that part will NOT follow the head / body when the model moves (add a rule to bonemap.py)" % (
                    me.name, 100.0 * sum(lost.values()) / wtot, ", ".join(sorted(lost, key=lost.get, reverse=True)[:5])))
        N = me.streams.get('NORMAL')
        N = N[:, :3].copy() if N is not None else np.zeros((me.nv, 3), np.float32)
        ln = np.linalg.norm(N, axis=1, keepdims=True)
        N = N / np.maximum(ln, 1e-6)
        for sub, base in subs:
            tri = idx[sub['start'] // 3: (sub['start'] + sub['count']) // 3]
            p = Part()
            p.name = '%s/%s' % (me.name, base)
            p.role, p.tex, p.alpha = classify(me.name, base)
            p.strand = strand_name(base) if p.role == 'hair' else None
            p.tex_path = None
            p.mcd = path
            used = np.unique(tri)
            remap = -np.ones(me.nv, np.int64)
            remap[used] = np.arange(len(used))
            p.P = me.streams['POSITION'][used].astype(np.float64)
            p.N = N[used]
            p.UV = me.uvs[0][used].astype(np.float64) if me.uvs else np.zeros((len(used), 2))
            p.W = [W[u] for u in used]
            p.T = remap[tri]
            parts.append(p)
            log("  part %-30s role=%-5s verts=%5d tris=%5d" % (p.name, p.role, len(used), len(tri)))
    if mouth:
        for p in parts:
            if p.role == 'skin' and p.tex == 'head':
                p.mouth_pts = np.concatenate(mouth)
    return parts


# --------------------------------------------------------------------------------------------------
# attires / detection
# --------------------------------------------------------------------------------------------------
def attire_label(path):
    """folder name of an attire mcd, e.g. '102_Default_Attire'"""
    return os.path.basename(os.path.dirname(path))


def attire_short(label):
    """'102_Default_Attire' -> 'Default_Attire', '102_Suit_2024' -> 'Suit_2024'"""
    return re.sub(r'^\d+_', '', label)


def _nn(s):
    return re.sub(r'[\s\-]+', '_', s.strip().lower())


def pick_attire(atts, wanted):
    """atts: attire .mcd paths.  wanted: None (first), a 1-based number, or a name: exact folder name, the name without the
    character number ('Suit', 'Suit_2024', 'Default_Attire'; spaces / dashes count as '_'), else a UNIQUE start / part of it."""
    if not wanted:
        return atts[0]
    w = _nn(str(wanted))
    labels = [attire_label(a) for a in atts]
    if w.isdigit() and 1 <= int(w) <= len(atts):
        return atts[int(w) - 1]
    full = [_nn(l) for l in labels]
    short = [_nn(attire_short(l)) for l in labels]
    for stage in (lambda i: w in (full[i], short[i]),
                  lambda i: short[i].startswith(w) or full[i].startswith(w),
                  lambda i: w in full[i]):
        hit = [i for i in range(len(atts)) if stage(i)]
        if len(hit) == 1:
            return atts[hit[0]]
        if len(hit) > 1:
            raise SystemExit("attire '%s' is ambiguous (%s) - give the full name, e.g. %s" % (
                wanted, ", ".join(attire_short(labels[i]) for i in hit), attire_short(labels[hit[0]])))
    raise SystemExit("attire '%s' not found. Available: %s" % (wanted, ", ".join(
        "%d = %s" % (i + 1, attire_short(l)) for i, l in enumerate(labels))))


def scan_mcd(path, src=None):
    """every mesh / material of an mcd (names, triangles, role, which colour / normal texture files exist) without
    building anything."""
    mcd = R.Mcd(path)
    out = []
    variant = variant_meshes([m.name for m in mcd.meshes])
    for mi, me in enumerate(mcd.meshes):
        lod = mcd.lods[0][mi]
        for sub in lod['subs']:
            base = mcd.materials[sub['mat']].split(':')[0]
            role, tex, alpha = classify(me.name, base)
            why = None
            if me.name.lower() in SKIP_MESHES:
                why = "skipped: the donor keeps its own eyes / mouth parts"
            elif base.lower() in SKIP_MATERIALS:
                why = "skipped: helper material"
            out.append(dict(name='%s/%s' % (me.name, base), mesh=me.name, material=base, role=role, tex=tex,
                            tris=sub['count'] // 3, alpha=alpha, skipped=why, default_off=variant.get(me.name),
                            colour=bool(src.texture(path, tex)) if (src and role not in ('hair',)) else None,
                            normal=bool(src.normal_texture(path, tex)) if (src and role not in ('hair',)) else None))
    return out


def scan_character(path, log=print):
    """-> {'attires': [(label, short, mcd path)], 'base': [parts], 'parts': {label: [parts]}}"""
    src = Source(path, log)
    try:
        atts = src.attires()
        res = dict(attires=[(attire_label(a), attire_short(attire_label(a)), a) for a in atts], parts={})
        res['base'] = scan_mcd(src.base(), src)
        for a in atts:
            res['parts'][attire_label(a)] = scan_mcd(a, src)
        return res
    finally:
        src.close()


def print_scan(res, log=print):
    def block(title, rows):
        log(title)
        log("  %-4s %-34s %-6s %7s  %-8s %s" % ("", "mesh/material (use these names)", "role", "tris", "textures", ""))
        for r in rows:
            tx = ("%s%s" % ("C" if r['colour'] else "-", "N" if r['normal'] else "-")) if r['colour'] is not None else "  "
            log("  %-4s %-34s %-6s %7d  %-8s %s" % ("skip" if r['skipped'] else ("off" if r.get('default_off') else ""), r['name'], r['role'],
                                                   r['tris'], tx, r['skipped'] or r.get('default_off') or ""))
    log("Attires (use --attire NAME or NUMBER):")
    for i, (lab, short, _) in enumerate(res['attires']):
        log("  %d = %s   (folder %s)" % (i + 1, short, lab))
    log("")
    block("BaseModel (always read):", res['base'])
    for lab, short, _ in res['attires']:
        log("")
        block("Attire %s:" % short, res['parts'][lab])
    log("")
    log("textures: C = colour map found, N = normal map found.   Port only some parts:  --only NAME[,NAME]  /  skip some:  "
        "--exclude NAME[,NAME]   (NAME = 'Mesh/material', only the mesh, or only the material; * and ? work).  'off' = a duplicate "
        "variant (entrance / withBelt) that is left out unless --variants (or --only naming it)")


# --------------------------------------------------------------------------------------------------
# regions / importance (which parts of the body deserve triangles)
# --------------------------------------------------------------------------------------------------
FACE_KEYS = ('head', 'eye', 'mayu', 'mabuta', 'meziri', 'hoho', 'hana', 'kuchi', 'miken')


def bone_region(name):
    """Wii bone name -> body region: head | neck | torso | arm | hand | leg | foot"""
    n = pose._norm(name)
    if 'finger' in n or n.endswith('hand'):
        return 'hand'
    if 'thigh' in n or 'calf' in n:
        return 'leg'
    if 'foot' in n or 'toe' in n:
        return 'foot'
    if 'upperarm' in n or 'forearm' in n or 'wrist' in n or 'elbow' in n:
        return 'arm'
    if 'neck' in n:
        return 'neck'
    if any(k in n for k in FACE_KEYS):
        return 'head'
    return 'torso'


def vertex_regions(W):
    """dominant region of every vertex (weights are {bone name: w})"""
    out = []
    for w in W:
        acc = collections.defaultdict(float)
        for b, x in w.items():
            acc[bone_region(b)] += x
        out.append(max(acc, key=acc.get) if acc else 'torso')
    return out


def importance_table(face_bias, body_bias):
    t = dict(head=face_bias, neck=0.5 * (face_bias + body_bias), torso=body_bias, arm=0.75 * body_bias,
             hand=0.9 * body_bias, leg=0.6 * body_bias, foot=0.45 * body_bias)
    return dict((k, max(0.8, v)) for k, v in t.items())


COVERED_FACTOR = 0.35          # skin that lies under clothing but was not culled: collapsed first


def vertex_importance(W, cov, table):
    reg = vertex_regions(W)
    imp = np.array([table[r] for r in reg], float)
    if cov is not None:
        imp = np.where(np.asarray(cov) > 0.5, imp * COVERED_FACTOR, imp)
    return imp


# --------------------------------------------------------------------------------------------------
# hidden skin culling  (conservative)
# --------------------------------------------------------------------------------------------------
def _vertex_neighbors_flag(T, flag, n):
    """bool per vertex: True when at least one neighbour (shared triangle edge) has flag == False"""
    bad = np.zeros(n, bool)
    for a, b in ((0, 1), (1, 2), (2, 0)):
        bad[T[:, a]] |= ~flag[T[:, b]]
        bad[T[:, b]] |= ~flag[T[:, a]]
    return bad


POKE_DEPTH = 2.0                     # cm: a cloth surface this far BEHIND (inside) a skin vertex means the skin sticks out through the cloth
POKE_DIST = 1.2                      # cm: sideways reach of that test
POKE_NEAR = 0.35                     # cm: skin this close UNDER a cloth surface counts as near it (z-fighting, pokes through when the cloth moves)
POKE_GAP = 0.30                      # cm: where --poke-fix scale puts such skin: this far under the cloth surface


def cull_hidden_skin(parts, dist, log, depth=8.0, rings=2, min_dot=0.3, remove=True, poke=False):
    """Remove body skin that is really covered by clothing - and nothing else.

    poke=True (--hide-under-cloth): ALSO remove the skin triangles that stick out THROUGH the clothing - a skin vertex with an
    opaque cloth surface just behind it (0.1 .. POKE_DEPTH cm inside, within POKE_DIST cm sideways, facing the same way) is skin
    showing on top of the cloth.  Those triangles go even where the margin of covered skin would keep them (the cloth right
    behind them fills the gap), so no skin shows over the clothes.

    A skin vertex counts as covered when a sample of an OPAQUE clothing surface lies just outside it (0..`depth` cm
    along the skin normal, within `dist` cm sideways) AND that clothing surface faces the same way as the skin
    (so a sleeve next to the torso, or the inside of a collar, never hides anything).  Then
      * head, neck and hand skin is never culled,
      * the covered area is eroded by `rings` triangle rings, so a margin of skin stays under every hem / sleeve /
        collar edge (no holes when the cloth moves),
      * only triangles whose three corners are still covered are removed.
    Covered skin that is kept gets the `cov` flag: the decimator thins it out first."""
    skin = [p for p in parts if p.role == 'skin' and p.tex == 'body']
    cloth = [p for p in parts if p.role == 'cloth' and not getattr(p, 'alpha', False)]
    for s in skin:
        s.cov = np.zeros(len(s.P))
        s.under = np.zeros(len(s.P), bool)               # vertices that lie under clothing (for --hide-under-cloth)
    if not skin or not cloth or dist <= 0:
        log("  skin culling: off (nothing is removed)")
        return
    pts, nrm = [], []
    for c in cloth:
        pts.append(c.P)
        nrm.append(c.N)
        pts.append(c.P[c.T].mean(1))
        cn = c.N[c.T].mean(1)
        nrm.append(cn / np.maximum(np.linalg.norm(cn, axis=1, keepdims=True), 1e-9))
    pts = np.concatenate(pts)
    nrm = np.concatenate(nrm)
    tree = cKDTree(pts)
    for s in skin:
        n = len(s.P)
        reg = vertex_regions(s.W)
        protect = np.array([r in ('head', 'neck', 'hand') for r in reg])
        hidden = np.zeros(n, bool)
        r = depth / 2.0 + dist
        used = np.zeros(n, bool)
        used[np.unique(s.T)] = True
        for i in np.nonzero(used & ~protect)[0]:
            nv = s.N[i]
            c = s.P[i] + nv * depth / 2.0
            ix = tree.query_ball_point(c, r)
            if not ix:
                continue
            q = pts[ix] - s.P[i]
            t = q @ nv
            perp = np.linalg.norm(q - np.outer(t, nv), axis=1)
            if np.any((t > -0.1) & (t < depth) & (perp < dist) & ((nrm[ix] @ nv) > min_dot)):
                hidden[i] = True
        pokev = np.zeros(n, bool)
        if poke:
            rp = float(np.hypot(POKE_DEPTH, max(POKE_DIST, dist)))
            for i in np.nonzero(used & ~protect & ~hidden)[0]:
                ix = tree.query_ball_point(s.P[i], rp)
                if not ix:
                    continue
                nv = s.N[i]
                q = pts[ix] - s.P[i]
                t = q @ nv
                perp = np.linalg.norm(q - np.outer(t, nv), axis=1)
                if np.any((t >= -POKE_DEPTH) & (t < -0.1) & (perp < max(POKE_DIST, dist)) & ((nrm[ix] @ nv) > min_dot)):
                    pokev[i] = True
        s.under = hidden | pokev
        if not remove and not pokev.any():               # only looking (--cull 0 with --hide-under-cloth): nothing is removed
            log("  skin under clothes: %d covered vertices found in %s (nothing culled)" % (int(hidden.sum()), s.name))
            continue
        s.cov = (hidden | pokev).astype(float)
        core = hidden.copy() if remove else np.zeros(n, bool)
        for _ in range(max(0, rings)):
            core &= ~_vertex_neighbors_flag(s.T, core, n)
        gone = core | pokev
        keep = ~(gone[s.T].all(1) & (core[s.T].all(1) | pokev[s.T].any(1)))
        n0 = len(s.T)
        if poke:
            npk = int((~keep & ~core[s.T].all(1)).sum())
            log("  skin poking through the clothes: %d vertices of %s, %d triangles removed on top of the covered skin" % (int(pokev.sum()), s.name, npk))
        by = collections.Counter(vertex_regions([s.W[v] for v in np.unique(s.T[~keep])]))
        s.T = s.T[keep]
        log("  hidden skin culled from %s: %d -> %d triangles (%.0f %% kept; %d covered vertices, %d-ring margin kept)%s" % (
            s.name, n0, len(s.T), 100.0 * len(s.T) / max(n0, 1), int(hidden.sum()), rings,
            ("; removed by region: " + ", ".join("%s %d" % kv for kv in sorted(by.items()))) if by else ""))
        if len(s.T) < 0.30 * n0:
            log("  WARNING: more than 70 %% of %s was culled - lower --cull / --cull-depth or use --cull 0" % s.name)


def _limit_flips(Pt, T, moves, min_cos=0.2, rounds=6):
    """the skin vertices of `moves` ({vertex: displacement}) are moved inward; no triangle may be turned inside out (or nearly so) by it:
    the displacement of a vertex that would do that is halved until it does not, and dropped if even that is not enough."""
    if not moves:
        return moves
    verts = np.array(sorted(moves), int)
    sel = np.nonzero(np.isin(T, verts).any(1))[0]
    if not len(sel):
        return moves
    Ts = T[sel]

    def nrm(P_):
        n_ = np.cross(P_[Ts[:, 1]] - P_[Ts[:, 0]], P_[Ts[:, 2]] - P_[Ts[:, 0]])
        l_ = np.linalg.norm(n_, axis=1)
        return n_ / np.maximum(l_, 1e-12)[:, None], l_ > 1e-12

    n0, ok0 = nrm(Pt)
    scale = dict((int(v), 1.0) for v in verts)
    for _ in range(rounds):
        Pn = Pt.copy()
        for v, dl in moves.items():
            Pn[v] = Pt[v] + dl * scale[int(v)]
        n1, ok1 = nrm(Pn)
        bad = ok0 & ((n0 * n1).sum(1) < min_cos)
        if not bad.any():
            break
        for v in np.unique(Ts[bad]):
            if int(v) in scale:
                scale[int(v)] *= 0.5
    else:
        Pn = Pt.copy()
        for v, dl in moves.items():
            Pn[v] = Pt[v] + dl * scale[int(v)]
        n1, ok1 = nrm(Pn)
        bad = ok0 & ((n0 * n1).sum(1) < min_cos)
        for v in np.unique(Ts[bad]):
            if int(v) in scale:
                scale[int(v)] = 0.0
    return dict((v, dl * scale[int(v)]) for v, dl in moves.items() if scale[int(v)] >= 0.1)


def poke_through_fix(P, N, tris, cuvs, rects, cover_keys, vreg, k, mode='scale', skin_key='body', depth_cm=POKE_DEPTH, tol=0.03,
                     protect=('head', 'neck')):
    """--hide-under-cloth, after the decimation: skin of the REDUCED mesh that is near or crossing the cloth above it.
    For every skin vertex (atlas patch `skin_key`, not head / neck) the cloth triangles (patches in `cover_keys`, oriented outwards by
    their vertex normals) that lie directly beneath / above it (the vertex projects inside them) are measured: d = how far the vertex is
    OUTSIDE that cloth surface (d > 0: the skin is on top of the cloth, d < 0: under it).  When the outermost of those surfaces is
    not comfortably above the skin (d >= -POKE_NEAR cm, up to POKE_DEPTH cm outside) the vertex is near or crossing the cloth:
      mode 'scale':  it is moved inward along the cloth normal to POKE_GAP cm under the cloth surface (the skin is scaled down there);
                     vertices that cloth triangles or the head share are left alone, so no cloth is dragged along;
      mode 'remove': skin triangles with two or three corners ON the cloth (d >= 0) are removed.
    Returns (keep mask over the triangles, {vertex: displacement}, number of near / crossing vertices), or None."""
    T = np.asarray(tris, int)
    if not len(T) or not cover_keys:
        return None
    C = np.asarray(cuvs, float).reshape(len(T), 3, 2)
    cx, cy = C[:, :, 0].mean(1), C[:, :, 1].mean(1)
    key = np.full(len(T), '', dtype=object)
    for name, (x, y, w, h) in rects.items():
        key[(cx >= x - 1) & (cx <= x + w + 1) & (cy >= y - 1) & (cy <= y + h + 1)] = name
    skin_i = np.nonzero(key == skin_key)[0]
    cloth_i = np.nonzero(np.isin(key, list(cover_keys)))[0]
    if not len(skin_i) or not len(cloth_i):
        return None
    Pt = np.asarray(P, float)
    A, B, Cc = Pt[T[cloth_i, 0]], Pt[T[cloth_i, 1]], Pt[T[cloth_i, 2]]
    g = np.cross(B - A, Cc - A)
    ar = np.linalg.norm(g, axis=1)
    good = ar > 1e-9
    A, B, Cc, g, ar, cl = A[good], B[good], Cc[good], g[good], ar[good], cloth_i[good]
    if not len(A):
        return None
    n = g / ar[:, None]
    sg = np.sign((n * np.asarray(N, float)[T[cl]].mean(1)).sum(1))
    sg[sg == 0] = 1.0
    n = n * sg[:, None]
    v0, v1 = B - A, Cc - A
    d00, d01, d11 = (v0 * v0).sum(1), (v0 * v1).sum(1), (v1 * v1).sum(1)
    den = d00 * d11 - d01 * d01
    den = np.where(np.abs(den) < 1e-12, 1e-12, den)
    cen = (A + B + Cc) / 3.0
    rad = np.max(np.linalg.norm(np.stack([A, B, Cc], 1) - cen[:, None, :], axis=2), axis=1)
    tree = cKDTree(cen)
    reach = float(rad.max())
    depth, near, gap, low = depth_cm * k, POKE_NEAR * k, POKE_GAP * k, -0.02 * k
    other = np.ones(len(T), bool)
    other[skin_i] = False
    shared = set(np.unique(T[other]).tolist())                 # vertices that cloth / head / hair triangles use as well
    poke = np.zeros(len(Pt), bool)
    onto = np.zeros(len(Pt), bool)
    moves = {}
    for v in np.unique(T[skin_i]):
        if vreg[v] in protect:
            continue
        s_ = Pt[v]
        ix = np.asarray(tree.query_ball_point(s_, reach + depth), int)
        if not len(ix):
            continue
        d = ((s_ - A[ix]) * n[ix]).sum(1)
        m = (d >= -depth) & (d <= depth)
        if not m.any():
            continue
        ix, d = ix[m], d[m]
        proj = s_ - d[:, None] * n[ix]
        v2 = proj - A[ix]
        d20, d21 = (v2 * v0[ix]).sum(1), (v2 * v1[ix]).sum(1)
        bv = (d11[ix] * d20 - d01[ix] * d21) / den[ix]
        bw = (d00[ix] * d21 - d01[ix] * d20) / den[ix]
        ins = (bv >= -tol) & (bw >= -tol) & (1.0 - bv - bw >= -tol)
        if not ins.any():
            continue
        ix, d = ix[ins], d[ins]
        j = int(np.argmin(d))                                   # the outermost cloth surface above / below the vertex
        if d[j] < -near:                                        # comfortably under the cloth: covered
            continue
        poke[v] = True
        onto[v] = d[j] >= low
        if mode == 'scale' and v not in shared:
            moves[int(v)] = -(d[j] + gap) * n[ix[j]]
    moves = _limit_flips(Pt, T, moves)
    keep = np.ones(len(T), bool)
    if mode == 'remove':
        keep[skin_i] = onto[T[skin_i]].sum(1) < 2
    return keep, moves, int(poke.sum())


# --------------------------------------------------------------------------------------------------
# donor profile: which submeshes get the new body, which are kept, where the head is
# --------------------------------------------------------------------------------------------------
class Profile(object):
    pass


def make_profile(donor, dW_names, log):
    """Work out the layout of ANY donor DUMY.
    * 6+ submeshes (ch102 layout): 0 head/torso/arms, 1 legs, 2 boots are replaced; 3 mouth and 4 eyes are kept, the last
      one is the blood layer (rebuilt on the new face).
    * fewer submeshes (e.g. the 3-submesh ch342: torso / head+arms+legs / mask+boots, no eye, mouth or blood
      submesh): ALL submeshes receive the new body, every new triangle goes to the donor submesh that is nearest to it
      (so the donor's draw layout and vertex-colour shading are kept), the 2K eyes are added to the head submesh."""
    nb = len(donor.blocks)
    real = donor.real_vcount
    pr = Profile()
    pr.nblocks = nb
    pr.tris = [len(list(donor.triangles(b))) for b in range(nb)]
    pr.bverts = dict((b, len({c[0] for t in donor.triangles(b) for c in t if c[0] < real})) for b in range(nb))
    pr.mouth = pr.eye = pr.blood = None
    if nb >= 6:
        pr.mode = 'legacy'
        pr.new_blocks = [0, 1, 2]
        pr.mouth, pr.eye, pr.blood = 3, 4, nb - 1
        pr.keep_rows = KEEP_TOP_ROWS
        pr.head_block = 0
    else:
        pr.mode = 'spatial'
        pr.keep_rows = 0
        # eye / mouth submeshes (if any) are recognised by their bones and kept as they are
        vreg = None
        for b in range(nb):
            vs = [v for v in donor.block_vertices(b)]
            if not vs:
                continue
            names = collections.Counter()
            for v in vs:
                w = dW_names[v]
                if w:
                    names[max(w, key=w.get)] += 1
            top = sum(c for n, c in names.items() if pose._norm(n) in ('leye', 'reye')) / float(len(vs))
            mth = sum(c for n, c in names.items() if 'kuchi' in pose._norm(n)) / float(len(vs))
            if top > 0.8 and pr.eye is None:
                pr.eye = b
            elif mth > 0.8 and pr.mouth is None:
                pr.mouth = b
        pr.new_blocks = [b for b in range(nb) if b not in (pr.eye, pr.mouth)]
        # head submesh = the one with most head-region triangles
        reg = vertex_regions(dW_names[:real])
        cnt = collections.Counter()
        for b in pr.new_blocks:
            for t in donor.triangles(b):
                ids = [c[0] for c in t]
                if max(ids) < real and sum(1 for i in ids if reg[i] == 'head') >= 2:
                    cnt[b] += 1
        pr.head_block = cnt.most_common(1)[0][0] if cnt else pr.new_blocks[0]
    return pr


def spatial_blocks(part, ctree, dbk, nblocks, rounds=2):
    """donor submesh of every triangle of `part`: that of the nearest donor triangle, smoothed over the triangle
    neighbourhood so the submesh borders stay clean (short strips)."""
    cen = part.P[part.T].mean(1)
    _, ix = ctree.query(cen)
    return smooth_blocks(part.T, dbk[ix], nblocks, rounds)


def smooth_blocks(T, bk, nblocks, rounds=2):
    """Majority vote of the submesh label over the edge neighbours of every triangle, so submesh borders stay clean
    (short borders = long strips).  T: (m,3) vertex ids, bk: (m,) labels."""
    T = np.asarray(T)
    bk = np.asarray(bk)
    m = len(T)
    if m < 2 or nblocks < 2:
        return bk
    from scipy.sparse import coo_matrix
    e = np.concatenate([T[:, [0, 1]], T[:, [1, 2]], T[:, [2, 0]]])
    tri_id = np.tile(np.arange(m), 3)
    e = np.sort(e, axis=1)
    key = e[:, 0].astype(np.int64) * (int(T.max()) + 1) + e[:, 1]
    order = np.argsort(key, kind='stable')
    ks, ts = key[order], tri_id[order]
    same = ks[1:] == ks[:-1]
    a, b = ts[:-1][same], ts[1:][same]
    adj = coo_matrix((np.ones(len(a) * 2), (np.concatenate([a, b]), np.concatenate([b, a]))), shape=(m, m)).tocsr()
    for _ in range(rounds):
        votes = np.zeros((m, nblocks))
        for k in range(nblocks):
            ind = (bk == k).astype(float)
            votes[:, k] = adj @ ind + 1.5 * ind
        bk = votes.argmax(1)
    return bk


def _waterfill(total, share, cap):
    """distribute `total` over the keys of `share` (weights) without exceeding cap[key]; the surplus of a capped key
    goes to the others."""
    out, free, rem = {}, list(share), float(total)
    while free:
        s = sum(share[k] for k in free) or 1e-12
        over = [k for k in free if rem * share[k] / s >= cap[k]]
        if not over:
            break
        for k in over:
            out[k] = cap[k]
            rem -= cap[k]
            free.remove(k)
    if free:
        s = sum(share[k] for k in free) or 1e-12
        for k in free:
            out[k] = rem * share[k] / s
    return out


def split_budget(content, donor_tris, avail_t, avail_v, T_total, V_total, ratio):
    """Triangle / vertex budget per submesh.  Share = half the donor's own distribution + half the importance-weighted
    content (face and torso area count more), clamped to 0.5x..1.7x of the donor's share of that submesh.  A submesh
    never gets more than it has (the surplus goes to the others), so the full budget is always used."""
    blocks = sorted(content)
    dt = np.array([max(donor_tris[b], 1) for b in blocks], float)
    ct = np.array([content[b] for b in blocks], float)
    ds = dt / dt.sum()
    cs = ct / max(ct.sum(), 1e-12)
    share = 0.5 * ds + 0.5 * cs
    for _ in range(6):
        share = np.clip(share, 0.5 * ds, 1.7 * ds)
        share = share / share.sum()
    tb = _waterfill(T_total, dict(zip(blocks, share)), dict((b, avail_t[b]) for b in blocks))
    vraw = dict((b, tb[b] * ratio[b]) for b in blocks)
    vs = sum(vraw.values()) or 1e-9
    vb = _waterfill(V_total, dict((b, vraw[b] / vs) for b in blocks), dict((b, avail_v[b]) for b in blocks))
    return dict((b, int(tb[b])) for b in blocks), dict((b, int(vb[b])) for b in blocks)


# --------------------------------------------------------------------------------------------------
# atlas (512 for the PAC, optional 4K export from the same layout)
# --------------------------------------------------------------------------------------------------
def load_tex_images(tex_files, log):
    from PIL import Image
    out = {}
    for key, f in tex_files.items():
        if not f:
            continue
        try:
            im = Image.open(f).convert('RGB')
            out[key] = im
        except Exception as e:            # noqa
            log("  WARNING: cannot read texture %s: %s" % (f, e))
    return out


def strand_bg(a):
    """background colour (floats 0..1) of a strand map (H, W, 3 floats 0..1) = its most common colour.  Triple H's maps sit on
    (51, 0, 51), the newer ones (Brock Lesnar) on (127, 0, 127)."""
    q = np.round(a[::4, ::4].reshape(-1, 3) * 255.0).astype(np.int32)
    key = (q[:, 0] << 16) | (q[:, 1] << 8) | q[:, 2]
    u, c = np.unique(key, return_counts=True)
    k = int(u[int(np.argmax(c))])
    return np.array([(k >> 16) & 255, (k >> 8) & 255, k & 255], np.float32) / 255.0


def strand_body(a, bg):
    """0 = background .. 1 = strand body, from the distance to the background colour"""
    return np.clip(np.sqrt(((a - bg) ** 2).sum(-1)) / 0.35, 0.0, 1.0)


def strand_alpha(img, gap=0.0):
    """Alpha (float32 0..1, the size of the map) of a strand map: the strand bodies are opaque (1), the background between them
    is `gap` (0 = see-through)."""
    a = np.asarray(img.convert('RGB'), np.float32) / 255.0
    body = strand_body(a, strand_bg(a))
    return np.clip(gap + (1.0 - gap) * body, 0.0, 1.0).astype(np.float32)


def alpha_resize(colour, alpha, size, cut=None):
    """colour: PIL RGB, alpha: float32 (h, w) of the same size -> RGBA uint8 (size = (w, h)).  The colour is averaged weighted by the
    alpha, so the undercoat of the gaps does not bleed into the strands.  cut=None: soft alpha 0..255 (the images for people);
    a number: texels whose coverage is >= cut are opaque, the others transparent (1-bit alpha, what the Wii's CMPR has)."""
    from PIL import Image
    w, h = size
    c = np.asarray(colour.convert('RGB'), np.float32)
    down = w < c.shape[1] and h < c.shape[0]
    flt = Image.BOX if down else Image.BILINEAR

    def rs(x):
        return np.asarray(Image.fromarray(np.ascontiguousarray(x, np.float32), mode='F').resize((w, h), flt), np.float32)
    al = rs(alpha)
    out = np.zeros((h, w, 4), np.uint8)
    safe = np.maximum(al, 1e-4)
    for k in range(3):
        ch = rs(c[..., k] * alpha) / safe
        out[..., k] = np.clip(np.where(al > 1e-4, ch, c[..., k].mean()), 0, 255).astype(np.uint8)
    out[..., 3] = np.where(al >= cut, 255, 0) if cut is not None else np.rint(np.clip(al, 0, 1) * 255.0)
    return out


def export_strand_textures(strand_mcd, src, hair_rgb, ramp, size, convert, stem, log):
    """The strand maps of the beard ('combinations') and the head hair ('hair') as colour textures WITH alpha (see-through gaps),
    size x size, one PNG each.  They are the full-resolution versions of what the PAC's hair texture is made from."""
    from PIL import Image
    label = {'combinations': 'beard', 'hair': 'hair'}
    for nm, mcd in sorted(strand_mcd.items()):
        f = src.raw_texture(mcd, nm + '_rai.dds')
        if not f:
            continue
        im = Image.open(f).convert('RGB')
        if max(im.size) > 2048:
            k = 2048.0 / max(im.size)
            im = im.resize((max(1, int(im.size[0] * k)), max(1, int(im.size[1] * k))), Image.LANCZOS)
        col = strand_map_to_colour(im, hair_rgb, ramp) if convert else im
        rgba = alpha_resize(col, strand_alpha(im), (size, size), cut=None)
        name = '%s_%s_strands_%s.png' % (stem, label.get(nm, nm), '4k' if size == 4096 else str(size))
        Image.fromarray(rgba, 'RGBA').save(name)
        log("Wrote %s (%dx%d RGBA, strands opaque, gaps see-through)" % (name, size, size))
        del rgba, col


def stack_strand_maps(imgs, side=(1024, 512)):
    """several strand maps (PIL RGB) -> one image, stacked top to bottom (map k is rows k/n .. (k+1)/n); one map is returned as it is.
    Each map is first reduced to `side` (w, h) when it is larger (the result is a 512 texture anyway)."""
    from PIL import Image
    if len(imgs) == 1:
        return imgs[0].convert('RGB')
    w, h = side
    out = Image.new('RGB', (w, h * len(imgs)))
    for k, im in enumerate(imgs):
        out.paste(im.convert('RGB').resize((w, h), Image.LANCZOS), (0, k * h))
    return out


def load_strand_sheet(src, hparts, log=None):
    """The strand map ('<strand>_rai.dds' next to the mcd) of every hair part: 'combinations' (beard) and 'hair' (head hair) each have
    their own map.  Sets p.layer = (k, n) on the parts (their UVs get squeezed into map k of n of the stacked texture; a part whose
    own map is missing uses the first one found).  Returns ([PIL RGB per map], [names]) - empty lists when there is none."""
    from PIL import Image
    found = collections.OrderedDict()
    for p in sorted(hparts, key=lambda q: getattr(q, 'strand', None) or ''):
        nm = getattr(p, 'strand', None) or 'combinations'
        if nm not in found:
            found[nm] = src.raw_texture(p.mcd, nm + '_rai.dds')
    have = [k for k, f in found.items() if f]
    if not have:
        return [], []
    for p in hparts:
        nm = getattr(p, 'strand', None) or 'combinations'
        p.layer = (have.index(nm if found.get(nm) else have[0]), len(have))
    if log and len(have) > 1:
        log("Hair strand maps: %s share one texture (stacked top to bottom)" % " + ".join(k + '_rai.dds' for k in have))
    return [Image.open(found[k]).convert('RGB') for k in have], have


def strand_map_to_colour(img, hair_rgb, ramp=None):
    """The 2K 'combinations_rai' map is a shader DATA map: flat purple background, wide magenta / red strand bodies (R and B
    carry a per-strand id) and thin green cores (G).  This turns it into an ordinary colour texture:
    * hair_rgb (a flat colour): undercoat in the background, strands a little brighter and shaded per strand, bright cores as
      highlights;
    * ramp (the 2K hair material's own colours, see read_hair_material): every strand sits between the material's ROOT colour and
      its TIP colour - `tip_mix` is how far towards the tip colour the average strand goes, the material's `variation` spreads
      the strands around that (per-strand random value = the R channel), the thin cores are pulled towards the tip colour, the
      background is the root colour with a slight lift.
    img: PIL RGB image; returns a PIL RGB image of the same size."""
    from PIL import Image
    a = np.asarray(img.convert('RGB'), np.float32) / 255.0
    R, G, B = a[..., 0], a[..., 1], a[..., 2]
    bg = strand_bg(a)
    body = strand_body(a, bg)                                                    # 0 background .. 1 strand
    core = np.clip(G * 1.25, 0.0, 1.0)                                           # thin bright centre line
    if ramp is not None:
        root = np.asarray(ramp['root'], np.float32)
        tip = np.asarray(ramp['tip'], np.float32)
        mix = float(ramp.get('tip_mix', 0.25))
        var = float(ramp.get('variation', 0.35))
        fl = float(bg[0]) if bg[0] < 0.3 else 0.0                                # older maps: background R = 0.2, strands above it
        rnd = np.clip((R - fl) / (1.0 - fl), 0.0, 1.0)                           # per-strand random value
        t = np.clip(mix + var * (rnd - 0.5) * 2.0 + 0.4 * core, 0.0, 1.0)
        t = body * t + (1.0 - body) * (0.25 * mix)                               # undercoat: root colour, slightly lifted
        col = (root[None, None, :] + (tip - root)[None, None, :] * t[..., None]) * float(ramp.get('albedo', 1.0))
        return Image.fromarray(np.clip(col * 255.0, 0, 255).astype(np.uint8))
    shade = np.clip(R - B, -1.0, 1.0)                                            # per-strand variation
    lum = 0.55 + 0.45 * body + 0.55 * core * body + 0.18 * shade * body
    col = np.asarray(hair_rgb, np.float32)[None, None, :] * lum[..., None]
    col = col + (core * body)[..., None] * np.array([14.0, 11.0, 7.0], np.float32)   # slightly warm highlights
    return Image.fromarray(np.clip(col, 0, 255).astype(np.uint8))


def read_hair_material(mcd_path):
    """Parameters (name -> float) of the 2K hair material ('yCh_hair' / NewHair_ColorChanging...) from the .mtls next to the
    attire mcd, or None.  The colours stored there are the material's own defaults (g_rootColorR/G/B, g_tipColorR/G/B,
    g_hairAlbedo, g_variation ...); the dye system of the game may override them at run time."""
    try:
        d = os.path.dirname(mcd_path)
        for f in sorted(os.listdir(d)):
            if not f.lower().endswith('.mtls'):
                continue
            data = open(os.path.join(d, f), 'rb').read()
            pos = 0
            while True:
                i = data.find(b'MTL!', pos)
                if i < 0:
                    break
                j = data.find(b'MTL!', i + 4)
                blk = data[i:j if j > 0 else len(data)]
                pos = i + 4
                names, k = [], 12
                while k < len(blk):
                    e = blk.find(b'\x00', k)
                    s = blk[k:e] if e >= 0 else b''
                    if e < 0 or not s or not all(32 <= c < 127 for c in s):
                        break
                    names.append(s.decode())
                    k = e + 1
                if len(names) < 4 or 'hair' not in (names[0] + names[1]).lower():
                    continue
                f0 = blk.find(b'\xff' * 8, k)
                if f0 < 0:
                    continue
                f0 += 8
                while f0 < len(blk) and blk[f0] == 0xff:
                    f0 += 1
                f0 += 8                                               # 8-byte hash, then one float per parameter
                params = names[2:]
                nf = min(len(params), (len(blk) - f0) // 4)
                vals = struct.unpack_from('<%df' % nf, blk, f0)
                out = dict((n, float(v)) for n, v in zip(params, vals))
                if all(('g_rootColor' + c) in out and ('g_tipColor' + c) in out for c in 'RGB') and all(
                        -0.01 <= out[x + c] <= 8.0 for x in ('g_rootColor', 'g_tipColor') for c in 'RGB'):
                    return out
    except Exception:                                                  # noqa
        return None
    return None


def _coloured(m):
    """does the 2K hair material carry a real colour?  (the files of many characters only hold the dye system's neutral defaults:
    a black root and a white tip)"""
    cols = [tuple(m['g_%sColor%s' % (k, c)] for c in 'RGB') for k in ('root', 'tip')]
    return any(max(abs(c[0] - c[1]), abs(c[1] - c[2]), abs(c[0] - c[2])) > 0.06 for c in cols)


def sample_head_hair_colour(src, mcd_path, log=None):
    """The colour the 2K artists painted into the head texture where the beard grows (BaseModel/CAS/headhair_mask.dds marks
    that area in head_color.dds): ROOT = the dark end of the painted hair, TIP = its lighter end.  None when the character has
    no such mask / texture.  Colours are 0..1."""
    try:
        from PIL import Image
        hf = src.texture(mcd_path, 'head')
        mf = src.raw_texture(mcd_path, 'headhair_mask.dds')
        if not hf or not mf:
            return None
        m = Image.open(mf).convert('L')
        h = Image.open(hf).convert('RGB').resize(m.size, Image.BILINEAR)
        mk = np.asarray(m, np.float32) > 127
        if int(mk.sum()) < 500:
            return None
        px = np.asarray(h, np.float32)[mk] / 255.0
        lum = px @ np.array([0.299, 0.587, 0.114], np.float32)
        order = np.argsort(lum)
        n = len(order)
        root = px[order[:max(1, int(0.15 * n))]].mean(0)
        tip = px[order[int(0.55 * n):max(int(0.55 * n) + 1, int(0.85 * n))]].mean(0)
        tip = np.maximum(tip, np.minimum(1.0, root * 1.35))
        return dict(root=tuple(float(x) for x in root), tip=tuple(float(x) for x in tip))
    except Exception:                                                   # noqa
        return None


def resolve_hair_colour(args, mcd_path, log, src=None):
    """--hair-color: 'auto' (default), 'material', 'head' or '#RRGGBB'.
    auto: the 2K hair material's own root / tip colours when they hold a real colour, else the colour painted into the head
    texture's beard area (the black / white of an untinted material is not a hair colour), else a dark brown.
    material: always the material's colours.  head: always the head texture's beard colour.  #RRGGBB: one flat colour.
    Returns (flat rgb tuple 0..255 for the places that need one colour, ramp dict or None)."""
    hc = str(args.hair_color).strip().lower()
    if hc in ('auto', 'default', '', 'material', '2k', 'head', 'beard'):
        mix = min(1.0, max(0.0, float(getattr(args, 'beard_tip_mix', 0.5))))
        m = None if hc in ('head', 'beard') else read_hair_material(mcd_path)
        if m is not None and (hc in ('material', '2k') or _coloured(m)):
            root = tuple(m['g_rootColor' + c] for c in 'RGB')
            tip = tuple(m['g_tipColor' + c] for c in 'RGB')
            ramp = dict(root=root, tip=tip, tip_mix=mix, variation=m.get('g_variation', 0.35), albedo=m.get('g_hairAlbedo', 1.0))
            flat = tuple(int(round(255.0 * min(1.0, max(0.0, (r + (t - r) * mix) * ramp['albedo'])))) for r, t in zip(root, tip))
            log("Hair colour: the 2K hair material's own colours - root (%.2f, %.2f, %.2f), tip (%.2f, %.2f, %.2f), albedo %.2f, strand "
                "variation %.2f; average strand %.0f %% of the way to the tip colour (--beard-tip-mix)" % (
                    root + tip + (ramp['albedo'], ramp['variation'], 100 * mix)))
            return flat, ramp
        h = sample_head_hair_colour(src, mcd_path) if src is not None else None
        if h is not None:
            root, tip = h['root'], h['tip']
            ramp = dict(root=root, tip=tip, tip_mix=mix, variation=0.4, albedo=1.0)
            flat = tuple(int(round(255.0 * min(1.0, max(0.0, r + (t - r) * mix)))) for r, t in zip(root, tip))
            why = "the 2K hair material only holds the neutral black / white defaults" if m is not None else "requested"
            log("Hair colour: taken from the colour painted into the head texture's beard area (%s) - root #%02x%02x%02x -> tip "
                "#%02x%02x%02x, average strand %.0f %% of the way to the tip (--beard-tip-mix); '--hair-color #RRGGBB' sets your own" % (
                    why, int(root[0] * 255), int(root[1] * 255), int(root[2] * 255),
                    int(tip[0] * 255), int(tip[1] * 255), int(tip[2] * 255), 100 * mix))
            return flat, ramp
        log("Hair colour: no coloured hair material and no beard area in the head texture -> #2a211c (set --hair-color #RRGGBB)")
        hc = '#2a211c'
    return tuple(int(hc.lstrip('#')[i:i + 2], 16) for i in (0, 2, 4)), None


# --------------------------------------------------------------------------------------------------
# object-space normal atlas
# --------------------------------------------------------------------------------------------------
def _decode_normal_map(img):
    """PIL image -> float array (h, w, 2) of the tangent-space x / y (-1..1) and (h, w) z.  2K normal maps keep the
    normal in R / G (B holds other data): z is rebuilt; an ordinary RGB normal map (blue ~ 1) uses its blue channel."""
    a = np.asarray(img.convert('RGB'), np.float32) / 255.0
    x, y = a[..., 0] * 2 - 1, a[..., 1] * 2 - 1
    if float(a[..., 2].mean()) > 0.85:
        z = a[..., 2] * 2 - 1
    else:
        z = np.sqrt(np.clip(1.0 - x * x - y * y, 0.0, 1.0))
    return x, y, z


def _green_vote(x, y):
    """+: the map looks like the gradient of a height field with green = UP (OpenGL), -: green = DOWN (DirectX).  For a
    height field h, n_x = -dh/dx and n_y(up) = dh/drow, so  d n_x / d row  =  - d n_y / d x  for green up (and + for down);
    the sign of the mean product tells which one it is.  Returns (sum of the product, count)."""
    x, y = x[::2, ::2], y[::2, ::2]
    if x.shape[0] < 4 or x.shape[1] < 4:
        return 0.0, 0
    dxr = np.gradient(x, axis=0)
    dyx = np.gradient(y, axis=1)
    return float((dxr * dyx).sum()), int(dxr.size)


def _tangent_frames(P, N, UV, T):
    """per-vertex tangent (dP/du) and bitangent (dP/dv, v running down the image), orthonormal to the vertex normal"""
    p0, p1, p2 = P[T[:, 0]], P[T[:, 1]], P[T[:, 2]]
    u0, u1, u2 = UV[T[:, 0]], UV[T[:, 1]], UV[T[:, 2]]
    e1, e2 = p1 - p0, p2 - p0
    d1, d2 = u1 - u0, u2 - u0
    # a UV that crosses a texture repeat must not give huge derivatives: use the wrapped differences
    d1 -= np.round(d1)
    d2 -= np.round(d2)
    det = d1[:, 0] * d2[:, 1] - d2[:, 0] * d1[:, 1]
    ok = np.abs(det) > 1e-14
    r = np.where(ok, 1.0 / np.where(ok, det, 1.0), 0.0)
    tan = (e1 * d2[:, 1:2] - e2 * d1[:, 1:2]) * r[:, None]
    bit = (e2 * d1[:, 0:1] - e1 * d2[:, 0:1]) * r[:, None]
    area = np.linalg.norm(np.cross(e1, e2), axis=1)
    tv = np.zeros((len(P), 3))
    bv = np.zeros((len(P), 3))
    for k in range(3):
        wgt = area[:, None]
        tn = tan / np.maximum(np.linalg.norm(tan, axis=1, keepdims=True), 1e-18)
        bn = bit / np.maximum(np.linalg.norm(bit, axis=1, keepdims=True), 1e-18)
        np.add.at(tv, T[:, k], tn * wgt)
        np.add.at(bv, T[:, k], bn * wgt)
    tv = tv - N * (N * tv).sum(1, keepdims=True)
    tv /= np.maximum(np.linalg.norm(tv, axis=1, keepdims=True), 1e-12)
    bv = bv - N * (N * bv).sum(1, keepdims=True) - tv * (tv * bv).sum(1, keepdims=True)
    bv /= np.maximum(np.linalg.norm(bv, axis=1, keepdims=True), 1e-12)
    # lost handedness / degenerate vertices: build the bitangent from the cross product (sign follows the UV winding)
    bad = (np.linalg.norm(tv, axis=1) < 0.5) | (np.linalg.norm(bv, axis=1) < 0.5)
    if bad.any():
        ref = np.where((np.abs(N[:, 1:2]) < 0.9), np.array([[0.0, 1.0, 0.0]]), np.array([[1.0, 0.0, 0.0]]))
        t2 = np.cross(ref, N)
        t2 /= np.maximum(np.linalg.norm(t2, axis=1, keepdims=True), 1e-12)
        tv[bad] = t2[bad]
        bv[bad] = np.cross(N, t2)[bad]
    return tv, bv


def bake_object_normals(snap, rects, nfiles, size, log, green='auto', space='obj', return_smooth=False):
    """Object-space normal map in the layout of the colour atlas: for every atlas rectangle the triangles of the full-resolution
    (posed, undecimated) parts that use that texture are rasterised in UV space; every texel gets the tangent-space normal of the
    2K normal map (`<name>_nrm.dds`) rotated into model space with the interpolated tangent frame (parts without a normal map
    bake their smooth vertex normals).  Gaps are padded a few texels, the rest is (128, 128, 128).
    space 'obj' = axes of the --obj export / preview (Y up, face +Z), 'pac' = the PAC's own axes (Y down, face -Z).
    Returns a (size, size, 3) uint8 image (return_smooth: also the same atlas made of the smooth vertex normals only)."""
    from PIL import Image, ImageDraw
    from scipy import ndimage
    k = size // ATLAS
    img = np.full((size, size, 3), 128, np.uint8)
    img_s = np.full((size, size, 3), 128, np.uint8) if return_smooth else None
    nmaps = {}
    for key, f in nfiles.items():
        if f:
            try:
                nmaps[key] = Image.open(f).convert('RGB')
            except Exception as e:                     # noqa
                log("  WARNING: cannot read normal map %s: %s" % (f, e))
    conv = {'up': 1.0, 'down': -1.0}.get(green)
    if conv is None:
        tot, cnt = 0.0, 0
        pri = [kk for kk in ('body', 'head') if kk in nmaps] or sorted(nmaps, key=lambda kk: -nmaps[kk].size[0] * nmaps[kk].size[1])[:2]
        for kk in pri:
            small = nmaps[kk]
            if max(small.size) > 2048:
                small = small.resize((small.size[0] // 2, small.size[1] // 2), Image.BILINEAR)
            x, y, _ = _decode_normal_map(small)
            s, c = _green_vote(x, y)
            tot, cnt = tot + s, cnt + c
        conv = 1.0 if tot <= 0 else -1.0
        log("Normal maps: green channel = %s (detected from %s)" % ("UP (OpenGL)" if conv > 0 else "DOWN (DirectX)", ", ".join(pri) or "-"))
    flip = np.array([1.0, -1.0, -1.0]) if space == 'obj' else np.ones(3)
    stats = []
    for key, (x0, y0, w0, h0) in sorted(rects.items(), key=lambda kv: (kv[1][1], kv[1][0])):
        parts = [q for q in snap if q.tex == key and len(q.T)]
        if not parts:
            continue
        W_, H_ = w0 * k, h0 * k
        px_uv, cN, cT, cB = [], [], [], []
        for q in parts:
            P, N, UV, T = np.asarray(q.P, float), np.asarray(q.N, float), np.asarray(q.UV, float), np.asarray(q.T)
            tv, bv = _tangent_frames(P, N, UV, T)
            uvt = UV[T]                                                    # (m, 3, 2)
            uvt = uvt - np.floor(uvt.mean(1, keepdims=True))             # whole texture repeats per triangle
            px_uv.append(uvt * np.array([W_, H_]))
            cN.append(N[T]); cT.append(tv[T]); cB.append(bv[T])
        px_uv, cN, cT, cB = (np.concatenate(a) for a in (px_uv, cN, cT, cB))
        ids = Image.new('I', (W_, H_), 0)
        dr = ImageDraw.Draw(ids)
        for i in range(len(px_uv)):
            t = px_uv[i]
            dr.polygon([(t[0, 0], t[0, 1]), (t[1, 0], t[1, 1]), (t[2, 0], t[2, 1])], fill=i + 1)
        ids = np.asarray(ids)
        ys, xs = np.nonzero(ids)
        if len(ys) == 0:
            continue
        tid = ids[ys, xs] - 1
        # barycentric weights of the texel centres
        q0, q1, q2 = px_uv[tid, 0], px_uv[tid, 1], px_uv[tid, 2]
        pt = np.stack([xs + 0.5, ys + 0.5], 1)
        v0, v1, v2 = q1 - q0, q2 - q0, pt - q0
        den = v0[:, 0] * v1[:, 1] - v1[:, 0] * v0[:, 1]
        den = np.where(np.abs(den) < 1e-12, 1.0, den)
        b1 = (v2[:, 0] * v1[:, 1] - v1[:, 0] * v2[:, 1]) / den
        b2 = (v0[:, 0] * v2[:, 1] - v2[:, 0] * v0[:, 1]) / den
        b0 = 1.0 - b1 - b2
        bw = np.clip(np.stack([b0, b1, b2], 1), 0, None)
        bw /= np.maximum(bw.sum(1, keepdims=True), 1e-12)
        n = np.einsum('nk,nkc->nc', bw, cN[tid])
        t_ = np.einsum('nk,nkc->nc', bw, cT[tid])
        b_ = np.einsum('nk,nkc->nc', bw, cB[tid])
        n /= np.maximum(np.linalg.norm(n, axis=1, keepdims=True), 1e-12)
        t_ = t_ - n * (n * t_).sum(1, keepdims=True)
        t_ /= np.maximum(np.linalg.norm(t_, axis=1, keepdims=True), 1e-12)
        b_ = b_ - n * (n * b_).sum(1, keepdims=True) - t_ * (t_ * b_).sum(1, keepdims=True)
        b_ /= np.maximum(np.linalg.norm(b_, axis=1, keepdims=True), 1e-12)
        if key in nmaps:
            nm = nmaps[key].resize((W_, H_), Image.LANCZOS)
            mx, my, mz = _decode_normal_map(nm)
            tx, ty, tz = mx[ys, xs], my[ys, xs], mz[ys, xs]
            # bitangent_up = -dP/dv(down); green up -> +ty along it, green down -> -ty
            nobj = tx[:, None] * t_ - (conv * ty)[:, None] * b_ + tz[:, None] * n
            nobj /= np.maximum(np.linalg.norm(nobj, axis=1, keepdims=True), 1e-12)
            agree = float((nobj * n).sum(1).mean())
            src_txt = "normal map %dx%d" % nmaps[key].size
        else:
            nobj, agree, src_txt = n, 1.0, "no normal map -> smooth vertex normals"
        nsm = n * flip
        nobj = nobj * flip
        tile = np.full((H_, W_, 3), 128, np.uint8)
        cov = np.zeros((H_, W_), bool)
        tile[ys, xs] = np.clip(np.round((nobj * 0.5 + 0.5) * 255.0), 0, 255).astype(np.uint8)
        cov[ys, xs] = True
        pad = max(4, 2 * k)
        dist, (iy, ix) = ndimage.distance_transform_edt(~cov, return_indices=True)
        fill = (~cov) & (dist <= pad)
        tile[fill] = tile[iy[fill], ix[fill]]
        img[y0 * k: y0 * k + H_, x0 * k: x0 * k + W_] = tile
        if return_smooth:
            tile = np.full((H_, W_, 3), 128, np.uint8)
            tile[ys, xs] = np.clip(np.round((nsm * 0.5 + 0.5) * 255.0), 0, 255).astype(np.uint8)
            tile[fill] = tile[iy[fill], ix[fill]]
            img_s[y0 * k: y0 * k + H_, x0 * k: x0 * k + W_] = tile
        stats.append("%s: %d tris, %.0f %% of the rectangle, %s, mean |n.N_geometry| %.3f" % (
            key, len(px_uv), 100.0 * cov.mean(), src_txt, agree))
    for s in stats:
        log("  normal atlas " + s)
    return (img, img_s) if return_smooth else img


BAKE_LIGHTS = ((np.array([-0.25, 0.65, 0.72]), 0.40),      # soft key light from the upper front
               (np.array([0.70, 0.25, -0.45]), 0.20),      # weaker fill from the other side
               (np.array([0.0, 1.0, 0.0]), 0.40))          # the GREEN channel of the object-space normal map = light from straight above
# directions are in the Y-up / +Z-front axes of the object-space normal map


def bake_hair_into_head(head_parts, hair_parts, head_img, src, hair_rgb, ramp, log, opacity=0.92, reach=1.6, T=1024):
    """Paint hair / beard cards into the head colour texture (the 'body' way: no geometry, no extra submesh, the vertices go back to
    the body).  Every head texel is placed in 3D (barycentric position on the head triangle); the strand-coloured hair-card samples
    (4 per card triangle, colour from the card's own UV in the converted strand map) within `reach` model units of that point are
    blended in: the more cards are near, the more hair colour; strand body = opaque, the undercoat between strands more transparent.
    Returns a new PIL RGB image of the size of head_img."""
    from PIL import Image, ImageDraw
    from scipy import ndimage
    from scipy.spatial import cKDTree
    sheets = {}
    for q in hair_parts:
        nm = getattr(q, 'strand', None) or 'combinations'
        if nm in sheets:
            continue
        f = src.raw_texture(q.mcd, nm + '_rai.dds')
        if f:
            im = Image.open(f).convert('RGB')
            if max(im.size) > 1024:
                sc = 1024.0 / max(im.size)
                im = im.resize((max(1, int(im.size[0] * sc)), max(1, int(im.size[1] * sc))), Image.BOX)
            a = np.asarray(im, np.float32) / 255.0
            sheets[nm] = (np.asarray(strand_map_to_colour(im, hair_rgb, ramp), np.float32), strand_body(a, strand_bg(a)))
        else:
            sheets[nm] = (np.asarray(hair_rgb, np.float32).reshape(1, 1, 3), np.ones((1, 1), np.float32))
    pts, cols, ops = [], [], []
    for q in hair_parts:
        col, body = sheets[getattr(q, 'strand', None) or 'combinations']
        tri = np.asarray(q.T)
        if not len(tri):
            continue
        Pq, UVq = np.asarray(q.P, float), np.asarray(q.UV, float)
        shift = np.floor(UVq[tri].mean(1))
        for bw in ((1 / 3., 1 / 3., 1 / 3.), (0.6, 0.2, 0.2), (0.2, 0.6, 0.2), (0.2, 0.2, 0.6)):
            w = np.asarray(bw)[None, :, None]
            pos = (Pq[tri] * w).sum(1)
            uv = ((UVq[tri] * w).sum(1) - shift) % 1.0
            hh, ww = col.shape[:2]
            ix = np.clip((uv[:, 0] * ww).astype(int), 0, ww - 1)
            iy = np.clip((uv[:, 1] * hh).astype(int), 0, hh - 1)
            pts.append(pos)
            cols.append(col[iy, ix])
            ops.append(body[iy, ix])
    pts, cols, ops = np.concatenate(pts), np.concatenate(cols), np.concatenate(ops)
    tree = cKDTree(pts)
    # head texels -> 3D positions
    px, PP = [], []
    for q in head_parts:
        if not len(q.T):
            continue
        uvt = np.asarray(q.UV, float)[q.T]
        uvt = uvt - np.floor(uvt.mean(1, keepdims=True))
        px.append(uvt * T)
        PP.append(np.asarray(q.P, float)[q.T])
    px, PP = np.concatenate(px), np.concatenate(PP)
    ids = Image.new('I', (T, T), 0)
    dr = ImageDraw.Draw(ids)
    for i in range(len(px)):
        t = px[i]
        dr.polygon([(t[0, 0], t[0, 1]), (t[1, 0], t[1, 1]), (t[2, 0], t[2, 1])], fill=i + 1)
    ids = np.asarray(ids)
    ys, xs = np.nonzero(ids)
    tid = ids[ys, xs] - 1
    q0, q1, q2 = px[tid, 0], px[tid, 1], px[tid, 2]
    pt = np.stack([xs + 0.5, ys + 0.5], 1)
    v0, v1, v2 = q1 - q0, q2 - q0, pt - q0
    den = v0[:, 0] * v1[:, 1] - v1[:, 0] * v0[:, 1]
    den = np.where(np.abs(den) < 1e-12, 1.0, den)
    b1 = (v2[:, 0] * v1[:, 1] - v1[:, 0] * v2[:, 1]) / den
    b2 = (v0[:, 0] * v2[:, 1] - v2[:, 0] * v0[:, 1]) / den
    bw = np.clip(np.stack([1.0 - b1 - b2, b1, b2], 1), 0, None)
    bw /= np.maximum(bw.sum(1, keepdims=True), 1e-12)
    pos = np.einsum('nk,nkc->nc', bw, PP[tid])
    K = 6
    dist, idx = tree.query(pos, k=K, distance_upper_bound=reach)
    ok = np.isfinite(dist)
    idx = np.where(ok, idx, 0)
    wgt = np.where(ok, (1.0 - np.where(ok, dist, reach) / reach) ** 2, 0.0)
    wo = wgt * ops[idx] + wgt * 0.35                              # the undercoat between the strands still counts a little
    wsum = np.maximum(wo.sum(1), 1e-9)
    colr = (cols[idx] * wo[..., None]).sum(1) / wsum[:, None]
    dens = np.clip(wgt.sum(1) / 3.0, 0.0, 1.0)
    strand = np.clip((wgt * ops[idx]).sum(1) / np.maximum(wgt.sum(1), 1e-9), 0.0, 1.0)
    alpha = dens * (0.6 + 0.4 * strand) * float(opacity)
    layer = np.zeros((T, T, 3), np.float32)
    al = np.zeros((T, T), np.float32)
    layer[ys, xs] = colr
    al[ys, xs] = alpha
    cov = np.zeros((T, T), bool)
    cov[ys, xs] = True
    dist2, (iy2, ix2) = ndimage.distance_transform_edt(~cov, return_indices=True)       # pad a few texels so the seams do not show skin
    fill = (~cov) & (dist2 <= 4)
    layer[fill] = layer[iy2[fill], ix2[fill]]
    al[fill] = al[iy2[fill], ix2[fill]]
    al = ndimage.gaussian_filter(al, 0.8)
    base = head_img.convert('RGB')
    Wb, Hb = base.size
    pre = Image.fromarray(np.ascontiguousarray(layer[..., 0] * al), mode='F')
    chans = [np.asarray(Image.fromarray(np.ascontiguousarray(layer[..., c] * al), mode='F').resize((Wb, Hb), Image.BILINEAR), np.float32) for c in range(3)]
    a_big = np.clip(np.asarray(Image.fromarray(np.ascontiguousarray(al), mode='F').resize((Wb, Hb), Image.BILINEAR), np.float32), 0.0, 1.0)
    out = np.asarray(base, np.float32) * (1.0 - a_big[..., None]) + np.stack(chans, 2)
    n_cov = int(cov.sum())
    log("Hair painted into the head texture: %d card samples (%d card triangles), %.0f %% of the head's texels got hair colour (alpha > 0.25), "
        "mean alpha there %.2f" % (len(pts), len(pts) // 4, 100.0 * float((al[cov] > 0.25).sum()) / max(n_cov, 1),
                                   float(al[cov][al[cov] > 0.25].mean()) if (al[cov] > 0.25).any() else 0.0))
    return Image.fromarray(np.clip(out + 0.5, 0, 255).astype(np.uint8))


def paint_under_cloth(skin_parts, cloth_parts, images, log, T=2048, grow=0):
    """--hide-under-cloth: the skin texture where clothing covers the body is painted in the colour of the cloth above it, so skin
    never shows through a hem, a thin spot or a gap when the cloth moves (the geometry is not touched).  Every skin texel is placed
    in 3D (barycentric position on the full-resolution skin triangle); its covered share (per-vertex 'under' flags, interpolated)
    decides how much of the colour of the nearest cloth surface point replaces the skin colour: fully covered texels become cloth,
    texels along a hem keep a soft transition.  Head, neck and hands are never covered.  Paints images[key] in place."""
    from PIL import Image, ImageDraw
    from scipy import ndimage
    from scipy.spatial import cKDTree
    pts, cols = [], []
    small = {}
    for c in cloth_parts:
        if getattr(c, 'alpha', False) or not len(c.T) or c.tex not in images:
            continue
        if c.tex not in small:
            im = images[c.tex].convert('RGB')
            if max(im.size) > 1024:
                k = 1024.0 / max(im.size)
                im = im.resize((max(1, int(im.size[0] * k)), max(1, int(im.size[1] * k))), Image.BOX)
            small[c.tex] = np.asarray(im, np.float32)
        col = small[c.tex]
        hh, ww = col.shape[:2]
        tri = np.asarray(c.T)
        Pq, UVq = np.asarray(c.P, float), np.asarray(c.UV, float)
        shift = np.floor(UVq[tri].mean(1))
        for bw in ((1 / 3., 1 / 3., 1 / 3.), (0.6, 0.2, 0.2), (0.2, 0.6, 0.2), (0.2, 0.2, 0.6)):
            w = np.asarray(bw)[None, :, None]
            uv = ((UVq[tri] * w).sum(1) - shift) % 1.0
            pts.append((Pq[tri] * w).sum(1))
            cols.append(col[np.clip((uv[:, 1] * hh).astype(int), 0, hh - 1), np.clip((uv[:, 0] * ww).astype(int), 0, ww - 1)])
    if not pts:
        log("Under-cloth skin texture: no opaque cloth with a texture - nothing painted")
        return
    tree = cKDTree(np.concatenate(pts))
    cols = np.concatenate(cols)
    for key in sorted(set(q.tex for q in skin_parts)):
        if key not in images:
            continue
        base = images[key].convert('RGB')
        Wb, Hb = base.size
        Tw, Th = min(Wb, T), min(Hb, T)
        px, PP, UN = [], [], []
        for q in skin_parts:
            if q.tex != key or getattr(q, 'under', None) is None or not len(q.T):
                continue
            tri = np.asarray(q.T)
            uflag = np.asarray(q.under, bool)
            if grow > 0:                                                   # --under-grow: the paint reaches `grow` vertex rings past the hem
                reg_ = vertex_regions(q.W)
                free_ = np.array([r_ not in ('head', 'neck', 'hand') for r_ in reg_])
                for _ in range(int(grow)):
                    uflag = uflag | (_vertex_neighbors_flag(tri, ~uflag, len(uflag)) & free_)
            und = uflag.astype(float)[tri]                                 # (n, 3)
            sel = und.max(1) > 0
            if not sel.any():
                continue
            uvt = np.asarray(q.UV, float)[tri[sel]]
            uvt = uvt - np.floor(uvt.mean(1, keepdims=True))
            px.append(uvt * np.array([Tw, Th]))
            PP.append(np.asarray(q.P, float)[tri[sel]])
            UN.append(und[sel])
        if not px:
            continue
        px, PP, UN = np.concatenate(px), np.concatenate(PP), np.concatenate(UN)
        ids = Image.new('I', (Tw, Th), 0)
        dr = ImageDraw.Draw(ids)
        for i in range(len(px)):
            t = px[i]
            dr.polygon([(t[0, 0], t[0, 1]), (t[1, 0], t[1, 1]), (t[2, 0], t[2, 1])], fill=i + 1)
        ids = np.asarray(ids)
        ys, xs = np.nonzero(ids)
        if not len(ys):
            continue
        tid = ids[ys, xs] - 1
        q0, q1, q2 = px[tid, 0], px[tid, 1], px[tid, 2]
        v0, v1, v2 = q1 - q0, q2 - q0, np.stack([xs + 0.5, ys + 0.5], 1) - q0
        den = v0[:, 0] * v1[:, 1] - v1[:, 0] * v0[:, 1]
        den = np.where(np.abs(den) < 1e-12, 1.0, den)
        b1 = (v2[:, 0] * v1[:, 1] - v1[:, 0] * v2[:, 1]) / den
        b2 = (v0[:, 0] * v2[:, 1] - v2[:, 0] * v0[:, 1]) / den
        bw = np.clip(np.stack([1.0 - b1 - b2, b1, b2], 1), 0, None)
        bw /= np.maximum(bw.sum(1, keepdims=True), 1e-12)
        cover = np.clip((bw * UN[tid]).sum(1), 0.0, 1.0)
        a_tx = cover * cover * (3.0 - 2.0 * cover)                          # smoothstep: soft transition along the hem
        _, nn = tree.query(np.einsum('nk,nkc->nc', bw, PP[tid]), k=1)
        layer = np.zeros((Th, Tw, 3), np.float32)
        al = np.zeros((Th, Tw), np.float32)
        layer[ys, xs] = cols[nn]
        al[ys, xs] = a_tx
        cov = np.zeros((Th, Tw), bool)
        cov[ys, xs] = True
        for ch in range(3):                                                  # calm the colour (one cloth sample per texel is speckled)
            num = ndimage.gaussian_filter(layer[..., ch] * cov, 1.6)
            den_ = ndimage.gaussian_filter(cov.astype(np.float32), 1.6)
            layer[..., ch] = np.where(cov, num / np.maximum(den_, 1e-6), 0.0)
        d2, (iy2, ix2) = ndimage.distance_transform_edt(~cov, return_indices=True)       # a few texels past the seams
        fill = (~cov) & (d2 <= 4)
        layer[fill] = layer[iy2[fill], ix2[fill]]
        al[fill] = al[iy2[fill], ix2[fill]]
        al = ndimage.gaussian_filter(al, 0.8)
        chans = [np.asarray(Image.fromarray(np.ascontiguousarray(layer[..., c] * al), mode='F').resize((Wb, Hb), Image.BILINEAR), np.float32) for c in range(3)]
        a_big = np.clip(np.asarray(Image.fromarray(np.ascontiguousarray(al), mode='F').resize((Wb, Hb), Image.BILINEAR), np.float32), 0.0, 1.0)
        out = np.asarray(base, np.float32) * (1.0 - a_big[..., None]) + np.stack(chans, 2)
        images[key] = Image.fromarray(np.clip(out + 0.5, 0, 255).astype(np.uint8))
        log("Under-cloth skin texture: %.0f %% of the '%s' texture's texels (%.0f %% of those covered by skin triangles) are painted in the colour "
            "of the cloth above them (%d cloth colour samples)" % (100.0 * float((a_big > 0.5).mean()), key,
                                                                    100.0 * float((al[cov] > 0.5).sum()) / max(int(cov.sum()), 1), len(cols)))


BAKE_KEY_STRENGTH = {'body': 1.0, 'head': 0.45}      # every other texture (cloth, shoes, gloves: fine woven relief turns into noise at 512) uses BAKE_OTHER
BAKE_OTHER = 0.35


def normal_shade_map(detail, smooth, strength, covered=None, shadow=1.0):
    """Brightness factor (float32, size x size) that carries the normal-map DETAIL (muscle / vein / wrinkle relief) as baked light:
    for every texel the lit value of the detailed normal minus the lit value of the smooth vertex normal, for a soft key light from
    the upper front, a weaker fill from the other side and the green (up) channel of the object normal as a top light, so flat surfaces
    stay exactly as they are and only the relief changes.  `shadow` > 1 makes the darker side (the little shadows under and between
    muscles, in creases) stronger than the bright side
    (the game's own lighting then works on the smooth vertex normals as usual).  A constant bias of the map is removed so the average
    brightness does not move.  1.0 = no change."""
    d = detail.astype(np.float32) / 127.5 - 1.0
    sm = smooth.astype(np.float32) / 127.5 - 1.0
    diff = d - sm
    sh = np.zeros(diff.shape[:2], np.float32)
    for L, w in BAKE_LIGHTS:
        L = (L / np.linalg.norm(L)).astype(np.float32)
        sh += w * (diff @ L)
    if covered is not None and covered.any():
        sh -= float(np.median(sh[covered]))
        sh[~covered] = 0.0
    sh = np.where(sh < 0, sh * (1.0 + 0.4 * float(shadow)), sh)
    return np.clip(1.0 + float(strength) * 1.3 * sh, 0.6, 1.4).astype(np.float32)


def _sharpen(im, strength):
    """unsharp mask for a colour patch that was shrunk a lot (strength 1 = radius 1.0 px, +150 %); the alpha / colour range is kept"""
    from PIL import ImageFilter
    st = max(0.0, float(strength))
    if st <= 0:
        return im
    return im.filter(ImageFilter.UnsharpMask(radius=1.0, percent=int(round(150 * st)), threshold=2))


def compose_atlas(rects, images, donor_img, hair_rgb, size, keep_rows, log, fixed=(), shade=None, only=None, base=None, sharpen=0.0):
    """rects are in the 512 grid; `size` is the output edge (512 for the PAC, 4096 for the export).
    fixed: [(PIL image, rect512)] pasted last (e.g. the 2K eye texture in the donor's eye area).
    base + only: an atlas that was composed before is changed IN PLACE - only the patches named in `only` are drawn again (colour only;
    alpha, the other patches and `fixed` stay as they are).  Used for the plain 4K export, which needs no second full atlas in memory."""
    from PIL import Image
    k = size // ATLAS
    if base is not None:
        img, alpha_plane = base, None
    else:
        if size == ATLAS:
            img = donor_img.copy()
        else:
            img = np.zeros((size, size, 4), np.uint8)
            if keep_rows:
                big = Image.fromarray(donor_img).resize((size, size), Image.LANCZOS)
                img[:keep_rows * k] = np.asarray(big)[:keep_rows * k]
        img[keep_rows * k:, :, :3] = 0
        alpha_plane = np.full((size, size), 255, np.uint8)
    for key, (x, y, w, h) in rects.items():
        if base is not None and (only is None or key not in only or key in ('hair', 'eye')):
            continue
        x, y, w, h = x * k, y * k, w * k, h * k
        if key == 'hair' and images.get('hair') is not None and images.get('hair_alpha') is not None:
            al, cut = images['hair_alpha']                  # see-through gaps between the strands of the beard cards in the atlas
            rgba = alpha_resize(images['hair'], al, (w, h), cut=(cut if size == ATLAS else None))
            img[y:y + h, x:x + w, :3] = rgba[..., :3]
            alpha_plane[y:y + h, x:x + w] = rgba[..., 3]
            continue
        if key == 'hair' and images.get('hair') is None:
            col = np.array(hair_rgb, np.float32)
            rng = np.random.RandomState(7)
            patch = col[None, None, :] * (0.92 + 0.16 * rng.rand(h, w, 1))
            img[y:y + h, x:x + w, :3] = np.clip(patch, 0, 255).astype(np.uint8)
            continue
        im = images.get(key)
        if im is None:
            img[y:y + h, x:x + w, :3] = (128, 128, 128)
            if size == ATLAS:
                log("  WARNING: no colour texture for '%s' (grey patch)" % key)
            continue
        small = im.resize((w, h), Image.LANCZOS)
        if sharpen and size == ATLAS and key not in ('eye', 'hair'):
            small = _sharpen(small, sharpen)
        patch = np.asarray(small).astype(np.float32)
        if shade is not None and key not in ('eye', 'hair'):
            ks = shade.shape[0] // ATLAS
            tile = shade[(y // k) * ks:((y // k) + (h // k)) * ks, (x // k) * ks:((x // k) + (w // k)) * ks]
            if tile.size:
                tile = 1.0 + (tile - 1.0) * BAKE_KEY_STRENGTH.get(key, BAKE_OTHER)
                tile = np.asarray(Image.fromarray(np.ascontiguousarray(tile), mode='F').resize((w, h), Image.BILINEAR), np.float32)
                patch = patch * tile[..., None]
        img[y:y + h, x:x + w, :3] = np.clip(patch + 0.5, 0, 255).astype(np.uint8)
    if base is not None:
        return img
    for im, (x, y, w, h) in fixed:
        x, y, w, h = x * k, y * k, w * k, h * k
        img[y:y + h, x:x + w, :3] = np.asarray(im.resize((w, h), Image.LANCZOS))
    img[..., 3] = alpha_plane
    return img


# --------------------------------------------------------------------------------------------------
# block assignment + fit
# --------------------------------------------------------------------------------------------------
def block_of(part, tri_y, H):
    """donor face block for each triangle (array).  y is 2K height-down (feet 0), H = model height."""
    n = len(tri_y)
    if part.role == 'hair':
        return np.zeros(n, int)
    low = part.tex
    if low in ('bottoms', 'underwear') or 'kneepad' in low:
        return np.ones(n, int)
    if low.startswith('shoes'):
        return np.full(n, 2)
    if part.role == 'skin' and part.tex == 'body':
        b = np.zeros(n, int)
        b[tri_y > -0.53 * H] = 1                       # below the waist
        b[tri_y > -0.20 * H] = 2                       # below the knees -> boot block
        return b
    return np.zeros(n, int)


def fit_to_donor(parts, donor, mode, log):
    """Return (scale, offset(3)) taking 2K coords to donor raw coords (both Y-down, face -Z, left +X)."""
    P = np.concatenate([p.P for p in parts if p.role != 'hair'])
    dp = np.array([donor.pos(i) for i in range(donor.real_vcount)])
    lo, hi = P.min(0), P.max(0)
    dlo, dhi = dp.min(0), dp.max(0)
    s = (dhi[1] - dlo[1]) / (hi[1] - lo[1])
    if mode == 'bbox':
        sx = (dhi[0] - dlo[0]) / (hi[0] - lo[0])
        sc = np.array([sx, s, s])
    else:
        sc = np.array([s, s, s])
    off = np.zeros(3)
    off[1] = dlo[1] - lo[1] * s
    off[0] = (dlo[0] + dhi[0]) / 2 - (lo[0] + hi[0]) / 2 * sc[0]
    # depth: match the centroid of the whole body to the donor's
    off[2] = dp[:, 2].mean() - P[:, 2].mean() * s
    log("Fit: scale xyz = %s, offset = %s (height %.1f cm -> %.2f units)" % (
        np.round(sc, 4), np.round(off, 3), hi[1] - lo[1], dhi[1] - dlo[1]))
    return sc, off


# --------------------------------------------------------------------------------------------------
# atlas
# --------------------------------------------------------------------------------------------------
def _split_rects(items, rect):
    """items: [(key, weight)] -> {key: (x,y,w,h)} bisection treemap."""
    x, y, w, h = rect
    if len(items) == 1:
        return {items[0][0]: rect}
    items = sorted(items, key=lambda kv: -kv[1])
    tot = sum(v for _, v in items)
    a, b, sa = [], [], 0.0
    for kv in items:                                   # balance the two halves
        if sa < tot / 2 or not a:
            a.append(kv); sa += kv[1]
        else:
            b.append(kv)
    if not b:
        b = [a.pop()]
        sa -= b[0][1]
    f = sa / tot
    if w >= h:
        w1 = max(8, int(round(w * f / 8.0)) * 8)
        w1 = min(w1, w - 8)
        r = _split_rects(a, (x, y, w1, h)); r.update(_split_rects(b, (x + w1, y, w - w1, h)))
    else:
        h1 = max(8, int(round(h * f / 8.0)) * 8)
        h1 = min(h1, h - 8)
        r = _split_rects(a, (x, y, w, h1)); r.update(_split_rects(b, (x, y + h1, w, h - h1)))
    return r


def _split_rects_fit(items, rect, aspects, step=8):
    """Like _split_rects, but it also looks at the SHAPE of every patch.  A texture that is squeezed into a rectangle of another
    shape keeps only the sharpness of its poorer axis, so each patch should have about the aspect of its source texture
    (head 1:1, body 2:1, boots 2:1 ...).  items: [(key, weight)], aspects: {key: source width / height}.  Every split is tried both
    ways (side by side / one above the other), for the balanced halves and for 'heaviest j patches | the rest'; the layout with the least
    weighted aspect error wins.  The area of a patch still follows its weight."""
    import math
    wt = dict(items)
    memo = {}

    def asp(k):
        return float(aspects.get(k, 1.0) or 1.0)

    def solve(ks, w, h):
        key = (ks, w, h)
        if key in memo:
            return memo[key]
        if len(ks) == 1:
            k = ks[0]
            res = (wt[k] * abs(math.log((w / float(h)) / asp(k))), {k: (0, 0, w, h)})
            memo[key] = res
            return res
        order = sorted(ks, key=lambda k_: (-wt[k_], k_))
        tot = sum(wt[k_] for k_ in order)
        cands = []
        sa, a_ = 0.0, []
        for k_ in order:                                       # the balanced split of _split_rects
            if sa < tot / 2 or not a_:
                a_.append(k_); sa += wt[k_]
        if len(a_) == len(order):
            a_ = a_[:-1]
        cands.append(tuple(a_))
        for j in range(1, len(order)):                         # the j heaviest | the rest
            cands.append(tuple(order[:j]))
        best = None
        for a in dict.fromkeys(cands):
            b = tuple(k_ for k_ in order if k_ not in a)
            f = sum(wt[k_] for k_ in a) / tot
            for vertical in (True, False):
                if vertical and w >= 2 * step:
                    w1 = min(max(step, int(round(w * f / float(step))) * step), w - step)
                    ra, rb = solve(tuple(sorted(a)), w1, h), solve(tuple(sorted(b)), w - w1, h)
                    lay = dict((k_, (r[0], r[1], r[2], r[3])) for k_, r in ra[1].items())
                    lay.update((k_, (r[0] + w1, r[1], r[2], r[3])) for k_, r in rb[1].items())
                elif (not vertical) and h >= 2 * step:
                    h1 = min(max(step, int(round(h * f / float(step))) * step), h - step)
                    ra, rb = solve(tuple(sorted(a)), w, h1), solve(tuple(sorted(b)), w, h - h1)
                    lay = dict((k_, (r[0], r[1], r[2], r[3])) for k_, r in ra[1].items())
                    lay.update((k_, (r[0], r[1] + h1, r[2], r[3])) for k_, r in rb[1].items())
                else:
                    continue
                cost = ra[0] + rb[0]
                if best is None or cost < best[0] - 1e-12:
                    best = (cost, lay)
        if best is None:                                       # no room to split: the old bisection decides
            best = (0.0, _split_rects([(k_, wt[k_]) for k_ in ks], (0, 0, w, h)))
        memo[key] = best
        return best

    x, y, w, h = rect
    lay = solve(tuple(sorted(wt)), w, h)[1]
    return dict((k, (r[0] + x, r[1] + y, r[2], r[3])) for k, r in lay.items())


def _dds_size(path):
    """(width, height) of a .dds file from its header, or None"""
    try:
        with open(path, 'rb') as f:
            hd = f.read(20)
        if hd[:4] == b'DDS ':
            h, w = struct.unpack_from('<II', hd, 12)
            if w > 0 and h > 0:
                return w, h
    except Exception:                                            # noqa
        pass
    return None


def atlas_uv(uv, rect):
    """2K uv (0..1, v down in image space) -> atlas pixel coords"""
    x, y, w, h = rect
    f = uv - np.floor(uv)                               # tiling -> fract
    px = x + 0.5 + f[:, 0] * (w - 1.0)
    py = y + 0.5 + f[:, 1] * (h - 1.0)
    return np.stack([px, py], 1)


# --------------------------------------------------------------------------------------------------
# donor helpers
# --------------------------------------------------------------------------------------------------
def donor_vertex_weights(donor):
    dW = donor.weights()
    out = []
    for i in range(donor.real_vcount):
        w = dW[i]
        out.append(dict((donor.bones[b][0], x) for b, x in w.items() if x > 0))
    return out


def load_donor_pac(path):
    raw = open(path, 'rb').read()
    epk = pacio.Epk8(raw)
    pach = pacio.Pach(epk.inner)
    dumy_raw, f2 = pacio.bpe_unwrap(pach.get(2))
    return epk, pach, dumy_raw


def donor_atlas_image(pach):
    tex_raw, _ = pacio.bpe_unwrap(pach.get(9))
    n = struct.unpack_from('<I', tex_raw, 0)[0]
    for i in range(n):
        o = 0x10 + i * 0x20
        name = tex_raw[o:o + 16].split(b'\0')[0].decode('latin1')
        size, off = struct.unpack_from('<II', tex_raw, o + 20)
        if name == DONOR_COLOR_ENTRY:
            tpl = tex_raw[off:off + size]
            return gxtex.decode_tpl(tpl), tpl, (off, size), tex_raw
    raise SystemExit("donor texture archive has no 'color' texture")


class HairDonorError(Exception):
    """The hair donor pac cannot be used; the hair then stays in the body model (the run is not aborted)."""


def _paletted(tpl):
    try:
        return gxtex.tpl_header_info(tpl)['fmt'] in (8, 9)          # C4 / C8
    except Exception:
        return False


def find_hair_texture(ents, refs):
    """Which texture of the hair donor's archive belongs to its hair model.  The hair donors differ in how that texture is
    called (ch107: 'hair_'), so the name is not required: the texture the hair DUMY itself refers to is used, then any
    'hair...' / 'kami...' texture, then any paletted one.  The body atlas ('color') and the blood layer never count.
    Returns (name, tpl, how) or (None, None, None)."""
    byname = dict((n, d) for n, _, d in ents)
    skip = lambda n: n.lower() == DONOR_COLOR_ENTRY or n.lower().startswith('blood')      # noqa: E731
    for n in refs:                                   # the texture the hair model really uses (Wii pacs: 'trans')
        if n in byname and not skip(n):
            return n, byname[n], "referenced by the hair model"
    for n in HAIR_TEX_NAMES:                         # known names of the hair texture
        if n in byname:
            return n, byname[n], "known hair texture name '%s'" % n
    for key, how in ((lambda n: n.lower().startswith('hair'), "name starts with 'hair'"),
                     (lambda n: 'hair' in n.lower() or 'kami' in n.lower(), "name contains 'hair' / 'kami'"),
                     (lambda n: _paletted(byname[n]), "paletted texture")):
        for n in byname:
            if not skip(n) and key(n):
                return n, byname[n], how
    return None, None, None


def load_hair_donor(path, log=print):
    """Open a pac that has a hair DUMY (PACH 0x2710): its hair model, the spring entries and a header for the new
    'hair_' strand texture.  Raises HairDonorError when the file has no usable hair model."""
    try:
        raw = open(path, 'rb').read()
        epk = pacio.Epk8(raw)
        pach = pacio.Pach(epk.inner)
        if not pach.has(HAIR_ENTRY):
            raise HairDonorError("%s has no hair DUMY (PACH entry 0x%X)" % (os.path.basename(path), HAIR_ENTRY))
        dumy = T.Dumy(pacio.bpe_unwrap(pach.get(HAIR_ENTRY))[0])
        ents = []
        if pach.has(9):
            ents = texarchive.read(pacio.bpe_unwrap(pach.get(9))[0])[1]
    except HairDonorError:
        raise
    except Exception as e:                      # corrupt / unexpected layout
        raise HairDonorError("%s cannot be read as a hair donor (%s: %s)" % (os.path.basename(path), type(e).__name__, e))
    refs = []
    for nm in dumy.names:
        if nm and nm[0] and nm[0] not in refs:
            refs.append(nm[0])
    name, tpl, how = find_hair_texture(ents, refs)
    base = os.path.basename(path)
    if name is None:
        # nothing usable in the archive: use the name the hair model refers to (or 'hair_') and build the header ourselves
        name = next((n for n in refs if n.lower() != DONOR_COLOR_ENTRY and not n.lower().startswith('blood')), HAIR_TEX)
        log("Hair donor %s: its texture archive has no hair texture (%s) -> a new '%s' texture is created with a generated header" % (
            base, ", ".join(n for n, _, _ in ents) or "empty", name))
    else:
        log("Hair donor %s: hair texture '%s' (%s)" % (base, name, how))
    # the hair model must point at the texture that is written; repoint its texture slots only when they do not already
    names = None
    if refs and name not in refs:
        target = name if len(name) + 5 <= 10 else HAIR_TEX          # a slot holds 'name\0tga\0' in 10 bytes
        names = [list(x) for x in dumy.names]
        for x in names:
            x[0] = target
        log("Hair donor %s: hair model texture slots %s -> '%s'" % (base, refs, target))
        name = target
    return dict(pach=pach, dumy=dumy, hdr=gxtex.c8_template_header(tpl), texname=name, names=names)



# --------------------------------------------------------------------------------------------------
# eyes (2K26 M_EYE -> donor eye submesh budget)
# --------------------------------------------------------------------------------------------------
# --------------------------------------------------------------------------------------------------
# main pipeline
# --------------------------------------------------------------------------------------------------
# --------------------------------------------------------------------------------------------------
# eyes (2K26 M_EYE -> eye budget)
# --------------------------------------------------------------------------------------------------
EYE_TRIS, EYE_VERTS = 40, 25          # per eye, used when the donor has no eye submesh of its own


def eye_front(p):
    """(triangle indices of the visible front cap of a 2K eyeball, its centre, its mean radius)"""
    used = np.unique(p.T)
    c = p.P[used].mean(0)
    R = float(np.linalg.norm(p.P[used] - c, axis=1).mean())
    cen = p.P[p.T].mean(1)
    front = (cen[:, 2] - c[2]) <= 0.15 * R            # character looks towards -Z
    return np.nonzero(front)[0], c, R


def build_eyes(eye_parts, rect, tris_each, verts_each, merge_tol, log):
    """Each 2K eyeball: keep the front cap (the part that can be seen), merge, decimate to the per-eye budget."""
    out = []
    for p in eye_parts:
        sel, c, R = eye_front(p)
        p.PUV = atlas_uv(p.UV, rect)
        P, N, W, tris, cuvs = weld_collect([(p, sel)], merge_tol)
        nt, nc = qem.decimate(P, tris, cuvs, tris_each, weights=W, target_verts=verts_each)
        nt, nc = qem.enforce_budget(P, nt, nc, tris_each, verts_each)
        used2 = sorted(set(v for t in nt for v in t))
        log("Eye %s: centre (%.2f, %.2f, %.2f) radius %.2f -> %d vertices / %d triangles (budget %d / %d)" % (
            p.name.split('/')[-1], c[0], c[1], c[2], R, len(used2), len(nt), verts_each, tris_each))
        out.append((P, N, W, nt, nc))
    return out


# --------------------------------------------------------------------------------------------------
# eyes + mouth as their own texture ('face', --face-tex)
# --------------------------------------------------------------------------------------------------
FACE_TEX_NAME = 'face'
FACE_PAD = 4                          # texels between the two patches / around the crops (bilinear filtering must not leak)
FACE_CROP_MARGIN = 6                  # source texels of real neighbour pixels kept around a crop
MOUTH_WINDOW = dict(x=1.2, up=1.0, down=0.6, z=4.0)     # cm around the 2K26 teeth / tongue / mouth bag (the lips + a skin margin)


def eye_uv_box(eye_parts):
    """UV box (u0, v0, u1, v1) the visible front caps of the eyes use in the eye texture"""
    lo, hi = np.array([9.0, 9.0]), np.array([-9.0, -9.0])
    for p in eye_parts:
        sel = eye_front(p)[0]
        if not len(sel):
            continue
        uv = np.asarray(p.UV, float)[p.T[sel]].reshape(-1, 2)
        uv = uv - np.floor(uv)
        lo, hi = np.minimum(lo, uv.min(0)), np.maximum(hi, uv.max(0))
    if lo[0] > hi[0]:
        return None
    return (float(lo[0]), float(lo[1]), float(hi[0]), float(hi[1]))


def mouth_uv_box(parts, sc, log=None):
    """UV box (u0, v0, u1, v1) in the head texture of the head triangles around the 2K26 mouth (lips + margin), or None"""
    heads = [p for p in parts if p.role == 'skin' and p.tex == 'head' and getattr(p, 'mouth_pts', None) is not None and len(p.T)]
    if not heads:
        return None
    mp = np.concatenate([p.mouth_pts for p in heads])
    k = np.asarray(sc, float) * np.ones(3)
    lo, hi = mp.min(0), mp.max(0)
    w = MOUTH_WINDOW
    uvs, ntri = [], 0
    for p in heads:
        cen = p.P[p.T].mean(1)
        m = ((cen[:, 0] > lo[0] - w['x'] * k[0]) & (cen[:, 0] < hi[0] + w['x'] * k[0]) &
             (cen[:, 1] > lo[1] - w['up'] * k[1]) & (cen[:, 1] < hi[1] + w['down'] * k[1]) &
             (cen[:, 2] < lo[2] + w['z'] * k[2]))
        if m.any():
            uv = np.asarray(p.UV, float)[p.T[m]].reshape(-1, 2)
            uvs.append(uv - np.floor(uv))
            ntri += int(m.sum())
    if not uvs or ntri < 12:
        return None
    uv = np.concatenate(uvs)
    lo, hi = uv.min(0), uv.max(0)
    return (float(lo[0]), float(lo[1]), float(hi[0]), float(hi[1]))


def plan_face_texture(eye_img, eye_box, head_img, mouth_box, fw):
    """Lay the eye crop and the lip crop out side by side in a fw x fw/2 texture at their source resolution (scaled down together
    only when they do not fit).  -> dict(fw, fh, scale, eye=patch, mouth=patch) with patch = dict(src=(x0, y0, x1, y1) source texels,
    cuv=(cu0, cv0, cu1, cv1) the UV box of that crop, dst=(x, y, w, h) texels of the face texture); None when there is nothing."""
    fh = fw // 2
    items = []
    for key, img, box in (('eye', eye_img, eye_box), ('mouth', head_img, mouth_box)):
        if img is None or box is None:
            continue
        W0, H0 = img.size
        x0 = max(0, int(np.floor(box[0] * W0)) - FACE_CROP_MARGIN)
        y0 = max(0, int(np.floor(box[1] * H0)) - FACE_CROP_MARGIN)
        x1 = min(W0, int(np.ceil(box[2] * W0)) + FACE_CROP_MARGIN)
        y1 = min(H0, int(np.ceil(box[3] * H0)) + FACE_CROP_MARGIN)
        if x1 - x0 < 8 or y1 - y0 < 8:
            continue
        items.append((key, (x0, y0, x1, y1), (x0 / float(W0), y0 / float(H0), x1 / float(W0), y1 / float(H0)), box))
    if not items:
        return None
    tot_w = sum(i[1][2] - i[1][0] for i in items) + FACE_PAD * (len(items) + 1)
    max_h = max(i[1][3] - i[1][1] for i in items) + 2 * FACE_PAD
    s = min(1.0, fw / float(tot_w), fh / float(max_h))
    plan = dict(fw=fw, fh=fh, scale=s)
    x = FACE_PAD
    for key, src, cuv, box in items:
        w = max(8, int(round((src[2] - src[0]) * s)))
        h = max(8, int(round((src[3] - src[1]) * s)))
        plan[key] = dict(src=src, cuv=cuv, box=box, dst=(x, FACE_PAD, w, h))
        x += w + FACE_PAD
    return plan


def face_eye_rect(patch):
    """a rect for atlas_uv() that puts the UV box of the eye crop onto its patch of the face texture (px = x + (u - cu0) * K)"""
    cu0, cv0, cu1, cv1 = patch['cuv']
    x, y, w, h = patch['dst']
    Kx, Ky = w / (cu1 - cu0), h / (cv1 - cv0)
    return (x - 0.5 - cu0 * Kx, y - 0.5 - cv0 * Ky, Kx + 1.0, Ky + 1.0)


def build_face_texture(plan, eye_img, head_img, shade, head_rect, log):
    """RGBA uint8 (fh, fw, 4) of the face texture: the eye crop (as it is) and the lip crop (with the same baked relief light as the
    head patch of the atlas, so both match along the border)."""
    from PIL import Image
    fw, fh = plan['fw'], plan['fh']
    out = np.zeros((fh, fw, 4), np.uint8)
    out[..., 3] = 255
    fill = None
    for key, img in (('mouth', head_img), ('eye', eye_img)):
        pt = plan.get(key)
        if pt is None or img is None:
            continue
        x, y, w, h = pt['dst']
        crop = img.convert('RGB').crop(pt['src'])
        if crop.size != (w, h):
            crop = crop.resize((w, h), Image.LANCZOS)
        a = np.asarray(crop, np.float32)
        if key == 'mouth' and shade is not None and head_rect is not None:
            ks = shade.shape[0] // ATLAS
            hx, hy, hw, hh = head_rect
            cu0, cv0, cu1, cv1 = pt['cuv']
            sx0, sx1 = int((hx + cu0 * hw) * ks), int(np.ceil((hx + cu1 * hw) * ks))
            sy0, sy1 = int((hy + cv0 * hh) * ks), int(np.ceil((hy + cv1 * hh) * ks))
            tile = shade[sy0:sy1, sx0:sx1]
            if tile.size and tile.shape[0] > 1 and tile.shape[1] > 1:
                tile = 1.0 + (tile - 1.0) * BAKE_KEY_STRENGTH.get('head', BAKE_OTHER)
                tile = np.asarray(Image.fromarray(np.ascontiguousarray(tile, np.float32), mode='F').resize((w, h), Image.BILINEAR), np.float32)
                a = a * tile[..., None]
        patch = np.clip(a + 0.5, 0, 255).astype(np.uint8)
        out[y:y + h, x:x + w, :3] = patch
        q_ = FACE_PAD                                      # the border is the patch's own edge pixels (no dark seam when filtered)
        y0_, x0_ = max(0, y - q_), max(0, x - q_)
        out[y0_:y, x:x + w, :3] = patch[0:1]
        out[y + h:y + h + q_, x:x + w, :3] = patch[-1:]
        out[y:y + h, x0_:x, :3] = patch[:, 0:1]
        out[y:y + h, x + w:x + w + q_, :3] = patch[:, -1:]
        out[y0_:y, x0_:x, :3] = patch[0, 0]
        out[y0_:y, x + w:x + w + q_, :3] = patch[0, -1]
        out[y + h:y + h + q_, x0_:x, :3] = patch[-1, 0]
        out[y + h:y + h + q_, x + w:x + w + q_, :3] = patch[-1, -1]
        if fill is None or key == 'mouth':
            fill = patch.reshape(-1, 3).mean(0)
    if fill is not None:                                   # unused texels: the average of the patches (compresses to nothing)
        used = np.zeros((fh, fw), bool)
        for key in ('eye', 'mouth'):
            if plan.get(key):
                x, y, w, h = plan[key]['dst']
                used[max(0, y - FACE_PAD):y + h + FACE_PAD, max(0, x - FACE_PAD):x + w + FACE_PAD] = True
        out[~used, :3] = np.clip(fill + 0.5, 0, 255).astype(np.uint8)
    return out


def face_tpl(donor_tpl, rgba):
    """TPL bytes (CMPR) of the face texture: the donor's own header with the size patched in"""
    h, w = rgba.shape[:2]
    info = gxtex.tpl_header_info(donor_tpl)
    hdr = bytearray(donor_tpl[:info['data_off']])
    struct.pack_into('>HH', hdr, info['img_hdr'], h, w)
    return bytes(hdr) + gxtex.encode_cmpr(rgba)


# --------------------------------------------------------------------------------------------------
# main pipeline
# --------------------------------------------------------------------------------------------------
DEFAULTS = dict(out=None, attire=None, hair_color='auto', beard_tip_mix=0.5, hair_gap_alpha=0.55, fit='height', cull=1.0, cull_depth=8.0, cull_margin=2,
                normals='donor', normal_dist=2.5, weld='auto', tri_scale=1.0, size_limit=1.12, merge=0.01,
                pose='legs-fingers', hair='separate', hair_donor=None, hair_springs=True, eyes='2k', blood=True,
                obj=False, face_bias=5.0, body_bias=2.0, limit_boost=1.0, atlas_4k=True, atlas_plain=True, atlas_size=4096,
                boundary_weight=50.0, hair_share=0.18, face_share=0.25, hand_share=0.15, hair_max_tris=1000, hair_max_verts=None, hair_mode='cards', beard_open_mouth=False, beard_texture='colour', arms='match', hand_height='donor', arm_reach='donor', only=None, exclude=None, variants=False,
                beard_uv='default', normal_atlas=True, normal_green='auto', normal_space='obj', bake_normals=1.0, bake_size=2048, bake_shadow=1.0, beard_as='hair', hair_as='hair', hair_body_opacity=0.92,
                beard_in_body=False, beard_atlas_share=0.06, beard_alpha=True, beard_alpha_cut=0.5, finger_length='donor', hide_under_cloth=False, under_grow=0, poke_fix='scale',
                atlas_focus=ATLAS_FOCUS, sharpen=SHARPEN, seam_weld=SEAM_WELD,
                face_tex=False, face_tex_size=1024, keep_arm_wrist=False)


def with_defaults(args):
    """fill in options a caller (e.g. an older GUI) did not set"""
    for k, v in DEFAULTS.items():
        if not hasattr(args, k):
            setattr(args, k, v)
    if args.pose is True:
        args.pose = 'legs-fingers'
    elif args.pose is False or args.pose is None:
        args.pose = 'none'
    return args


def calibrate_shares(orig, locked, vreg, T_t, V_t, groups, bound_w, log, rounds=8, tol=0.05):
    """Quadric decimation spends triangles where the *geometric error* is.  A smooth, densely sampled head needs far fewer
    than its share, and thin fingers are expensive to keep, so plain priority factors leave the face thin and the hands
    ragged.  This trial-decimates the body a few times and scales the priority of each group of regions until the group
    really keeps its share of the body triangles (beard / hair excluded).
    groups: {name: (regions, share)}.  Returns the new per-vertex importance array."""
    P, N, W, imp, tris, cuvs, tg = orig
    base = np.asarray(imp, float)
    reg = np.asarray(vreg)
    lockmask = np.zeros(len(P), bool)
    if locked:
        lockmask[list(locked)] = True
    masks = {}
    for name, (regs, share) in groups.items():
        mk = np.isin(reg, regs) & ~lockmask
        if mk.any() and share > 0:
            masks[name] = mk
    if not masks:
        return base
    n_hair = int(sum(1 for t in tris if t[0] in locked))
    body_t = max(1, T_t - n_hair)
    target = dict((k, groups[k][1] * body_t) for k in masks)
    mult = dict((k, 1.0) for k in masks)

    def counts(nt):
        a = np.asarray(nt, int)
        free = ~lockmask[a[:, 0]]
        return dict((k, int(((mk[a].sum(1) >= 2) & free).sum())) for k, mk in masks.items())

    def importance():
        out = base.copy()
        for k, mk in masks.items():
            out[mk] = base[mk] * mult[k]
        return out
    best = None
    for i in range(rounds):
        nt, nc, idx = qem.decimate(P, tris, cuvs, T_t, weights=W, target_verts=V_t, importance=importance(), return_index=True,
                                   bound_w=bound_w, locked=locked)
        got = counts(nt)
        err = max(abs(math.log(max(1, got[k]) / target[k])) for k in masks)
        log("Priority calibration %d: %s" % (i + 1, "; ".join("%s x%.2f -> %d triangles (target %d)" % (
            k, mult[k], got[k], target[k]) for k in masks)))
        if best is None or err < best[0]:
            best = (err, dict(mult))
        if err < tol:
            break
        for k in masks:
            mult[k] = min(300.0, max(0.1, mult[k] * (target[k] / max(1, got[k])) ** 1.5))
    mult = best[1]
    out = base.copy()
    for k, mk in masks.items():
        out[mk] = base[mk] * mult[k]
    return out


def build(args, log=print):
    from PIL import Image          # noqa: F401
    args = with_defaults(args)
    src = Source(args.character, log)
    try:
        return _build(args, src, log)
    finally:
        src.close()


def _build(args, src, log):
    epk, pach, dumy_raw = load_donor_pac(args.donor)
    donor = T.Dumy(dumy_raw)
    donor_verts = donor.real_vcount
    dW = donor_vertex_weights(donor)                 # {bone name: weight} per donor vertex
    pr = make_profile(donor, dW, log)
    nblocks = pr.nblocks
    donor_tris = pr.tris
    boost = max(1.0, float(args.limit_boost))
    V_lim = int(donor_verts * boost)
    T_lim = int(sum(donor_tris) * boost)
    B_lim = int(len(dumy_raw) * args.size_limit * boost)
    log("Donor: %d vertices, %d triangles in %d submeshes %s, %d bones, DUMY %d bytes" % (
        donor_verts, sum(donor_tris), nblocks, donor_tris, donor.bone_count, len(dumy_raw)))
    if pr.mode == 'legacy':
        log("Donor layout: submeshes %s are replaced, %d (mouth) and %d (eyes) are kept, %d is the blood layer" % (
            pr.new_blocks, pr.mouth, pr.eye, pr.blood))
    else:
        log("Donor layout: all %d submeshes %s are replaced by the new body (each new triangle goes to the nearest "
            "donor submesh); head submesh = %d; no separate %s submesh" % (
                len(pr.new_blocks), pr.new_blocks, pr.head_block,
                "/".join(n for n, b in (('eye', pr.eye), ('mouth', pr.mouth), ('blood', pr.blood)) if b is None)))
    log("LIMITS used (= the donor's own maximum%s): %d vertices, %d triangles, %d bytes" % (
        "" if boost == 1.0 else " x%.2f" % boost, V_lim, T_lim, B_lim))

    # ---- read 2K ---------------------------------------------------------------------------------
    base_path = src.base()
    atts = src.attires()
    if not atts:
        raise SystemExit("no attire .mcd found")
    att_path = pick_attire(atts, args.attire)
    log("Attires found: %s" % ", ".join(attire_short(attire_label(a)) for a in atts))
    log("Using attire : %s" % attire_short(attire_label(att_path)))
    log("Vertex normals (they drive the shading / shine in game): %s" % {
        'source': "the 2K model's own normals - highlights sit where they do on the 2K model",
        'donor': "borrowed from the donor where the surfaces are close (the donor's shine pattern; head / neck keep the 2K normals)",
        'blend': "average of the 2K and the donor's normals (head / neck: 2K only)"}.get(args.normals, args.normals))
    hair_rgb, hair_ramp = resolve_hair_colour(args, att_path, log, src)
    only, exclude = split_patterns(getattr(args, 'only', None)), split_patterns(getattr(args, 'exclude', None))
    select = None
    if only or exclude:
        select = lambda name: part_selected(name, only, exclude)           # noqa: E731
        log("Part selection: only=%s exclude=%s" % (only or "(all)", exclude or "(none)"))
    parts = []
    for path in (base_path, att_path):
        log("Reading %s" % os.path.relpath(path, src.root))
        parts += mesh_to_parts(R.Mcd(path), path, log, select=select, variants=bool(getattr(args, 'variants', False) or only))
    if not parts:
        raise SystemExit("no part left after --only / --exclude (see --list for the names)")
    if not any(p.role == 'skin' for p in parts):
        log("WARNING: no body / head skin selected - pose, culling and the face / hand priorities have nothing to work on")
    snap = []                                         # full-resolution copies (before culling) for the normal-map bake
    if args.normal_atlas or float(getattr(args, 'bake_normals', 0) or 0) > 0 or getattr(args, 'hide_under_cloth', False):
        for p in parts:
            if p.role in ('skin', 'cloth') and len(p.T):
                q = Part()
                q.name, q.role, q.tex, q.mcd = p.name, p.role, p.tex, p.mcd
                q.P, q.N, q.UV, q.T, q.W = p.P.copy(), p.N.copy(), p.UV, p.T.copy(), p.W
                snap.append(q)
    skin_parts = [p for p in parts if p.role == 'skin']
    lm_src = None
    if args.pose == 'full' and skin_parts:
        lm_src = pose.landmarks(np.concatenate([p.P for p in skin_parts]), [x for p in skin_parts for x in p.W])
    hide_under = bool(getattr(args, 'hide_under_cloth', False))
    cull_hidden_skin(parts, args.cull if (args.cull > 0 or not hide_under) else 1.0, log, depth=args.cull_depth, rings=args.cull_margin,
                     remove=(args.cull > 0), poke=(hide_under and getattr(args, 'poke_fix', 'scale') == 'remove'))
    for q in snap:                                    # the full-resolution copies know which of their vertices lie under clothing
        for p in parts:
            if p.role == 'skin' and p.name == q.name and getattr(p, 'under', None) is not None and len(p.under) == len(q.P):
                q.under = p.under

    # ---- height / fit -------------------------------------------------------------------------------
    allP = np.concatenate([p.P for p in parts if p.role != 'hair'])
    H = allP[:, 1].max() - allP[:, 1].min()
    sc, off = fit_to_donor(parts, donor, args.fit, log)
    for p in parts + snap:
        p.P = p.P * sc + off
        if getattr(p, 'mouth_pts', None) is not None:
            p.mouth_pts = p.mouth_pts * sc + off
        N = p.N / sc                                   # a uniform scale keeps normals, the bbox fit needs inverse-transpose
        p.N = N / np.maximum(np.linalg.norm(N, axis=1, keepdims=True), 1e-9)
    args.merge_scale = float(np.mean(sc))
    merge_tol = args.merge * args.merge_scale
    log("Vertex merge distance: %g (2K units) = %g (donor units)" % (args.merge, merge_tol))

    # ---- rest pose ------------------------------------------------------------------------------------------
    dP_all = np.array([donor.pos(i) for i in range(donor_verts)])
    if args.pose == 'legs-fingers':
        sk = [p for p in parts if p.role == 'skin']
        if sk:
            plan = pose.LegFingerPose(np.concatenate([p.P for p in sk]), [w for p in sk for w in p.W], dP_all, dW,
                                      legs=True, fingers=True, log=log)
            for line in plan.info:
                log("Pose: " + line)

            def extent():
                ys = [p.P[np.unique(p.T)][:, 1] for p in parts if p.role not in ('hair', 'eye') and len(p.T)]
                return min(float(y.min()) for y in ys), max(float(y.max()) for y in ys)
            for p in parts + snap:
                p.P, p.N = plan.apply(p.P, p.N, p.W)
            # spreading the legs makes the model a little shorter: scale it uniformly (about the floor) so head-to-feet
            # height equals the donor's again and the feet stay on the floor; arms / torso / head are not re-posed
            t1, b1 = extent()
            dlo_y, dhi_y = float(dP_all[:, 1].min()), float(dP_all[:, 1].max())
            k = (dhi_y - dlo_y) / max(b1 - t1, 1e-6)
            zc = float(np.mean(np.concatenate([p.P[np.unique(p.T)][:, 2] for p in parts if len(p.T)])))
            ctr_src, ctr_dst = np.array([0.0, b1, zc]), np.array([0.0, dhi_y, zc])
            for p in parts + snap:
                p.P = (p.P - ctr_src) * k + ctr_dst
                if getattr(p, 'mouth_pts', None) is not None:
                    p.mouth_pts = (p.mouth_pts - ctr_src) * k + ctr_dst
            log("Pose: legs and fingers rotated; model rescaled x%.3f so head-to-feet height equals the donor's and the feet "
                "stay on the floor (torso and head are not re-posed)" % k)
        else:
            log("Pose: no skin found, nothing rotated")
    elif args.pose == 'full' and lm_src is not None:
        dWn = dW
        lm_d = pose.landmarks(dP_all, dWn)
        lm_s = dict((k, (v * sc + off) if v is not None else None) for k, v in lm_src.items())
        keys = [k for k in ('elbowL', 'elbowR', 'wristL', 'wristR', 'kneeL', 'kneeR', 'ankleL', 'ankleR')
                if lm_s.get(k) is not None and lm_d.get(k) is not None]
        before = max(float(np.linalg.norm(lm_s[k] - lm_d[k])) for k in keys)
        log("Pose (full retarget): 2K26 rest pose  -> %s" % pose.angle_report(lm_s))
        log("Pose (full retarget): donor rest pose -> %s" % pose.angle_report(lm_d))
        for p in parts + snap:
            p.P, p.N = pose.retarget(p.P, p.N, p.W, lm_s, lm_d)
        sk = [p for p in parts if p.role == 'skin']
        lm_a = pose.landmarks(np.concatenate([p.P for p in sk]), [x for p in sk for x in p.W])
        after = max(float(np.linalg.norm(lm_a[k] - lm_d[k])) for k in keys)
        log("Pose (full retarget): largest joint distance to the donor skeleton %.2f -> %.2f units" % (before, after))
    else:
        log("Pose: off (2K26 pose kept)")

    # ---- arm / hand length: only the LENGTH of the segments is matched to the donor, no rotation ---------------------
    keep_aw = bool(getattr(args, 'keep_arm_wrist', False))
    if keep_aw:
        log("Arms: --keep-arm-wrist -> the 2K26 arm length and wrist (palm) length are kept (arms are not matched to the donor)")
    if args.arms == 'match' and args.pose != 'full' and not keep_aw:
        sk = [p for p in parts if p.role == 'skin']
        if sk:
            aplan = pose.ArmLength(np.concatenate([p.P for p in sk]), [x for p in sk for x in p.W], dP_all, dW,
                                   height=(args.hand_height == 'donor'), reach=(args.arm_reach == 'donor'), log=log)
            for line in aplan.info:
                log("Arms: " + line)
            if aplan.T:
                for p in parts + snap:
                    p.P, p.N = aplan.apply(p.P, p.N, p.W)
                log("Arms: segment lengths of arms and hands now follow the donor" +
                    (", knuckle / finger height and hand orientation too" if args.hand_height == 'donor' else ""))

    # ---- knuckles and finger lengths from the donor: every finger joint where the donor's joint is --------------------
    if getattr(args, 'finger_length', 'donor') == 'donor' and args.pose == 'legs-fingers':
        sk = [p for p in parts if p.role == 'skin']
        if sk:
            fplan = pose.FingerFit(np.concatenate([p.P for p in sk]), [x for p in sk for x in p.W], dP_all, dW, log=log, keep_palm=keep_aw)
            for line in fplan.info:
                log("Fingers: " + line)
            if fplan.T:
                for p in parts + snap:
                    p.P, p.N = fplan.apply(p.P, p.N, p.W)
                log("Fingers: knuckles and the lengths of the finger segments now follow the donor%s (--finger-length keep switches it off)" % (
                    ", the palm length stays the 2K26's" if keep_aw else ""))

    # ---- eyes: 2K26 eyes (position + texture) -----------------------------------------------------------------
    eye_parts = [p for p in parts if p.role == 'eye']
    parts = [p for p in parts if p.role != 'eye']
    if args.eyes != '2k':
        eye_parts = []

    # ---- hair goes to its own DUMY (PACH 0x2710) ------------------------------------------------------------------
    hair_parts, hair_donor = [], None
    if args.hair == 'separate':
        hp = args.hair_donor
        if not hp:
            for cand in (os.path.join(os.path.dirname(os.path.abspath(args.donor)), 'ch107.pac'), os.path.join(HERE, 'ch107.pac')):
                if os.path.exists(cand):
                    hp = cand
                    break
        if hp and os.path.exists(hp):
            try:
                hair_donor = load_hair_donor(hp, log)
            except HairDonorError as e:
                hair_donor = None
                log("WARNING: %s -> hair/beard stay in the body model (use --hair-donor with a pac that has a hair DUMY, e.g. ch107.pac)" % e)
            if hair_donor is not None:
                hair_parts = [p for p in parts if p.role == 'hair']
                parts = [p for p in parts if p.role != 'hair']
                log("Hair: %d part(s) -> separate hair DUMY (PACH 0x%X) using hair donor %s" % (len(hair_parts), HAIR_ENTRY, os.path.basename(hp)))
        else:
            if args.hair_donor:
                log("WARNING: hair donor %s not found" % args.hair_donor)
            log("Hair: no hair donor pac (use --hair-donor ch107.pac) -> hair/beard stay in the body model")

    strand_mcd = {}                               # strand map name -> its mcd (for the 4K strand textures with alpha)
    for p in list(parts) + list(hair_parts):
        if p.role == 'hair':
            strand_mcd.setdefault(getattr(p, 'strand', None) or 'combinations', p.mcd)

    # ---- hair / beard painted into the head texture instead of 3D cards (--beard-as body / --hair-as body) ----------------
    baked_hair = [p for p in list(parts) + list(hair_parts) if p.role == 'hair' and
                  getattr(args, 'beard_as' if (getattr(p, 'strand', None) or 'combinations') == 'combinations' else 'hair_as', 'hair') == 'body']
    if baked_hair:
        parts = [p for p in parts if p not in baked_hair]
        hair_parts = [p for p in hair_parts if p not in baked_hair]
        log("Hair as body: %s -> %d triangles are NOT ported as geometry; they are painted into the head texture instead (the vertices go "
            "back to the body)" % (", ".join(sorted(set(p.name for p in baked_hair))), sum(len(p.T) for p in baked_hair)))

    # ---- beard cards inside the body mesh (--beard-in-body): head submesh + body atlas, no hair submesh / texture / DUMY --------
    body_beard = []
    if getattr(args, 'beard_in_body', False):
        if getattr(args, 'beard_as', 'hair') == 'body':
            log("Beard cards in the body mesh: ignored - the beard is painted into the head texture (--beard-as body)")
        else:
            body_beard = [p for p in list(parts) + list(hair_parts) if p.role == 'hair' and (getattr(p, 'strand', None) or 'combinations') == 'combinations']
            if not body_beard:
                log("Beard cards in the body mesh: the character has no 'combinations' (beard) material - nothing to do")
            else:
                parts = parts + [p for p in body_beard if p not in parts]
                hair_parts = [p for p in hair_parts if p not in body_beard]
                for p in body_beard:
                    p.in_body = True
                log("Beard cards in the body mesh: %s -> %d card triangles stay 3D cards inside the body model (head submesh, body atlas - "
                    "no own hair submesh / texture)" % (", ".join(sorted(set(p.name for p in body_beard))), sum(len(p.T) for p in body_beard)))
    trans_hair = [p for p in parts if p.role == 'hair' and not getattr(p, 'in_body', False)]

    # ---- beard texture: the 2K strand map as its own texture (not in the atlas) -------------------------------------
    beard_tex = None                              # (PIL image, name) when the beard gets its own texture
    if args.beard_texture in ('colour', 'raw') and hair_donor is None and trans_hair:
        why = None
        if args.hair_mode == 'shell':
            try:
                import skimage  # noqa: F401
            except ImportError:
                why = "scikit-image is not installed (needed for --hair-mode shell)"
        if pr.mode == 'legacy':
            why = "the 6-submesh layout keeps its blood submesh last"
        elif len(donor.blocks) >= donor.mat_count:
            why = "the donor has no spare material for a new submesh"
        elif len(donor.names) < 2 and not donor.names_resizable:
            why = "the donor has a single texture slot"
        sheet_imgs, sheet_names = load_strand_sheet(src, trans_hair, log)
        if len(sheet_imgs) > 1 and args.hair_mode == 'shell':
            # the voxel shell copies UVs from the nearest card and cannot squeeze them into one half: it uses the first map only
            sheet_imgs, sheet_names = sheet_imgs[:1], sheet_names[:1]
            for p in trans_hair:
                p.layer = None
            log("Beard texture: --hair-mode shell uses one strand map only (%s_rai.dds); the default cards mode keeps both" % sheet_names[0])
        if not sheet_imgs and why is None:
            why = "no combinations_rai.dds / hair_rai.dds in the character"
        if why:
            log("Beard texture: %s -> the beard keeps a flat colour patch in the atlas (--beard-texture atlas)" % why)
        else:
            im_ = stack_strand_maps(sheet_imgs)
            beard_al = strand_alpha(im_) if args.beard_alpha else None
            fnames = " + ".join(n + '_rai.dds' for n in sheet_names)
            if args.beard_texture == 'colour':
                im_ = strand_map_to_colour(im_, hair_rgb, hair_ramp)
                log("Beard texture: %s converted to a colour texture (%s) as its own texture '%s', not in the atlas" % (
                    fnames, "hair colours from the 'Hair colour' line above" if hair_ramp else "hair colour %s" % args.hair_color,
                    BEARD_TEX_NAME))
            else:
                log("Beard texture: %s (original 2K data map, unconverted) as its own texture '%s', not in the atlas" % (
                    fnames, BEARD_TEX_NAME))
            beard_tex = (im_, BEARD_TEX_NAME, beard_al)

    # the strand map of the beard cards that sit in the body mesh: a patch of the colour atlas
    beard_atlas_img = beard_atlas_alpha = None
    if body_beard:
        if args.beard_texture == 'atlas':
            log("Beard cards in the body mesh: --beard-texture atlas -> a flat hair colour patch in the atlas")
        else:
            sh_imgs, sh_names = load_strand_sheet(src, body_beard, log)
            if sh_imgs:
                im_ = sh_imgs[0]
                if max(im_.size) > 1024:
                    from PIL import Image as _I
                    k_ = 1024.0 / max(im_.size)
                    im_ = im_.resize((max(1, int(im_.size[0] * k_)), max(1, int(im_.size[1] * k_))), _I.LANCZOS)
                if args.beard_alpha:
                    beard_atlas_alpha = (strand_alpha(im_), float(args.beard_alpha_cut))
                if args.beard_texture == 'colour':
                    im_ = strand_map_to_colour(im_, hair_rgb, hair_ramp)
                beard_atlas_img = im_
                log("Beard cards in the body mesh: %s_rai.dds %s into a patch of the body atlas%s" % (
                    sh_names[0], "converted to a colour texture" if args.beard_texture == 'colour' else "(raw, unconverted) baked",
                    ", gaps between the strands see-through (alpha, --no-beard-alpha for solid)" if beard_atlas_alpha is not None else ", solid (no alpha)"))
            else:
                log("Beard cards in the body mesh: no combinations_rai.dds in the character -> a flat hair colour patch in the atlas")

    # ---- importance (face + body get more triangles, covered skin fewer) -------------------------------------
    itable = importance_table(args.face_bias, args.body_bias)
    for p in parts + hair_parts:
        p.imp = vertex_importance(p.W, getattr(p, 'cov', None), itable)
    log("Triangle priority: face x%.1f, torso x%.1f, arms x%.1f, hands x%.1f, legs x%.1f, covered skin x%.2f" % (
        itable['head'], itable['torso'], itable['arm'], itable['hand'], itable['leg'], COVERED_FACTOR))

    # ---- atlas -------------------------------------------------------------------------------------------
    area = collections.defaultdict(float)
    for p in parts:
        a = np.linalg.norm(np.cross(p.P[p.T[:, 1]] - p.P[p.T[:, 0]], p.P[p.T[:, 2]] - p.P[p.T[:, 0]]), axis=1).sum() / 2
        area[p.tex] += a
    weights = {}
    tot = sum(area.values())
    focus = max(0.0, float(getattr(args, 'atlas_focus', ATLAS_FOCUS) or 0.0))
    for k, a in area.items():
        wgt = max(a / tot, 0.02)
        if k == 'head':
            wgt *= 2.2 * (1.0 + 0.9 * focus)               # --atlas-focus: the face is what people look at: it gets most of the texels
        elif k == 'body':
            wgt *= 1.0 + 0.7 * focus
        elif focus > 0 and k not in ('hair', 'eye'):
            wgt = max(wgt / (1.0 + 0.6 * focus), 0.012)    # trousers, boots, wrist tape, accessories: smaller patches
        if k == 'hair':
            wgt = 0.015
        weights[k] = wgt
    if beard_tex is not None and not body_beard:
        weights.pop('hair', None)
    if body_beard:
        weights['hair'] = max(float(getattr(args, 'beard_atlas_share', 0.06)), 0.02)
    tex_files = {}
    for p in parts:
        if p.tex not in tex_files and p.tex != 'hair':
            tex_files[p.tex] = src.texture(p.mcd, p.tex)
    eye_file = src.texture(eye_parts[0].mcd, 'eye') if eye_parts else None
    if eye_parts and not eye_file:
        log("Eyes: no eye_color texture found -> keeping the donor eyes / no eyes")
        eye_parts = []
    face_on = face_eye = False
    if getattr(args, 'face_tex', False):
        why = None
        n_extra = 1 if beard_tex is not None else 0                     # the separate beard texture also takes a submesh + material + slot
        if pr.mode == 'legacy':
            why = "the 6-submesh layout keeps its blood submesh last"
        elif pr.eye is not None:
            why = "the donor has an eye submesh of its own"
        elif len(donor.blocks) + n_extra >= donor.mat_count:
            why = "the donor has no spare material for another submesh (%d materials, %d submeshes%s)" % (
                donor.mat_count, len(donor.blocks), " + the beard" if n_extra else "")
        elif len(donor.names) < n_extra + 2 and not donor.names_resizable:
            why = "the donor has no spare texture slot"
        if why:
            log("Face texture: %s -> the eyes and lips stay in the colour atlas" % why)
        else:
            face_on = True
    if eye_parts and pr.mode != 'legacy':
        tex_files['eye'] = eye_file
        if face_on and eye_uv_box(eye_parts) is not None:
            face_eye = True                                               # its own texture: no patch in the atlas
        else:
            weights['eye'] = 0.012
    donor_img, donor_tpl, (tex_off, tex_size), tex_raw = donor_atlas_image(pach)
    log("Atlas (%dx%d%s):" % (ATLAS, ATLAS, ", top %d rows from the donor" % pr.keep_rows if pr.keep_rows else ""))
    region = (0, pr.keep_rows, ATLAS, ATLAS - pr.keep_rows)
    if focus > 0 and len(weights) > 1:
        aspects = {}
        for k_, f_ in tex_files.items():
            sz_ = _dds_size(f_) if f_ else None
            if sz_ and k_ in weights:
                aspects[k_] = sz_[0] / float(sz_[1])
        rects = _split_rects_fit(sorted(weights.items()), region, aspects)
    else:
        rects = _split_rects(sorted(weights.items()), region)
    for k_, r_ in sorted(rects.items(), key=lambda kv: (kv[1][1], kv[1][0])):
        log("  atlas %-12s %3dx%-3d at (%3d,%3d)" % (k_, r_[2], r_[3], r_[0], r_[1]))
    images = load_tex_images(tex_files, log)
    if beard_atlas_img is not None:
        images['hair'] = beard_atlas_img
        if beard_atlas_alpha is not None:
            images['hair_alpha'] = beard_atlas_alpha
    plain_imgs = {}                                   # the skin textures as they were BEFORE the under-cloth paint (for the plain 4K export)
    if hide_under:
        pre_paint = dict(images)
        try:
            paint_under_cloth([q for q in snap if q.role == 'skin'], [p for p in parts if p.role == 'cloth'], images, log,
                              grow=int(getattr(args, 'under_grow', 0) or 0))
        except Exception as e:                    # noqa
            log("WARNING: painting the skin under the clothes failed (%s: %s) - the body texture is left as it is" % (type(e).__name__, e))
        plain_imgs = dict((k_, v_) for k_, v_ in pre_paint.items() if images.get(k_) is not v_)
    if baked_hair:
        try:
            head_parts_ = [p for p in parts if p.role == 'skin' and p.tex == 'head']
            if 'head' in images and head_parts_:
                images['head'] = bake_hair_into_head(head_parts_, baked_hair, images['head'], src, hair_rgb, hair_ramp, log,
                                                     opacity=getattr(args, 'hair_body_opacity', 0.92))
            else:
                log("WARNING: hair as body needs the head colour texture and the head mesh - nothing was painted")
        except Exception as e:                    # noqa
            log("WARNING: painting the hair into the head texture failed (%s: %s) - the hair is left out" % (type(e).__name__, e))
    fixed = []
    if eye_parts and pr.mode == 'legacy':
        fixed = [(images['eye'], EYE_RECT)] if 'eye' in images else []
        log("Eyes: 2K26 eye_color texture -> atlas area %s" % (EYE_RECT,))
    shade, _nb = None, {}
    if float(getattr(args, 'bake_normals', 0) or 0) > 0 and snap:
        try:
            bsz = max(ATLAS, int(getattr(args, 'bake_size', 2048) or 2048) // ATLAS * ATLAS)
            nfiles = {}
            for q in snap:
                if q.tex in rects and q.tex not in nfiles:
                    nfiles[q.tex] = src.normal_texture(q.mcd, q.tex)
            log("Baking the normal-map detail into the colour atlas (%dx%d bake, strength %.2f) ..." % (bsz, bsz, float(args.bake_normals)))
            det, smo = bake_object_normals(snap, rects, nfiles, bsz, log, green=args.normal_green, space='obj', return_smooth=True)
            cov = (smo != 128).any(-1)
            shade = normal_shade_map(det, smo, args.bake_normals, cov, getattr(args, 'bake_shadow', 1.0))
            if cov.any():
                dv = (shade[cov] - 1.0) * 100.0
                log("Normal-map detail baked into the colour atlas: brightness change of the covered texels p5 %+.1f %% / p95 %+.1f %% "
                    "(muscle / vein / wrinkle relief as baked light; --bake-normals 0 switches it off, a larger value strengthens it)" % (
                        np.percentile(dv, 5), np.percentile(dv, 95)))
            if args.normal_atlas and args.normal_space == 'obj':
                _nb = dict(size=bsz, img=det)
            del smo, cov
        except Exception as e:                    # noqa
            shade = None
            log("WARNING: baking the normal-map detail into the colour atlas failed (%s: %s) - the atlas is left as the plain colour texture" % (
                type(e).__name__, e))
    atlas = compose_atlas(rects, images, donor_img, hair_rgb, ATLAS, pr.keep_rows, log, fixed, shade=shade,
                          sharpen=float(getattr(args, 'sharpen', SHARPEN) or 0.0))
    del HAIR_RECT[:]
    if 'hair' in rects:
        HAIR_RECT.append(rects['hair'])
    for p in parts:
        p.PUV = atlas_uv(p.UV, rects[p.tex]) if p.tex in rects else np.asarray(p.UV, float)
    face = None                                   # the texture 'face': eye crop + lip crop at the 2K26 resolution (--face-tex)
    if face_on:
        try:
            ebox = eye_uv_box(eye_parts) if face_eye else None
            mbox = mouth_uv_box(parts, sc, log) if ('head' in rects and images.get('head') is not None) else None
            plan = plan_face_texture(images.get('eye') if face_eye else None, ebox, images.get('head'), mbox, int(args.face_tex_size))
            if plan:
                face = dict(plan=plan, head=rects.get('head'),
                            rgba=build_face_texture(plan, images.get('eye'), images.get('head'), shade, rects.get('head'), log))
                log("Face texture '%s' (%dx%d CMPR, %d KB): %s%s%s" % (
                    FACE_TEX_NAME, plan['fw'], plan['fh'], plan['fw'] * plan['fh'] // 2048,
                    ("eye crop %dx%d texels" % plan['eye']['dst'][2:]) if plan.get('eye') else "no eye crop",
                    (", lip crop %dx%d texels" % plan['mouth']['dst'][2:]) if plan.get('mouth') else ", no lip crop (no 2K26 mouth parts found)",
                    "" if plan['scale'] >= 0.95 else " (scaled to %.0f %% to fit - --face-tex-size %d gives more room)" % (100 * plan['scale'], 2 * plan['fw'])))
            else:
                log("Face texture: no eye / lip crop could be made -> nothing to put in it")
        except Exception as e:                    # noqa
            log("WARNING: the face texture failed (%s: %s) - the eyes and lips stay in the colour atlas where possible" % (type(e).__name__, e))
            face = None
    if face_eye and not (face and face['plan'].get('eye')):
        log("WARNING: the 2K26 eyes could not be given their own texture and have no patch in the atlas -> no 3D eyes")
        eye_parts = []
    eye_meshes = None
    if eye_parts:
        eye_rect = EYE_RECT if pr.mode == 'legacy' else (face_eye_rect(face['plan']['eye']) if face_eye else rects['eye'])
        if pr.eye is not None:
            per_t, per_v = donor_tris[pr.eye] // 2, pr.bverts[pr.eye] // 2
        else:
            per_t, per_v = EYE_TRIS, EYE_VERTS
        eye_meshes = build_eyes(eye_parts, eye_rect, per_t, per_v, merge_tol, log)
        if pr.mode != 'legacy' and 'eye' in images:
            pass

    # ---- which donor submesh gets which triangle ---------------------------------------------------------------------
    dtree = cKDTree(dP_all)
    dN = np.array([donor.normal_out(i) for i in range(donor_verts)])
    blocks = collections.defaultdict(list)       # block -> list of (part, tri_idx array)
    if pr.mode == 'spatial':
        dc, db = [], []
        for b in pr.new_blocks:
            for t in donor.triangles(b):
                if max(c[0] for c in t) >= donor_verts:
                    continue
                dc.append(np.mean([donor.pos(c[0]) for c in t], 0))
                db.append(b)
        ctree, dbk = cKDTree(np.array(dc)), np.array(db)
    for p in parts:
        if pr.mode == 'spatial':
            bk = spatial_blocks(p, ctree, dbk, nblocks)
        else:
            y = p.P[p.T][:, :, 1].mean(1)
            yk = (y - off[1]) / sc[1]                 # back to 2K cm
            bk = block_of(p, yk, H)
        for b in pr.new_blocks:
            ix = np.nonzero(bk == b)[0]
            if len(ix):
                blocks[b].append((p, ix))
    total_in = sum(len(ix) for b in blocks for _, ix in blocks[b])
    log("Triangles before decimation: %d" % total_in)

    # ---- weld ONCE for the whole body -----------------------------------------------------------------------------
    # The donor submesh of every triangle is decided first and travels through the decimation as a tag.  The body is
    # welded and decimated as ONE mesh, so the borders between submeshes stay identical on both sides.  (Decimating each
    # submesh on its own simplified the two sides of a border differently and opened cracks along it - visible in the
    # face of donors whose submesh borders cross it.)  Face / torso / hands still get more triangles through the importance.
    items, tags = [], []
    for b in pr.new_blocks:
        for p, ix in blocks.get(b, []):
            if p.role == 'hair':
                continue                                  # beard / hair cards get their own budget (below)
            items.append((p, ix))
            tags.append(np.full(len(ix), b, int))
    if not items:
        raise SystemExit("the character has no body geometry")
    seam_tol = float(getattr(args, 'seam_weld', SEAM_WELD) or 0.0) * args.merge_scale
    P, N, W, imp, tris, cuvs, tg = weld_collect2(items, merge_tol, tags=tags, seam_tol=seam_tol)
    if seam_tol > merge_tol and _SEAM_STATS[0]:
        log("Seam weld: borders closer than %g (2K units) stitched together -> %d vertices merged where parts meet (--seam-weld 0 = off)" % (
            float(args.seam_weld), _SEAM_STATS[0] - _SEAM_STATS[1]))
    tris, cuvs, ncomp, ndrop, keep = qem.prune_small_components(P, tris, cuvs, return_index=True)
    tg = [tg[i] for i in keep]
    log("Body: %d vertices after merge, %d islands, %d tiny ones dropped, %d triangles (%s)" % (
        len(P), ncomp, ndrop, len(tris), ", ".join("submesh %d: %d" % (b, tg.count(b)) for b in pr.new_blocks)))

    # ---- what is reserved for kept / rebuilt donor parts ---------------------------------------------------------
    eye_t = sum(len(m[3]) for m in eye_meshes) if eye_meshes else 0
    eye_v = sum(len(set(v for t in m[3] for v in t)) for m in eye_meshes) if eye_meshes else 0
    if pr.mode == 'legacy':
        kept_t = donor_tris[pr.mouth] + donor_tris[pr.eye] + (donor_tris[pr.blood] if args.blood else 0)
        kept_v = pr.bverts[pr.mouth] + pr.bverts[pr.eye] + int(0.6 * pr.bverts[pr.blood])
    else:
        kept_t = eye_t + (donor_tris[pr.mouth] if pr.mouth is not None else 0) + (donor_tris[pr.eye] if (pr.eye is not None and not eye_meshes) else 0)
        kept_v = eye_v + (pr.bverts[pr.mouth] if pr.mouth is not None else 0) + (pr.bverts[pr.eye] if (pr.eye is not None and not eye_meshes) else 0)
    T_avail = (T_lim - kept_t) * args.tri_scale
    V_avail = (V_lim - kept_v) * args.tri_scale
    log("Budget for the new body: %d triangles, %d vertices (limits minus %d triangles / %d vertices of eyes / mouth / blood)" % (
        T_avail, V_avail, kept_t, kept_v))

    # beard / hair cards that stay in the body DUMY: a budget of their own (--hair-share of the triangle budget), added to
    # the body mesh as protected geometry (their vertices are never removed by the body decimation)
    locked = set()
    locked_trans = set()                          # the cards that get the own hair submesh + texture 'trans'
    merged_hair = [p for p in parts if p.role == 'hair' and not getattr(p, 'in_body', False)]
    all_hair = merged_hair + [p for p in parts if p.role == 'hair' and getattr(p, 'in_body', False)]
    if all_hair:
        hb_t = min(int(args.hair_share * T_avail), int(args.hair_max_tris))
        if args.hair_mode == 'cards':
            # the cards keep their own vertices (about one per triangle), so the vertex budget follows the triangle budget
            hb_v = int(args.hair_max_verts) if args.hair_max_verts else int(1.15 * hb_t)
        else:
            cap = 300 if args.hair_max_verts is None else int(args.hair_max_verts)
            hb_v = min(int(0.7 * hb_t), cap) if cap else int(0.7 * hb_t)
        hpts = []
        for p in parts:
            if p.role == 'skin' and len(p.P):
                r = np.asarray(vertex_regions(p.W))
                if (r == 'head').any():
                    hpts.append(p.P[r == 'head'])
        hc = np.concatenate(hpts).mean(0) if hpts else None
        ref = sum(_signed_volume(p.P, p.T) for p in parts if p.role != 'hair' and len(p.T))
        mp = [p.mouth_pts for p in parts if getattr(p, 'mouth_pts', None) is not None]
        n_all = float(max(1, sum(len(p.T) for p in all_hair)))
        for grp, in_body in ((merged_hair, False), (body_beard, True)):
            if not grp:
                continue
            f_ = sum(len(p.T) for p in grp) / n_all if len(all_hair) > len(grp) else 1.0      # split the hair budget by card count
            g_t = max(1, int(hb_t * f_))
            g_v = max(1, int(hb_v * f_))
            if in_body:
                # the beard in the body mesh: original cards, only decimated; UVs placed inside the atlas patch of its strand map
                g_v = int(args.hair_max_verts) if args.hair_max_verts else int(1.15 * g_t)
                hh = prepare_merged_hair(grp, g_t, g_v, merge_tol, log, mode='cards', rect=rects['hair'])
            else:
                hh = prepare_merged_hair(grp, g_t, g_v, merge_tol, log, head_center=hc, ref_sign=(1.0 if ref >= 0 else -1.0),
                                         mouth_pts=(np.concatenate(mp) if (mp and args.beard_open_mouth) else None),
                                         uv_patch=(BEARD_UV_PATCH if beard_tex is not None else None),
                                         uv_mode=args.beard_uv, mode=args.hair_mode)
            if hh is not None:
                hP, hN, hW, hI, hT, hC = hh
                off_v = len(P)
                P = list(P) + hP
                N = list(N) + hN
                W = list(W) + hW
                imp = np.concatenate([np.asarray(imp, float), hI])
                tris = list(tris) + [tuple(v + off_v for v in t) for t in hT]
                cuvs = list(cuvs) + hC
                tg = list(tg) + [pr.head_block] * len(hT)
                locked |= set(range(off_v, off_v + len(hP)))
                if not in_body:
                    locked_trans |= set(range(off_v, off_v + len(hP)))
    orig = (P, N, W, imp, tris, cuvs, tg)
    vreg = vertex_regions(W)                      # per vertex region, used for the normals below
    poke_mode = getattr(args, 'poke_fix', 'scale') if hide_under else 'off'
    poke_post = None                              # --hide-under-cloth: skin of the reduced mesh that is near / crossing the cloth is scaled down
    if poke_mode in ('scale', 'remove') and 'body' in rects:
        opaque_ = set(p.tex for p in parts if p.role == 'cloth' and not getattr(p, 'alpha', False))
        alpha_ = set(p.tex for p in parts if p.role == 'cloth' and getattr(p, 'alpha', False))
        cover_ = (opaque_ - alpha_) & set(rects)
        if cover_:
            poke_post = (cover_, float(sc[1]), poke_mode)
    groups = {}
    if float(args.face_share or 0) > 0:
        groups['face'] = (('head', 'neck'), float(args.face_share))
    if float(args.hand_share or 0) > 0:
        groups['hands'] = (('hand',), float(args.hand_share))
    if groups:
        orig = orig[:3] + (calibrate_shares(orig, locked, vreg, int(T_avail), int(V_avail), groups, float(args.boundary_weight), log),) + orig[4:]

    cur = {}                                     # progressive decimation state: (triangles, corner uvs, submesh tags)

    def run(T_t, V_t, restart):
        """decimate the whole body to <= T_t triangles / <= V_t vertices, then split it into the donor submeshes"""
        if restart:
            cur.clear()
        P, N, W, imp = orig[0], orig[1], orig[2], orig[3]
        if 'body' not in cur:
            cur['body'] = (orig[4], orig[5], orig[6])
        tris_, cuv_, tg_ = cur['body']
        log("Body: %d triangles -> <= %d triangles / <= %d vertices" % (len(tris_), T_t, V_t))
        nt, nc, idx = qem.decimate(P, tris_, cuv_, T_t, weights=W, log=log, target_verts=V_t, importance=imp, return_index=True,
                                   bound_w=float(args.boundary_weight), locked=locked)
        nt, nc, tg2 = qem.enforce_budget(P, nt, nc, T_t, V_t, tags=[tg_[i] for i in idx])
        if poke_post is not None and len(nt):
            res_ = poke_through_fix(P, N, nt, nc, rects, poke_post[0], vreg, poke_post[1], mode=poke_post[2])
            if res_ is not None:
                kp_, mv_, npk_ = res_
                if mv_:
                    for v_, dl_ in mv_.items():
                        P[v_] = np.asarray(P[v_], float) + dl_
                    ml_ = np.array([np.linalg.norm(x) for x in mv_.values()]) / poke_post[1]
                    log("Skin near / crossing the cloth: %d skin vertices of the reduced mesh scaled down (moved inward %.2f cm on average, "
                        "up to %.2f cm, to %.2f cm under the cloth surface)" % (len(mv_), ml_.mean(), ml_.max(), POKE_GAP))
                if not kp_.all():
                    log("Skin poking through the clothes: %d skin vertices on top of the cloth in the reduced mesh -> %d skin triangles removed" % (
                        npk_, int((~kp_).sum())))
                    nt = [t for t, f_ in zip(nt, kp_) if f_]
                    nc = [c for c, f_ in zip(nc, kp_) if f_]
                    tg2 = [g_ for g_, f_ in zip(tg2, kp_) if f_]
        cur['body'] = (nt, nc, tg2)
        cnt = collections.Counter()
        for t in nt:
            if t[0] in locked:
                cnt['beard/hair'] += 1
            else:
                cnt[collections.Counter(vreg[v] for v in t).most_common(1)[0][0]] += 1
        log("Triangles by region: " + ", ".join("%s %d" % kv for kv in sorted(cnt.items(), key=lambda kv: -kv[1])))
        lab = np.array(tg2, int)
        isb = np.array([t[0] in locked_trans for t in nt], bool) if (beard_tex is not None and len(nt)) else np.zeros(len(nt), bool)
        if pr.mode == 'spatial' and len(lab):
            body_i = np.nonzero(~isb)[0]
            if len(body_i):
                lab[body_i] = smooth_blocks(np.array(nt)[body_i], lab[body_i], nblocks, rounds=1)    # clean submesh borders
        out = {}
        for b in pr.new_blocks:
            sel = np.nonzero((lab == b) & ~isb)[0]
            if len(sel):
                out[b] = (P, N, W, [nt[i] for i in sel], [nc[i] for i in sel])
        if isb.any():                                  # the beard: its own submesh + texture
            sel = np.nonzero(isb)[0]
            out['beard'] = (P, N, W, [nt[i] for i in sel], [nc[i] for i in sel])
        return out

    vt_cache = {}

    def vt_raw(obj, key):
        if key not in vt_cache:
            vt_cache[key] = len(obj.VT)
            obj.VT.append(key)
        return vt_cache[key]

    fm = None                                     # lips: head triangles whose UVs lie inside the lip crop use the texture 'face'
    if face and face['plan'].get('mouth') and face['head'] is not None:
        pm_ = face['plan']['mouth']
        fm = dict(head=face['head'], box=pm_['box'], cuv=pm_['cuv'], dst=pm_['dst'], fw=face['plan']['fw'], fh=face['plan']['fh'])

    def mouth_uv(c):
        """UVs (in the face texture) of a triangle with atlas-pixel corners c when it lies inside the lip crop, else None"""
        hx, hy, hw, hh = fm['head']
        u0, v0, u1, v1 = fm['box']
        eps = 2e-4
        fuv = []
        for k in range(3):
            fu = (c[k][0] - hx - 0.5) / (hw - 1.0)
            fv = (c[k][1] - hy - 0.5) / (hh - 1.0)
            if fu < u0 - eps or fu > u1 + eps or fv < v0 - eps or fv > v1 + eps:
                return None
            fuv.append((fu, fv))
        cu0, cv0, cu1, cv1 = fm['cuv']
        x, y, w, h = fm['dst']
        return [(round((x + (fu - cu0) / (cu1 - cu0) * w) / float(fm['fw']), 5),
                 round(1.0 - (y + (fv - cv0) / (cv1 - cv0) * h) / float(fm['fh']), 5)) for fu, fv in fuv]

    def assemble(dec):
        obj = T.ObjModel()
        obj.skin = {}
        obj.meta = {}
        gstats = {}
        face_tl = []
        for b in list(pr.new_blocks) + ['beard']:
            if b not in dec:
                continue
            P, N, W, nt, nc = dec[b]
            used = sorted(set(v for t in nt for v in t))
            loc = {}
            for v in used:
                loc[v] = len(obj.V)
                obj.V.append(tuple(P[v]))
                n = np.array(N[v], float)
                # the donor's normals are only borrowed outside the head: the face is not the donor's face, and its own
                # 2K normals keep the shading of the nose, cheeks and lips right
                if args.normals in ('donor', 'blend') and vreg[v] not in ('head', 'neck'):
                    dd, jj = dtree.query(P[v])
                    if dd < args.normal_dist and float(np.dot(dN[jj], n)) > 0.3:
                        n = dN[jj] if args.normals == 'donor' else n / (np.linalg.norm(n) or 1.0) + dN[jj] / (np.linalg.norm(dN[jj]) or 1.0)
                nn = np.linalg.norm(n) or 1.0
                obj.VN.append(tuple(n / nn))
                obj.skin[loc[v]] = W[v]
            hx, hy, hw, hh = HAIR_RECT[0] if HAIR_RECT else (0, 0, 0, 0)
            hair_tl, plain_tl = [], []
            n_face = 0
            for t, c in zip(nt, nc):
                if fm is not None and b != 'beard':
                    fuv = mouth_uv(c)
                    if fuv is not None:
                        face_tl.append(tuple((loc[t[k]], vt_raw(obj, fuv[k]), loc[t[k]]) for k in range(3)))
                        n_face += 1
                        continue
                tt = tuple((loc[t[k]], vt_raw(obj, (round(c[k][0] / ATLAS, 5), round(1.0 - c[k][1] / ATLAS, 5))), loc[t[k]]) for k in range(3))
                # a triangle belongs to the hair material when its UVs lie in the hair patch of the atlas
                cx = sum(x[0] for x in c) / 3.0
                cy = sum(x[1] for x in c) / 3.0
                (hair_tl if (b != 'beard' and hw and hx <= cx <= hx + hw and hy <= cy <= hy + hh) else plain_tl).append(tt)
            obj.groups['beard' if b == 'beard' else 'block%d' % b] = plain_tl
            if hair_tl:
                obj.groups['hair@%d' % b] = hair_tl
            gstats[b] = len(plain_tl) + len(hair_tl) + n_face
        if face_tl:
            obj.groups['face'] = face_tl
        return obj, gstats

    def add_donor_block(obj, bk, gname):
        """copy a donor submesh verbatim (positions, normals, UVs, weights)."""
        loc = {}
        tl = []
        for tri in donor.triangles(bk):
            if max(c[0] for c in tri) >= donor_verts:
                continue
            corners = []
            for (vi, ci, ui) in tri:
                if vi not in loc:
                    loc[vi] = len(obj.V)
                    obj.V.append(tuple(donor.pos(vi)))
                    obj.VN.append(tuple(donor.normal_out(vi)))
                    obj.skin[loc[vi]] = dW[vi]
                u, v = donor.uvs[ui]
                key = (round(u / 1024.0, 6), round(1.0 - v / 1024.0, 6))
                corners.append((loc[vi], vt_raw(obj, key), loc[vi]))
            tl.append(tuple(corners))
        obj.groups[gname] = tl
        return len(tl)

    def add_eyes(obj, meshes, gname, tsz=(ATLAS, ATLAS)):
        tl = []
        for P, N, W, nt, nc in meshes:
            used = sorted(set(v for t in nt for v in t))
            loc = {}
            for v in used:
                loc[v] = len(obj.V)
                obj.V.append(tuple(P[v]))
                n = np.array(N[v], float)
                obj.VN.append(tuple(n / (np.linalg.norm(n) or 1.0)))
                obj.skin[loc[v]] = W[v]
            for t, c in zip(nt, nc):
                cs = []
                for k in range(3):
                    key = (round(c[k][0] / float(tsz[0]), 6), round(1.0 - c[k][1] / float(tsz[1]), 6))
                    cs.append((loc[t[k]], vt_raw(obj, key), loc[t[k]]))
                tl.append(tuple(cs))
        obj.groups.setdefault(gname, [])
        obj.groups[gname] = obj.groups[gname] + tl
        return len(tl)

    # blood: uv = affine fit of the donor's blood vertices (only donors with a blood submesh)
    coef = bl_lo = bl_hi = None
    if pr.blood is not None:
        bl_verts = sorted({c[0] for t in donor.triangles(pr.blood) for c in t if c[0] < donor_verts})
        bl_uv = {}
        for t in donor.triangles(pr.blood):
            for (vi, ci, ui) in t:
                if vi < donor_verts:
                    bl_uv[vi] = donor.uvs[ui]
        A = np.array([[*donor.pos(v)[:2], 1.0] for v in bl_verts])
        Bu = np.array([bl_uv[v] for v in bl_verts], float)
        coef, *_ = np.linalg.lstsq(A, Bu, rcond=None)
        bl_pos = np.array([donor.pos(v) for v in bl_verts])
        bl_lo, bl_hi = bl_pos.min(0) - 0.8, bl_pos.max(0) + 0.8

    # ---- fit loop: largest budget that still meets EVERY donor limit ------------------------------------------------
    scale_try, last_scale = 1.0, None
    best, lo_ok, hi_bad, fb = None, None, None, None
    chk = dumy_out = obj = None
    for attempt in range(9):
        restart = last_scale is None or scale_try > last_scale + 1e-9
        last_scale = scale_try
        dec = run(int(T_avail * scale_try), int(V_avail * scale_try), restart)
        vt_cache.clear()
        obj, gstats = assemble(dec)
        n_new_tris = sum(gstats.values())
        n_keep = 0
        v_before = len(obj.V)
        if pr.mode == 'legacy':
            for bk, gname in ((pr.mouth, 'submesh_%d' % pr.mouth), (pr.eye, 'submesh_%d' % pr.eye)):
                if bk == pr.eye and eye_meshes:
                    n_keep += add_eyes(obj, eye_meshes, gname)
                else:
                    n_keep += add_donor_block(obj, bk, gname)
        else:
            if pr.mouth is not None:
                n_keep += add_donor_block(obj, pr.mouth, 'submesh_%d' % pr.mouth)
            if eye_meshes and face_eye:
                n_keep += add_eyes(obj, eye_meshes, 'face', (face['plan']['fw'], face['plan']['fh']))
            elif eye_meshes:
                n_keep += add_eyes(obj, eye_meshes, 'submesh_%d' % pr.eye if pr.eye is not None else 'block%d' % pr.head_block)
            elif pr.eye is not None:
                n_keep += add_donor_block(obj, pr.eye, 'submesh_%d' % pr.eye)
        n_keep_v = len(obj.V) - v_before
        v_before = len(obj.V)
        blood_tris = 0
        if args.blood and pr.blood is not None:
            blood_tris = add_blood(obj, dec, bl_lo, bl_hi, coef, donor_tris[pr.blood], vt_raw, group='block%d' % pr.head_block)
        blood_v = len(obj.V) - v_before
        nverts_est = len(obj.V)
        total_tris = n_new_tris + n_keep + blood_tris
        log("Attempt %d (budget x%.3f): triangles new=%d + kept eyes/mouth=%d + blood=%d = %d (limit %d); vertices=%d (limit %d)" % (
            attempt + 1, scale_try, n_new_tris, n_keep, blood_tris, total_tris, T_lim, nverts_est, V_lim))
        # triangles are exact before the import; the vertex count is only an estimate (vertices on submesh borders are
        # counted twice and merged by the importer), so only the real result decides about vertices
        over = max((nverts_est - 1.5 * V_lim) / float(max(nverts_est, 1)),
                   (total_tris - T_lim) / float(max(n_new_tris, 1)))
        ok = over <= 0
        res = None
        if ok:
            mapping = collections.OrderedDict()
            has_beard_, has_face_ = 'beard' in obj.groups, bool(obj.groups.get('face'))
            beard_blk_ = len(donor.blocks)                                             # NEW submeshes with their own texture:
            face_blk_ = len(donor.blocks) + (1 if has_beard_ else 0)                   # the beard first, then the face
            for g in obj.groups:
                if g.startswith('block'):
                    mapping[g] = dict(block=int(g[5:]), bone=None, color=None)
                elif g == 'beard':
                    mapping[g] = dict(block=beard_blk_, bone=None, color=None)       # NEW submesh with its own texture
                elif g == 'face':
                    mapping[g] = dict(block=face_blk_, bone=None, color=None)        # NEW submesh: eyes + lips, texture 'face'
                elif g.startswith('hair@'):
                    mapping[g] = dict(block=int(g.split('@')[1]), bone=None, color=None)     # hair material: same draw submesh
                elif g.startswith('submesh_'):
                    mapping[g] = dict(block=int(g.split('_')[1]), bone=None, color=None)
                elif g == 'blood':
                    mapping[g] = dict(block=pr.blood, bone=None, color=None)
            xf = T.Xform(1.0, flip=(False, False, False))
            pkw = {}
            if has_beard_ or has_face_:
                nm_ = [list(x) for x in donor.names]
                slot_ = min(1, len(nm_))
                xs_, mc_ = {}, {}
                for has_, blk_, tname_ in ((has_beard_, beard_blk_, BEARD_TEX_NAME), (has_face_, face_blk_, FACE_TEX_NAME)):
                    if not has_:
                        continue
                    ent_ = [tname_, 'tga', (nm_[slot_][2] if slot_ < len(nm_) else b'\0' * 6)]
                    if slot_ < len(nm_):
                        nm_[slot_:slot_ + 1] = [ent_]
                    else:
                        nm_.append(ent_)
                    xs_[blk_], mc_[blk_] = slot_, pr.head_block
                    slot_ += 1
                pkw = dict(names=nm_, extra_blocks=int(has_beard_) + int(has_face_), extra_slots=xs_, mat_clone=mc_)
            dumy_out, stats = T.port_model(donor, obj, mapping, xf, **dict(dict(names=None), **pkw), weight_mode='file', restrict=True,
                                           colour_mode='transfer', weld_angle='auto' if args.weld == 'auto' else float(args.weld),
                                           vert_budget=V_lim, log=lambda s: log("  [dumy] " + s))
            chk = T.Dumy(dumy_out)
            ntri_c = sum(len(list(chk.triangles(b))) for b in range(len(chk.blocks)))
            fin_v, fin_t, fin_b = chk.real_vcount, ntri_c, len(dumy_out)
            log("  result: %d vertices (limit %d), %d triangles (limit %d), %d bytes (limit %d)" % (fin_v, V_lim, fin_t, T_lim, fin_b, B_lim))
            if fin_v > V_lim or fin_t > T_lim or fin_b > B_lim:
                ok = False
                ovr = dict(dumy=dumy_out, chk=chk, obj=obj, v=fin_v, t=fin_t, b=fin_b, scale=scale_try,
                           fill=max(fin_v / float(V_lim), fin_t / float(T_lim), fin_b / float(B_lim)))
                if fb is None or ovr['fill'] < fb['fill']:
                    fb = ovr
                over = max((fin_v - V_lim) / float(V_lim), (fin_t - T_lim) / float(T_lim), (fin_b - B_lim) / float(B_lim), 0.0) + 0.002
            else:
                fill = max(fin_v / float(V_lim), fin_t / float(T_lim), fin_b / float(B_lim))
                res = dict(dumy=dumy_out, chk=chk, obj=obj, fill=fill, scale=scale_try, v=fin_v, t=fin_t, b=fin_b)
        if ok:
            lo_ok = scale_try
            if best is None or res['fill'] > best['fill']:
                best = res
            if res['fill'] >= 0.985:
                break
            if hi_bad is None:
                scale_try *= min(1.12, 0.995 / max(res['fill'], 0.5))
            else:
                scale_try = (lo_ok + hi_bad) / 2.0
                if hi_bad - lo_ok < 0.004:
                    break
        else:
            hi_bad = scale_try
            if lo_ok is None:
                scale_try *= max(0.80, 1.0 - max(over, 0.0) - 0.004)
            else:
                scale_try = (lo_ok + hi_bad) / 2.0
                if hi_bad - lo_ok < 0.004:
                    break
    if best is None:
        if fb is None:
            raise SystemExit("model does not fit the donor limits (see log) - lower --tri-scale")
        log("WARNING: could not meet every donor limit (closest result is used, %.1f %% of the limit) - lower --tri-scale" % (100.0 * fb['fill']))
        best = fb
    dumy_out, chk, obj = best['dumy'], best['chk'], best['obj']

    # ---- sanity: re-read ------------------------------------------------------------------------------------
    ntri = best['t']
    log("Result DUMY: %d vertices (%.1f %% of the donor limit %d), %d triangles (%.1f %% of %d), %d bytes (%.1f %% of %d)" % (
        chk.real_vcount, 100.0 * best['v'] / V_lim, V_lim, ntri, 100.0 * ntri / T_lim, T_lim, len(dumy_out), 100.0 * best['b'] / B_lim, B_lim))
    per = [(b, len(list(chk.triangles(b)))) for b in range(len(chk.blocks))]
    log("Triangles per submesh: %s" % ", ".join("%d: %d (donor %d)" % (b, n, donor_tris[b] if b < len(donor_tris) else 0) for b, n in per))

    # ---- hair DUMY + texture ----------------------------------------------------------------------------------
    hair_dumy = hair_tpl = hair_chk = None
    if hair_parts and hair_donor is not None:
        sheet_imgs, sheet_names = (load_strand_sheet(src, hair_parts, log) if args.beard_texture in ('colour', 'raw') else ([], []))
        hair_dumy, hair_chk, hair_ntri = build_hair(hair_parts, hair_donor['dumy'], hair_rgb, args, log, names=hair_donor['names'])
        hidx = hpal = None
        hrai = " + ".join(n + '_rai.dds' for n in sheet_names) if sheet_imgs else None
        if hrai is not None:
            from PIL import Image as _I
            hh_, hw_ = struct.unpack_from('>HH', hair_donor['hdr'], 20)
            hidx, hpal, _prev = rai_hair_texture(stack_strand_maps(sheet_imgs), hair_rgb, hair_ramp, (hh_, hw_),
                                                 gap_alpha=(args.hair_gap_alpha if args.beard_alpha else 1.0), convert=(args.beard_texture == 'colour'))
            log("Hair texture '%s' (%dx%d C8): the 2K strand map %s (%s), strands opaque, gaps %.0f %% opaque - the cards keep their "
                "default 2K UVs" % (hair_donor['texname'], hw_, hh_, hrai,
                                    "raw, unconverted" if args.beard_texture == 'raw' else (
                                        "converted with the hair colours chosen above" if hair_ramp else
                                        "converted with hair colour %s" % args.hair_color),
                                    100 * args.hair_gap_alpha))
        else:
            log("Hair texture: no strand map (*_rai.dds) used (--beard-texture %s / not in the character) -> GENERATED placeholder "
                "strands in %s" % (args.beard_texture, args.hair_color))
            hidx, hpal = make_hair_strands(hair_rgb)
        hair_tpl = gxtex.encode_c8_tpl_indexed(hidx, hpal, hair_donor['hdr'])

    # ---- write the pac ----------------------------------------------------------------------------------------
    new_tpl = donor_tpl[:64] + gxtex.encode_cmpr(atlas)
    assert len(new_tpl) == tex_size, (len(new_tpl), tex_size)
    thead, tents = texarchive.read(tex_raw)
    for e in tents:
        if e[0] == DONOR_COLOR_ENTRY:
            e[2] = new_tpl
    if hair_tpl is not None:
        for e in tents:
            if e[0] == hair_donor['texname']:
                e[2] = hair_tpl
                break
        else:
            tents.append([hair_donor['texname'], b'tpl\0', hair_tpl])
    beard_rgba = None
    if beard_tex is not None and 'beard' in obj.groups:
        from PIL import Image as _I
        if beard_tex[2] is not None:
            beard_rgba = alpha_resize(beard_tex[0], beard_tex[2], (ATLAS, ATLAS), cut=float(args.beard_alpha_cut))
        else:
            im_ = beard_tex[0].resize((ATLAS, ATLAS), _I.LANCZOS)
            beard_rgba = np.concatenate([np.asarray(im_, np.uint8), np.full((ATLAS, ATLAS, 1), 255, np.uint8)], 2)
        b_tpl = donor_tpl[:64] + gxtex.encode_cmpr(beard_rgba)
        assert len(b_tpl) == tex_size, (len(b_tpl), tex_size)
        for e in tents:
            if e[0] == BEARD_TEX_NAME:
                e[2] = b_tpl
                break
        else:
            tents.append([BEARD_TEX_NAME, b'tpl\0', b_tpl])
        log("Beard: submesh %d, texture '%s' (%dx%d CMPR, the 2K strand map, %s), %d triangles" % (
            len(donor.blocks), BEARD_TEX_NAME, ATLAS, ATLAS,
            "gaps between the strands see-through (1-bit alpha, %.0f %% of the texels opaque)" % (100.0 * float((beard_rgba[..., 3] > 0).mean()))
            if beard_tex[2] is not None else "solid, no alpha", len(obj.groups['beard'])))
    face_rgba = None
    face_blk = len(donor.blocks) + (1 if 'beard' in obj.groups else 0)
    if face is not None and obj.groups.get('face'):
        face_rgba = face['rgba']
        f_tpl = face_tpl(donor_tpl, face_rgba)
        for e in tents:
            if e[0] == FACE_TEX_NAME:
                e[2] = f_tpl
                break
        else:
            tents.append([FACE_TEX_NAME, b'tpl\0', f_tpl])
        log("Face: submesh %d, texture '%s' (%dx%d CMPR, %d KB), %d triangles (the eyes and the lips)" % (
            face_blk, FACE_TEX_NAME, face_rgba.shape[1], face_rgba.shape[0], len(f_tpl) // 1024, len(obj.groups['face'])))
    pach.set(2, pacio.bpe_wrap(dumy_out, 256))
    pach.set(9, pacio.bpe_wrap(texarchive.build(thead, tents), 256))
    if hair_dumy is not None:
        pach.add(HAIR_ENTRY, pacio.bpe_wrap(hair_dumy, 256))
        if args.hair_springs:
            for fn in HAIR_SPRING_ENTRIES:
                if hair_donor['pach'].has(fn):
                    pach.add(fn, hair_donor['pach'].get(fn))
    out_pac = epk.build(pach.build())
    out = args.out or os.path.splitext(os.path.basename(args.donor))[0] + '_2k26port.pac'
    if os.path.dirname(out):
        os.makedirs(os.path.dirname(out), exist_ok=True)
    open(out, 'wb').write(out_pac)
    log("Wrote %s (%d bytes)" % (out, len(out_pac)))
    from PIL import Image
    stem = os.path.splitext(out)[0]
    Image.fromarray(atlas).save(stem + '_atlas.png')
    if args.atlas_4k:
        size = int(args.atlas_size)
        try:
            log("Building the %dx%d atlas export from the full-resolution 2K26 textures (same layout / UVs as the PAC atlas) ..." % (size, size))
            big = compose_atlas(rects, images, donor_img, hair_rgb, size, pr.keep_rows, log,
                                [(images['eye'], EYE_RECT)] if (eye_parts and pr.mode == 'legacy' and 'eye' in images) else [], shade=shade)
            bigname = stem + ('_atlas_4k.png' if size == 4096 else '_atlas_%d.png' % size)
            if int(big[..., 3].min()) < 255:                      # the beard patch has see-through gaps
                Image.fromarray(big, 'RGBA').save(bigname, optimize=False)
            else:
                Image.fromarray(big[..., :3]).save(bigname, optimize=False)
            log("Wrote %s%s" % (bigname, " (skin under the clothes painted in the cloth colour)" if plain_imgs else ""))
            if plain_imgs and getattr(args, 'atlas_plain', True):          # the same atlas with the plain 2K26 skin texture
                try:
                    import gc
                    imgs_plain = dict(images)
                    imgs_plain.update(plain_imgs)
                    compose_atlas(rects, imgs_plain, donor_img, hair_rgb, size, pr.keep_rows, log, shade=shade, only=set(plain_imgs), base=big)
                    plainname = os.path.splitext(bigname)[0] + '_plain.png'      # the painted patches were redrawn in place
                    if int(big[..., 3].min()) < 255:
                        Image.fromarray(big, 'RGBA').save(plainname, optimize=False)
                    else:
                        Image.fromarray(big[..., :3]).save(plainname, optimize=False)
                    log("Wrote %s (plain: the 2K26 skin texture, nothing painted over it)" % plainname)
                    del imgs_plain
                    gc.collect()
                except Exception as e:                # noqa
                    log("WARNING: the plain %dx%d atlas export failed (%s: %s) - the painted atlas and the PAC are fine" % (
                        size, size, type(e).__name__, e))
            del big
        except Exception as e:                    # the PAC is already written: an optional image must not lose it
            log("WARNING: the %dx%d atlas export failed (%s: %s) - the PAC and the other files are fine; try a smaller --atlas-size" % (
                size, size, type(e).__name__, e))
        if strand_mcd:
            try:
                export_strand_textures(strand_mcd, src, hair_rgb, hair_ramp, size, args.beard_texture != 'raw', stem, log)
            except Exception as e:                # noqa
                log("WARNING: the %dx%d beard / hair strand textures failed (%s: %s) - the PAC and the other files are fine" % (
                    size, size, type(e).__name__, e))
    if args.normal_atlas and snap:
        size = int(args.atlas_size)
        try:
            log("Baking the %dx%d object-space normal atlas (same layout / UVs as the colour atlas, %s axes) ..." % (
                size, size, "Y-up / +Z-front (like --obj)" if args.normal_space == 'obj' else "PAC"))
            nfiles = {}
            for q in snap:
                if q.tex in rects and q.tex not in nfiles:
                    nfiles[q.tex] = src.normal_texture(q.mcd, q.tex)
            if _nb and _nb['size'] == size:
                nimg = _nb['img']                       # the bake made for the colour atlas has exactly this size / axes
            else:
                nimg = bake_object_normals(snap, rects, nfiles, size, log, green=args.normal_green, space=args.normal_space)
            nname = stem + ('_normals_object_4k.png' if size == 4096 else '_normals_object_%d.png' % size)
            Image.fromarray(nimg).save(nname, optimize=False)
            log("Wrote %s" % nname)
            del nimg
        except Exception as e:
            log("WARNING: the normal atlas failed (%s: %s) - the PAC and the other files are fine" % (type(e).__name__, e))
    models = [(chk, atlas)]
    per_blk = {}
    if beard_rgba is not None:
        Image.fromarray(beard_rgba, 'RGBA').save(stem + '_beard_texture.png')
        per_blk[len(donor.blocks)] = beard_rgba
    if face_rgba is not None:
        Image.fromarray(face_rgba[..., :3]).save(stem + '_face_texture.png')
        log("Wrote %s_face_texture.png (the texture 'face': the 2K26 eye and lip crops)" % stem)
        per_blk[face_blk] = face_rgba
    if per_blk:
        models = [(chk, atlas, per_blk)]
    if hair_tpl is not None:
        hair_rgba = gxtex.decode_c8_tpl(hair_tpl)
        bg = np.zeros((hair_rgba.shape[0], hair_rgba.shape[1], 4), np.uint8)
        bg[:] = (255, 0, 255, 255)
        a_ = hair_rgba[..., 3:4].astype(float) / 255.0
        Image.fromarray(np.concatenate([(hair_rgba[..., :3] * a_ + bg[..., :3] * (1 - a_)).astype(np.uint8)], 2)).save(stem + '_hair_texture.png')
        models.append((hair_chk, hair_rgba))
    write_preview(stem + '_preview.png', models, log)
    hp = np.array([chk.pos(i) for i in range(chk.real_vcount)]) * np.array([1, -1, -1])
    top = hp[:, 1].max()
    write_preview(stem + '_face.png', models, log, focus=(0.0, top - 6.5, hp[hp[:, 1] > top - 14][:, 2].mean(), 15.0))
    if args.obj:
        write_obj(stem + '_model.obj', obj)
        log("Wrote %s_model.obj" % stem)
    return out


def add_blood(obj, dec, lo, hi, coef, limit, vt_raw, dtree=None, group='block0'):
    """Blood layer: duplicate the new face triangles that sit inside the donor's blood region, slightly offset, with
    planar UVs fitted to the donor's blood UV layout."""
    cand = []
    tl = obj.groups.get(group, [])
    for t in tl:
        pts = np.array([obj.V[c[0]] for c in t])
        cen = pts.mean(0)
        if np.all(cen >= lo) and np.all(cen <= hi):
            nrm = np.array([obj.VN[c[0]] for c in t]).mean(0)
            if nrm[2] < -0.1:                      # faces the front (character looks towards -Z)
                cand.append((float(np.linalg.norm(cen - (lo + hi) / 2)), t))
    cand.sort(key=lambda x: x[0])
    sel = [t for _, t in cand[:limit]]
    if not sel:
        return 0
    newv = {}
    tl2 = []
    for t in sel:
        cs = []
        for (vi, ti, ni) in t:
            if vi not in newv:
                p = np.array(obj.V[vi]); n = np.array(obj.VN[ni])
                q = p + n * BLOOD_OFFSET
                newv[vi] = len(obj.V)
                obj.V.append(tuple(q)); obj.VN.append(tuple(n))
                obj.skin[newv[vi]] = obj.skin[vi]
            q = obj.V[newv[vi]]
            uv = np.array([q[0], q[1], 1.0]) @ coef
            key = (round(float(uv[0]) / 1024.0, 6), round(1.0 - float(uv[1]) / 1024.0, 6))
            cs.append((newv[vi], vt_raw(obj, key), newv[vi]))
        tl2.append(tuple(cs))
    obj.groups['blood'] = tl2
    return len(tl2)


def write_obj(path, obj):
    lines = ["# 2K26 -> Wii port (donor raw frame: Y down, face -Z)"]
    for v in obj.V:
        lines.append("v %.5f %.5f %.5f" % (v[0], -v[1], -v[2]))
    for u, v in obj.VT:
        lines.append("vt %.5f %.5f" % (u, v))
    for n in obj.VN:
        lines.append("vn %.5f %.5f %.5f" % (n[0], -n[1], -n[2]))
    for g, tl in obj.groups.items():
        lines.append("g %s" % g)
        for t in tl:
            lines.append("f " + " ".join("%d/%d/%d" % (c[0] + 1, c[1] + 1, c[2] + 1) for c in (t[0], t[2], t[1])))
    open(path, 'w').write("\n".join(lines) + "\n")


def write_preview(path, models, log, focus=None):
    """software render (front / side / 3-4 view) of the final DUMY(s) with their textures: z-buffer, alpha cut-out."""
    from PIL import Image
    meshes = []                                       # (P, tris, dumy, atlas)
    allP = []
    for mdl in models:
        d, atlas = mdl[0], mdl[1]
        per_block = mdl[2] if len(mdl) > 2 else {}
        n = d.real_vcount
        P = np.array([d.pos(i) for i in range(n)]) * np.array([1, -1, -1])      # Y up, face +Z
        nb = len(d.blocks) - 1 if (len(d.blocks) >= 6 and not per_block) else len(d.blocks)   # last block of the body model = blood
        tris = [(t, per_block.get(b, atlas)) for b in range(nb) for t in d.triangles(b) if max(c[0] for c in t) < n]
        meshes.append((P, tris, d, atlas))
        allP.append(P)
    allP = np.concatenate(allP)
    W, Hh = 460, 560
    ctr = (allP.min(0) + allP.max(0)) / 2
    sc = min(Hh * 0.94 / (allP.max(0)[1] - allP.min(0)[1]), W * 0.96 / (allP.max(0)[0] - allP.min(0)[0]))
    if focus is not None:                                 # close-up: (centre xyz in preview space, visible height)
        ctr = np.array(focus[:3], float)
        sc = Hh * 0.92 / focus[3]
    views = []
    for yaw in (0.0, 90.0, 35.0):
        a = math.radians(yaw)
        R = np.array([[math.cos(a), 0, -math.sin(a)], [0, 1, 0], [math.sin(a), 0, math.cos(a)]])
        zb = np.full((Hh, W), -1e9)
        img = np.zeros((Hh, W, 3), np.uint8); img[:] = (40, 40, 44)
        for P, tris, d, atlas in meshes:
            Q = (P - ctr) @ R.T
            for t, atl in tris:
                AH, AW = atl.shape[:2]
                q = [Q[c[0]] for c in t]
                sx = [W / 2 + p[0] * sc for p in q]
                sy = [Hh / 2 - p[1] * sc for p in q]
                x0, x1 = int(max(min(sx), 0)), int(min(max(sx) + 1, W - 1))
                y0, y1 = int(max(min(sy), 0)), int(min(max(sy) + 1, Hh - 1))
                if x1 < x0 or y1 < y0:
                    continue
                xs, ys = np.meshgrid(np.arange(x0, x1 + 1) + 0.5, np.arange(y0, y1 + 1) + 0.5)
                den = (sy[1] - sy[2]) * (sx[0] - sx[2]) + (sx[2] - sx[1]) * (sy[0] - sy[2])
                if abs(den) < 1e-9:
                    continue
                l0 = ((sy[1] - sy[2]) * (xs - sx[2]) + (sx[2] - sx[1]) * (ys - sy[2])) / den
                l1 = ((sy[2] - sy[0]) * (xs - sx[2]) + (sx[0] - sx[2]) * (ys - sy[2])) / den
                l2 = 1 - l0 - l1
                m = (l0 >= -0.02) & (l1 >= -0.02) & (l2 >= -0.02)
                if not m.any():
                    continue
                z = l0 * q[0][2] + l1 * q[1][2] + l2 * q[2][2]
                uv = [d.uvs[c[2]] for c in t]
                u = (l0 * uv[0][0] + l1 * uv[1][0] + l2 * uv[2][0]) / 1024.0
                v = (l0 * uv[0][1] + l1 * uv[1][1] + l2 * uv[2][1]) / 1024.0
                px = np.clip((u * AW).astype(int), 0, AW - 1); py = np.clip((v * AH).astype(int), 0, AH - 1)
                tex = atl[py, px]
                sub = zb[y0:y1 + 1, x0:x1 + 1]
                upd = m & (z > sub) & (tex[..., 3] >= 128)
                sub[upd] = z[upd]
                img[y0:y1 + 1, x0:x1 + 1][upd] = tex[..., :3][upd]
        views.append(img)
    Image.fromarray(np.concatenate(views, 1)).save(path)
    log("Wrote %s" % path)


# --------------------------------------------------------------------------------------------------
# vertex merge ("merge by distance")
# --------------------------------------------------------------------------------------------------
_SEAM_STATS = [0, 0]                                   # vertices before / after the last seam weld (for the log)


def cluster_positions(P, tol):
    from scipy.sparse import coo_matrix
    from scipy.sparse.csgraph import connected_components
    n = len(P)
    tree = cKDTree(P)
    pairs = tree.query_pairs(max(tol, 1e-7), output_type='ndarray')
    if len(pairs) == 0:
        return np.arange(n)
    g = coo_matrix((np.ones(len(pairs)), (pairs[:, 0], pairs[:, 1])), shape=(n, n))
    return connected_components(g, directed=False)[1]


def seam_weld_labels(P, tri_rows, lab, tol, min_loop_gap=8):
    """Second welding pass for the OPEN borders of the body.  `lab` = vertex clusters of the coincident-vertex merge; every vertex
    that sits on an open border (an edge used by one triangle only) and has another border vertex within `tol` (a different border, or
    the same border more than `min_loop_gap` vertices further along) is merged with it.  The cracks where two 2K26 objects meet
    (their borders lie a hair apart, not exactly on top of each other) become closed seams, and since the body is simplified as one
    mesh afterwards the simplification keeps them closed.  Returns new labels (compact)."""
    from scipy.sparse import coo_matrix
    from scipy.sparse.csgraph import connected_components
    nc = int(lab.max()) + 1
    T = lab[np.asarray(tri_rows, dtype=np.int64).reshape(-1, 3)]
    T = T[(T[:, 0] != T[:, 1]) & (T[:, 1] != T[:, 2]) & (T[:, 0] != T[:, 2])]
    if len(T) == 0:
        return lab
    E = np.concatenate([T[:, [0, 1]], T[:, [1, 2]], T[:, [2, 0]]])
    E.sort(axis=1)
    key = E[:, 0].astype(np.int64) * nc + E[:, 1]
    uk, cnt = np.unique(key, return_counts=True)
    bk = uk[cnt == 1]
    if len(bk) == 0:
        return lab
    be = np.stack([bk // nc, bk % nc], 1)
    bv = np.unique(be.ravel())
    # position of every cluster = mean of its members
    cn = np.bincount(lab, minlength=nc).astype(float)
    Pc = np.zeros((nc, 3))
    np.add.at(Pc, lab, P)
    Pc /= np.maximum(cn, 1.0)[:, None]
    # border loops: connected components of the border edges + the position along the loop where it is a simple cycle / chain
    g = coo_matrix((np.ones(len(be)), (be[:, 0], be[:, 1])), shape=(nc, nc))
    nl, loop = connected_components(g, directed=False)
    adj = collections.defaultdict(list)
    for a, b in be:
        adj[int(a)].append(int(b)); adj[int(b)].append(int(a))
    order, size, cyc = {}, {}, {}
    for v0 in bv:
        v0 = int(v0)
        if v0 in order:
            continue
        stack, comp = [v0], {v0}
        while stack:
            x = stack.pop()
            for y in adj[x]:
                if y not in comp:
                    comp.add(y); stack.append(y)
        ends = [v for v in comp if len(adj[v]) == 1]
        if all(len(adj[v]) <= 2 for v in comp):                 # a simple chain or cycle: walk along it
            cur, prev, seq, seen = (ends[0] if ends else v0), -1, [], set()
            while cur not in seen:
                seen.add(cur); seq.append(cur)
                nxt = [y for y in adj[cur] if y != prev and y not in seen]
                if not nxt:
                    break
                prev, cur = cur, nxt[0]
            for i, v in enumerate(seq):
                order[v], size[v], cyc[v] = i, len(seq), not ends
        else:
            for v in comp:                                      # branching border: only different borders merge
                order[v] = -1
    tree = cKDTree(Pc[bv])
    pairs = tree.query_pairs(max(tol, 1e-7), output_type='ndarray')
    if len(pairs) == 0:
        return lab
    a, b = bv[pairs[:, 0]], bv[pairs[:, 1]]
    ok = np.zeros(len(a), bool)
    for k in range(len(a)):
        u, v = int(a[k]), int(b[k])
        if loop[u] != loop[v]:
            ok[k] = True
        elif order.get(u, -1) >= 0 and order.get(v, -1) >= 0:
            d = abs(order[u] - order[v])
            if cyc.get(u):
                d = min(d, size[u] - d)
            ok[k] = d > min_loop_gap
    if not ok.any():
        return lab
    a, b = a[ok], b[ok]
    g2 = coo_matrix((np.ones(len(a)), (a, b)), shape=(nc, nc))
    _, comp2 = connected_components(g2, directed=False)
    # never create an edge shared by more than two triangles (it would stop the simplifier from touching that seam): the clusters that
    # would do it are taken back to their separate vertices
    for _ in range(3):
        T2 = comp2[T]
        T2 = T2[(T2[:, 0] != T2[:, 1]) & (T2[:, 1] != T2[:, 2]) & (T2[:, 0] != T2[:, 2])]
        T2 = np.unique(np.sort(T2, axis=1), axis=0)
        E2 = np.concatenate([T2[:, [0, 1]], T2[:, [1, 2]], T2[:, [2, 0]]])
        n2 = int(comp2.max()) + 1
        k2 = E2[:, 0].astype(np.int64) * n2 + E2[:, 1]
        uk2, c2 = np.unique(k2, return_counts=True)
        bad = uk2[c2 > 2]
        if len(bad) == 0:
            break
        badv = np.unique(np.concatenate([bad // n2, bad % n2]))
        members = np.bincount(comp2, minlength=n2)
        undo = np.isin(comp2, badv) & (members[comp2] > 1)
        # clusters that were merged by the coincident-vertex pass alone stay as they are: only undo what this pass added
        joined = undo & (np.bincount(comp2, weights=np.ones(nc), minlength=n2)[comp2] > 1)
        if not joined.any():
            break
        comp2 = comp2.copy()
        comp2[joined] = comp2.max() + 1 + np.arange(int(joined.sum()))
    return comp2[lab]


def weld_collect2(items, tol, tags=None, seam_tol=0.0):
    """items: [(part, triangle-index array)] -> (P, N, W, imp, tris, cuvs) with every vertex pair closer than `tol` merged
    (position = mean of the cluster, normal = normalised sum, weights/uv corners of the first member, importance = max).
    tags: optional list (one array per item) of per-triangle values (the donor submesh); they are filtered along with the
    triangles and returned as a 7th value."""
    rows_P, rows_N, rows_W, rows_I, tri_rows, cuvs = [], [], [], [], [], []
    row_tags = []
    for k_item, (p, ix) in enumerate(items):
        if tags is not None:
            row_tags.extend(int(x) for x in tags[k_item])
        used = np.unique(p.T[ix])
        base = sum(len(r) for r in rows_P)
        lut = dict((int(v), base + k) for k, v in enumerate(used))
        rows_P.append(p.P[used]); rows_N.append(p.N[used]); rows_W.extend(p.W[v] for v in used)
        imp = getattr(p, 'imp', None)
        rows_I.append(np.asarray(imp)[used] if imp is not None else np.ones(len(used)))
        for ti in ix:
            t = p.T[ti]
            tri_rows.append(tuple(lut[int(v)] for v in t))
            cuvs.append(tuple(tuple(p.PUV[v]) for v in t))
    Pall = np.concatenate(rows_P); Nall = np.concatenate(rows_N); Iall = np.concatenate(rows_I)
    lab = cluster_positions(Pall, tol)
    if seam_tol and seam_tol > tol:
        n0 = int(lab.max()) + 1
        lab = seam_weld_labels(Pall, tri_rows, lab, seam_tol)
        _, lab = np.unique(lab, return_inverse=True)
        _SEAM_STATS[:] = [n0, int(lab.max()) + 1]
    nc = lab.max() + 1
    cnt = np.bincount(lab, minlength=nc).astype(float)
    Pm = np.zeros((nc, 3)); Nm = np.zeros((nc, 3)); Im = np.zeros(nc)
    np.add.at(Pm, lab, Pall); np.add.at(Nm, lab, Nall); np.maximum.at(Im, lab, Iall)
    Pm /= cnt[:, None]
    Nm /= np.maximum(np.linalg.norm(Nm, axis=1, keepdims=True), 1e-9)
    first = np.full(nc, -1)
    for r in range(len(lab) - 1, -1, -1):
        first[lab[r]] = r
    W = [rows_W[first[c]] for c in range(nc)]
    seen, tris, cu, tg = set(), [], [], []
    for k_tri, (t, c) in enumerate(zip(tri_rows, cuvs)):
        a, b, d = int(lab[t[0]]), int(lab[t[1]]), int(lab[t[2]])
        if a == b or b == d or a == d:
            continue
        key = tuple(sorted((a, b, d)))
        if key in seen:                       # exact duplicate (double sided) triangle
            continue
        seen.add(key)
        tris.append((a, b, d)); cu.append(c)
        if tags is not None:
            tg.append(row_tags[k_tri])
    if tags is not None:
        return [tuple(x) for x in Pm], [x for x in Nm], W, Im, tris, cu, tg
    return [tuple(x) for x in Pm], [x for x in Nm], W, Im, tris, cu


def weld_collect(items, tol, seam_tol=0.0):
    P, N, W, imp, tris, cu = weld_collect2(items, tol, seam_tol=seam_tol)
    return P, N, W, tris, cu


# --------------------------------------------------------------------------------------------------
# hair model (separate DUMY = PACH entry 0x2710 + 'hair_' texture)
# --------------------------------------------------------------------------------------------------
HAIR_ENTRY = 10000          # 0x2710
HAIR_SPRING_ENTRIES = (60, 61)   # 0x3C SpringHairSetting, 0x3D SpringHairCollision
HAIR_TEX = 'hair_'
HAIR_TEX_NAMES = ('trans', 'hair_')          # names of the hair texture in the Wii pacs ('trans'; ch107 / older notes: 'hair_')


def make_hair_strands(rgb, size=256, coverage=0.72, seed=11):
    """Strand-card texture like the original 'hair_' atlas: wavy strands with soft alpha (3-bit) on transparent.
    Returns (index image, palette rgba) ready for encode_c8_tpl_indexed, and a decoded RGBA preview."""
    rng = np.random.RandomState(seed)
    yy = np.arange(size, dtype=np.float32)[:, None]
    xx = np.arange(size, dtype=np.float32)[None, :]
    alpha = np.zeros((size, size), np.float32)
    shade = np.zeros((size, size), np.float32)
    nstr = int(size * coverage * 0.55)
    for _ in range(nstr):
        x0 = rng.rand() * size
        amp = 1.5 + rng.rand() * 6
        per = 40 + rng.rand() * 120
        ph = rng.rand() * 6.28
        wid = 1.1 + rng.rand() * 1.4
        sh = 0.75 + rng.rand() * 0.45
        xc = x0 + amp * np.sin(2 * np.pi * yy / per + ph)
        d = np.abs(((xx - xc + size / 2) % size) - size / 2)          # wrap around so the texture tiles
        a = np.clip(1.0 - d / wid, 0, 1)
        m = a > alpha
        alpha = np.where(m, a, alpha)
        shade = np.where(m, sh, shade)
    # a dense, fully opaque root band at the top (u,v origin = top-left) keeps short hair / beard solid
    alpha[:6, :] = 1.0
    shade[:6, :] = 0.8
    SL, AL = 8, 8
    si = np.clip(((shade - 0.7) / 0.5 * (SL - 1)).round().astype(int), 0, SL - 1)
    ai = np.clip((alpha * (AL - 1)).round().astype(int), 0, AL - 1)
    idx = (si * AL + ai).astype(np.uint8)
    pal = np.zeros((SL * AL, 4), np.uint16)
    for s in range(SL):
        f = 0.7 + 0.5 * s / (SL - 1)
        for a in range(AL):
            c = np.clip(np.array(rgb, float) * f, 0, 255)
            pal[s * AL + a] = (int(c[0]), int(c[1]), int(c[2]), int(round(255 * a / (AL - 1))))
    return idx, pal


def rai_hair_texture(img, hair_rgb, ramp, size, gap_alpha=0.55, convert=True, colours=32, alevels=8):
    """The hair-donor texture made from the 2K strand map (combinations_rai) instead of an invented one: the SAME map, the
    SAME layout, so the cards keep their default 2K UVs (fract(uv)) and every strand lands where it does in 2K26.
    * colour: strand_map_to_colour (the 2K hair material's root / tip colours, or one flat colour); convert=False keeps the raw map;
    * alpha: strands (the wide bodies of the map) are opaque, the gaps between them get `gap_alpha` (0 = see-through, 1 = solid);
    * C8 + RGB5A3 palette: `colours` colours x `alevels` alpha levels = 256 palette entries (3-bit alpha, like the game's own).
    Returns (index image uint8 (size_h, size_w), palette (256, 4) uint16 RGBA, rgba uint8 preview (size_h, size_w, 4))."""
    from PIL import Image
    h, w = size
    src_rgb = strand_map_to_colour(img, hair_rgb, ramp) if convert else img.convert('RGB')
    a = np.asarray(img.convert('RGB'), np.float32) / 255.0
    body = strand_body(a, strand_bg(a))
    alpha = np.clip(gap_alpha + (1.0 - gap_alpha) * body, 0.0, 1.0)
    # downscale colour weighted by alpha (so transparent gaps do not bleed their colour into the strands), alpha plain
    c = np.asarray(src_rgb, np.float32)
    big = np.concatenate([c * alpha[..., None], alpha[..., None]], 2)
    chans = [np.asarray(Image.fromarray(big[..., k]).resize((w, h), Image.BOX), np.float32) for k in range(4)]
    al = np.clip(chans[3], 1e-4, 1.0)
    rgb = np.clip(np.stack(chans[:3], 2) / al[..., None], 0, 255)
    al = chans[3]
    ai = np.clip((al * (alevels - 1)).round().astype(int), 0, alevels - 1)
    q = Image.fromarray(rgb.astype(np.uint8)).quantize(colours, method=Image.MEDIANCUT, dither=Image.NONE)
    cidx = np.asarray(q, np.uint8).astype(int)
    pal3 = np.asarray(q.getpalette(), np.uint8)[:colours * 3].reshape(-1, 3)
    pal3 = np.concatenate([pal3, np.zeros((colours - len(pal3), 3), np.uint8)]) if len(pal3) < colours else pal3
    idx = (cidx * alevels + ai).astype(np.uint8)
    pal = np.zeros((colours * alevels, 4), np.uint16)
    for ci in range(colours):
        for k in range(alevels):
            pal[ci * alevels + k] = (int(pal3[ci][0]), int(pal3[ci][1]), int(pal3[ci][2]), int(round(255.0 * k / (alevels - 1))))
    prev = np.concatenate([pal3[cidx].astype(np.uint8), np.round(255.0 * ai / (alevels - 1)).astype(np.uint8)[..., None]], 2)
    return idx, pal, prev


def _signed_volume(P, T):
    P = np.asarray(P, float)
    T = np.asarray(T)
    return float(np.einsum('ij,ij->i', P[T[:, 0]], np.cross(P[T[:, 1]], P[T[:, 2]])).sum() / 6.0)


SHELL_CLEAN = dict(rounds=4, min_faces=150, bound_w=5.0)


def _clean_face_mask(F, keep, rounds=2, min_faces=60):
    """Smooth a per-face keep mask over the face adjacency (isolated kept faces go, single-face gaps close) and drop kept
    islands smaller than `min_faces`.  The raw 'faces looking away from the head' mask is ragged along the silhouette, and a
    ragged border costs a vertex for nearly every triangle."""
    nf = len(F)
    e = np.concatenate([F[:, [0, 1]], F[:, [1, 2]], F[:, [2, 0]]])
    fid = np.tile(np.arange(nf), 3)
    e = np.sort(e, 1)
    order = np.lexsort((e[:, 1], e[:, 0]))
    e, fid = e[order], fid[order]
    same = (e[1:, 0] == e[:-1, 0]) & (e[1:, 1] == e[:-1, 1])
    a, b = fid[:-1][same], fid[1:][same]                         # face pairs that share an edge
    keep = keep.copy()
    for _ in range(rounds):
        nk = np.zeros(nf, int)
        np.add.at(nk, a, keep[b].astype(int))
        np.add.at(nk, b, keep[a].astype(int))
        keep = (keep.astype(int) + nk) >= 2
    from scipy import sparse
    from scipy.sparse.csgraph import connected_components
    m = keep[a] & keep[b]
    g = sparse.coo_matrix((np.ones(int(m.sum())), (a[m], b[m])), shape=(nf, nf))
    _, lab = connected_components(g, directed=False)
    size = np.bincount(lab[keep], minlength=lab.max() + 1)
    keep = keep & (size[lab] >= min_faces)
    # small enclosed gaps of the shell (concave bits wrongly seen as 'looking into the head') are closed again: only the big
    # connected region that really faces the head stays open
    drop = ~keep
    m = drop[a] & drop[b]
    g = sparse.coo_matrix((np.ones(int(m.sum())), (a[m], b[m])), shape=(nf, nf))
    _, lab = connected_components(g, directed=False)
    dsize = np.bincount(lab[drop], minlength=lab.max() + 1)
    small = drop & (dsize[lab] < max(250, int(0.04 * nf)))
    return keep | small


def card_uv_transfer(Pn, tris_n, hparts, log=None, size=ATLAS):
    """Default hair UVs: every triangle of the new beard / hair shell takes its UVs from the ORIGINAL hair cards (the 2K
    'combinations' material), not from a re-packed or generated mapping.  Each triangle finds the nearest card triangle and
    copies that card's UV map (texel density and strand direction of the 2K model) - its corners are projected into the card's
    plane and run through the card's own affine UV map.  A triangle's UVs are only shifted by whole texture repeats (or, if it
    straddles the edge of the texture, slid back inside), never rescaled.  Returns per-triangle corner UVs in pixels of a
    size x size texture (like all other UVs here)."""
    P = np.concatenate([p.P for p in hparts if len(p.T)])
    UV = np.concatenate([np.asarray(p.UV, float) for p in hparts if len(p.T)])
    off, T = 0, []
    for p in hparts:
        if len(p.T):
            T.append(p.T + off)
        off += len(p.P)
    T = np.concatenate(T)
    A, B, C = P[T[:, 0]], P[T[:, 1]], P[T[:, 2]]
    uA, uB, uC = UV[T[:, 0]], UV[T[:, 1]], UV[T[:, 2]]
    n = np.cross(B - A, C - A)
    area = np.linalg.norm(n, axis=1)
    e1 = B - A
    l1 = np.linalg.norm(e1, axis=1)
    ok = (area > 1e-12) & (l1 > 1e-9)
    nn = n / np.maximum(area, 1e-12)[:, None]
    e1n = e1 / np.maximum(l1, 1e-12)[:, None]
    e2 = np.cross(nn, e1n)
    a1 = np.stack([l1, np.zeros(len(T))], 1)                                    # B in the card's plane coordinates
    a2 = np.stack([((C - A) * e1n).sum(1), ((C - A) * e2).sum(1)], 1)           # C
    dB, dC = uB - uA, uC - uA
    det = a1[:, 0] * a2[:, 1] - a1[:, 1] * a2[:, 0]
    det = np.where(np.abs(det) < 1e-18, 1.0, det)
    # M (2x2): [dB dC] = M [a1 a2]   ->   M = [dB dC] [a1 a2]^-1
    # [a1 a2] = [[a1x, a2x],[a1y, a2y]]  ->  its inverse = 1/det [[a2y, -a2x], [-a1y, a1x]]
    inv = np.stack([np.stack([a2[:, 1], -a2[:, 0]], 1), np.stack([-a1[:, 1], a1[:, 0]], 1)], 1) / det[:, None, None]
    M = np.einsum('nik,nkj->nij', np.stack([dB, dC], 2), inv)
    uvok = ok & (np.abs(dB[:, 0] * dC[:, 1] - dB[:, 1] * dC[:, 0]) > 1e-9)
    cen = (A + B + C) / 3.0
    idx = np.nonzero(uvok)[0]
    if len(idx) == 0:
        return None
    tree = cKDTree(cen[idx])
    Pn = np.asarray(Pn, float)
    out = []
    kq = min(12, len(idx))
    for t in tris_n:
        q = Pn[list(t)]
        c = q.mean(0)
        _, cand = tree.query(c, k=kq)
        cand = idx[np.atleast_1d(cand)]
        # distance of c to each candidate card triangle (projection into its plane, clamped into the triangle)
        d = c - A[cand]
        x = (d * e1n[cand]).sum(1)
        y = (d * e2[cand]).sum(1)
        z = (d * nn[cand]).sum(1)
        p2 = np.stack([x, y], 1)
        a, b_, c_ = np.zeros((len(cand), 2)), a1[cand], a2[cand]
        # closest point of the 2D triangle (a, b_, c_) to p2 (barycentric clamp, good enough for choosing a card)
        v0, v1 = b_ - a, c_ - a
        d00, d01, d11 = (v0 * v0).sum(1), (v0 * v1).sum(1), (v1 * v1).sum(1)
        d20, d21 = (p2 * v0).sum(1), (p2 * v1).sum(1)
        den = np.maximum(d00 * d11 - d01 * d01, 1e-18)
        bv = np.clip((d11 * d20 - d01 * d21) / den, 0, 1)
        bw = np.clip((d00 * d21 - d01 * d20) / den, 0, 1)
        s = bv + bw
        sc = np.where(s > 1, 1.0 / np.maximum(s, 1e-12), 1.0)
        cp = a + (v0 * (bv * sc)[:, None]) + (v1 * (bw * sc)[:, None])
        dist = np.sqrt(((p2 - cp) ** 2).sum(1) + z * z)
        j = cand[int(np.argmin(dist))]
        uvs = []
        for P3 in q:
            dd = P3 - A[j]
            pl = np.array([(dd * e1n[j]).sum(), (dd * e2[j]).sum()])
            uvs.append(uA[j] + M[j] @ pl)
        uvs = np.array(uvs)
        uvs -= np.floor(uvs.mean(0))                                            # whole repeats only
        lo_, hi_ = uvs.min(0), uvs.max(0)
        ext = hi_ - lo_
        for k in range(2):
            if ext[k] > 0.98:                                                   # larger than the texture: scale to fit
                uvs[:, k] = (uvs[:, k] - lo_[k]) * (0.98 / ext[k]) + 0.01
            elif lo_[k] < 0.01 or hi_[k] > 0.99:                                # straddles the border: slide inside
                uvs[:, k] += np.clip(lo_[k], 0.01, 0.99 - ext[k]) - lo_[k]
        out.append(tuple((0.5 + float(u) * (size - 1.0), 0.5 + float(v) * (size - 1.0)) for u, v in uvs))
    if log:
        log("Beard UVs: default hair-card UVs of the 2K 'combinations' material copied to %d triangles (nearest card, own texel density)" % len(out))
    return out


def hair_shell(hparts, head_center, ref_sign, t_budget, v_budget, log, mouth_pts=None, uv_patch=None, uv_mode='default'):
    """Beard / hair cards -> ONE clean outer surface.  The cards are voxelised, closed into a solid volume, the surface is
    extracted (marching cubes) and edge-collapsed to the budget: a smooth beard / hair volume whose triangles describe its
    SHAPE (hundreds of overlapping card islands cannot be decimated, and grid clustering turns them into a blocky tangle).
    Faces that look into the head are dropped.  The beard is filled like the 2K model: nothing is opened for the mouth unless
    `mouth_pts` is given (--beard-open-mouth), in which case the mouth window and the see-through openings of the cards seen
    from the front stay open.  Needs scikit-image; returns None without it.
    Returns (P, N, W, imp, tris, cuvs) with compact vertex ids."""
    try:
        from skimage import measure
        from scipy import ndimage
    except ImportError:
        return None
    P = np.concatenate([p.P for p in hparts])
    W, T, off = [], [], 0
    for p in hparts:
        T.append(p.T + off)
        off += len(p.P)
        W.extend(p.W)
    T = np.concatenate(T)
    used = np.unique(T)
    uv = tuple(float(x) for x in np.mean(np.concatenate([np.asarray(p.PUV)[np.unique(p.T)] for p in hparts]), 0))
    imp_v = float(max(np.max(np.asarray(p.imp)) for p in hparts))
    ext = float((P[used].max(0) - P[used].min(0)).max())
    cell = ext / 55.0
    A, B, C = P[T[:, 0]], P[T[:, 1]], P[T[:, 2]]
    L = np.maximum(np.linalg.norm(B - A, axis=1), np.maximum(np.linalg.norm(C - A, axis=1), np.linalg.norm(C - B, axis=1)))
    for _ in range(4):
        # points on the surface of the cards, at most half a cell apart
        pts = [P[used]]
        n = np.clip(np.ceil(L / (cell * 0.5)).astype(int), 1, 40)
        for k in np.unique(n):
            sel = np.nonzero(n == k)[0]
            for i in range(k + 1):
                for j in range(k + 1 - i):
                    u, v = i / float(k), j / float(k)
                    pts.append(A[sel] * (1 - u - v) + B[sel] * u + C[sel] * v)
        pts = np.concatenate(pts)
        lo = pts.min(0) - 4 * cell
        idx = np.floor((pts - lo) / cell).astype(int) + 2
        vol = np.zeros(tuple(idx.max(0) + 3), bool)
        vol[idx[:, 0], idx[:, 1], idx[:, 2]] = True
        vol = ndimage.binary_dilation(vol, iterations=1)
        vol = ndimage.binary_closing(vol, iterations=2)
        vol = ndimage.binary_fill_holes(vol)
        verts, faces, _, _ = measure.marching_cubes(ndimage.gaussian_filter(vol.astype(np.float32), 0.9), level=0.5)
        if len(faces) <= 150000:
            break
        cell *= 1.35
    V = lo + (verts - 2 + 0.5) * cell
    F = faces
    # same winding convention as the body (its signed volume has the sign `ref_sign`)
    if _signed_volume(V, F) * ref_sign < 0:
        F = F[:, [0, 2, 1]]
    cen = V.mean(0)
    cF = V[F].mean(1)
    nF = np.cross(V[F[:, 1]] - V[F[:, 0]], V[F[:, 2]] - V[F[:, 0]])
    nF /= np.maximum(np.linalg.norm(nF, axis=1, keepdims=True), 1e-12)
    sgn = 1.0 if np.median(((cF - cen) * nF).sum(1)) >= 0 else -1.0          # +1: the cross product points outwards
    out = nF * sgn
    keep = ((cF - head_center) * out).sum(1) > 0                              # drop the faces that look into the head
    # see-through openings of the cards in the front view (the character looks towards -Z): a 2D mask of the cards
    # (x, y), enclosed holes of it stay open
    px = np.floor((pts[:, :2] - lo[:2]) / (cell * 0.5)).astype(int) + 2
    mask = np.zeros(tuple(px.max(0) + 3), bool)
    mask[px[:, 0], px[:, 1]] = True
    mask = ndimage.binary_dilation(mask, iterations=2)
    holes = ndimage.binary_fill_holes(mask) & ~mask
    lab, nlab = ndimage.label(holes)
    if nlab and mouth_pts is not None:                        # see-through openings are only carved with --beard-open-mouth
        sizes = ndimage.sum(holes, lab, range(1, nlab + 1))
        big = np.isin(lab, [i + 1 for i, s in enumerate(sizes) if s >= 25])
        cx = np.floor((cF[:, :2] - lo[:2]) / (cell * 0.5)).astype(int) + 2
        ok = (cx[:, 0] >= 0) & (cx[:, 0] < big.shape[0]) & (cx[:, 1] >= 0) & (cx[:, 1] < big.shape[1])
        inhole = np.zeros(len(F), bool)
        inhole[ok] = big[cx[ok, 0], cx[ok, 1]]
        keep &= ~inhole
    if mouth_pts is not None and len(mouth_pts):
        # mouth window: the 2K mouth (teeth / tongue / mouth bag) seen from the front, plus a lip margin; everything of the
        # beard in front of it is removed (a solid beard has no alpha cut-outs, so the lips would disappear)
        m_lo, m_hi = mouth_pts[:, :2].min(0), mouth_pts[:, :2].max(0)
        mg = np.array([0.15, 0.6]) * (m_hi - m_lo) + 0.5 * cell            # lip margin: 15 % sideways, 60 % up / down
        m_lo, m_hi = m_lo - mg, m_hi + mg
        inwin = (cF[:, 0] >= m_lo[0]) & (cF[:, 0] <= m_hi[0]) & (cF[:, 1] >= m_lo[1]) & (cF[:, 1] <= m_hi[1])
        keep &= ~inwin
    keep = _clean_face_mask(F, keep, SHELL_CLEAN['rounds'], SHELL_CLEAN['min_faces'])
    F = F[keep]
    if len(F) == 0:
        return None
    u = np.unique(F)
    remap = -np.ones(len(V), int)
    remap[u] = np.arange(len(u))
    V, F = V[u], remap[F]
    _, nn = cKDTree(P[used]).query(V)
    Wv = [W[used[i]] for i in nn]
    cuv = [(uv, uv, uv)] * len(F)
    nt, nc = qem.decimate([tuple(x) for x in V], [tuple(int(i) for i in t) for t in F], cuv, t_budget, weights=Wv,
                          target_verts=v_budget, bound_w=SHELL_CLEAN['bound_w'])
    ids = sorted(set(v for t in nt for v in t))
    loc = dict((v, i) for i, v in enumerate(ids))
    Pn = np.array([V[v] for v in ids])
    tris_n = [tuple(loc[v] for v in t) for t in nt]
    Nn = np.zeros((len(ids), 3))
    for t in tris_n:
        a, b, c = Pn[t[0]], Pn[t[1]], Pn[t[2]]
        nrm = np.cross(b - a, c - a)
        for v in t:
            Nn[v] += nrm
    Nn *= sgn
    Nn /= np.maximum(np.linalg.norm(Nn, axis=1, keepdims=True), 1e-12)
    if uv_patch is not None and uv_mode == 'default':
        cu = card_uv_transfer(Pn, tris_n, hparts, log)
        if cu is not None:
            nc = cu
        else:
            uv_mode = 'wrap'                                    # no usable card UVs
    if uv_patch is not None and uv_mode != 'default':
        # the beard has its own texture: wrap-around mapping (angle, height) onto the dense strand field of the 2K map,
        # one UV per vertex (corner UVs in atlas pixel units like everything else)
        u0, u1, v0, v1 = uv_patch
        lo_, hi_ = Pn.min(0), Pn.max(0)
        # u = angle around the head's vertical axis (0 = straight ahead, the character looks towards -Z), v = height:
        # the strands run down the beard everywhere, also on the cheeks and under the chin
        th_ = np.arctan2(Pn[:, 0] - head_center[0], -(Pn[:, 2] - head_center[2]))
        tu_ = (th_ - th_.min()) / max(float(th_.max() - th_.min()), 1e-9)
        tv_ = (Pn[:, 1] - lo_[1]) / max(hi_[1] - lo_[1], 1e-9)
        vuv = [((u0 + a * (u1 - u0)) * ATLAS, (v0 + b * (v1 - v0)) * ATLAS) for a, b in zip(tu_, tv_)]
        nc = [tuple(vuv[v] for v in t) for t in tris_n]
    log("Beard / hair volume: %d card triangles -> solid shell of %d faces (%d facing outwards) -> %d triangles / %d vertices "
        "(budget %d / %d)" % (len(T), len(faces), int(keep.sum()), len(tris_n), len(ids), t_budget, v_budget))
    return ([tuple(x) for x in Pn], [x for x in Nn], [Wv[v] for v in ids], np.full(len(ids), imp_v), tris_n, [tuple(c) for c in nc])


def collect_cards(hparts, to_px=None, use_patch_uv=False, rect=None):
    """The original beard / hair cards as they are: every vertex of every card stays its own vertex (NO welding, NO clustering).
    UVs are the 2K hair material's own (default) UVs per triangle corner, only shifted by whole texture repeats per triangle
    (the strand texture tiles).  to_px: None = UV in 0..1; a size = pixels of a size x size texture (0.5 + uv * (size - 1)).
    use_patch_uv: take `p.PUV` (already placed inside the colour atlas) instead.
    rect: (x, y, w, h) of a patch of the colour atlas (atlas pixel units): the UVs are placed inside it, per triangle (whole repeats
    removed by the triangle's centre, then kept one pixel inside the patch) - the strand map sits in the atlas.
    Returns (P, N, W, imp, tris, cuvs) over ALL vertices of the parts (unused ones simply have no triangles)."""
    parts = [p for p in hparts if len(p.T)]
    P, N, W, I, tris, cuvs = [], [], [], [], [], []
    off = 0
    for p in parts:
        P.extend(tuple(float(x) for x in v) for v in p.P)
        N.extend(np.asarray(p.N, float))
        W.extend(p.W)
        imp = getattr(p, 'imp', None)
        I.extend(np.asarray(imp, float) if imp is not None else np.ones(len(p.P)))
        uv = np.asarray(p.PUV if use_patch_uv else p.UV, float)
        lay = getattr(p, 'layer', None)
        if lay is not None and lay[1] < 2:
            lay = None
        for t in p.T:
            a, b, c = int(t[0]), int(t[1]), int(t[2])
            if a == b or b == c or a == c:
                continue
            cu = uv[[a, b, c]]
            if not use_patch_uv:
                cu = cu - np.floor(cu.mean(0))                    # whole repeats only
                if lay is not None:                               # several strand maps stacked in one texture: squeeze v into map k of n
                    cu = np.stack([cu[:, 0], (cu[:, 1] + lay[0]) / float(lay[1])], 1)
                if rect is not None:
                    rx, ry, rw, rh = rect
                    cu = np.stack([np.clip(rx + 0.5 + cu[:, 0] * (rw - 1.0), rx + 1.0, rx + rw - 1.0),
                                   np.clip(ry + 0.5 + cu[:, 1] * (rh - 1.0), ry + 1.0, ry + rh - 1.0)], 1)
                elif to_px:
                    cu = 0.5 + cu * (to_px - 1.0)
            tris.append((a + off, b + off, c + off))
            cuvs.append(tuple((float(u), float(v)) for u, v in cu))
        off += len(p.P)
    return P, N, W, np.asarray(I, float), tris, cuvs


def hair_cards(hparts, t_budget, v_budget, log, uv_patch=None, rect=None):
    """Beard / hair that stays in the body DUMY, the simple way: the ORIGINAL cards, only decimated (edge collapse).  No vertex
    merging, no clustering, no voxel shell - the cards keep their shape, their default 2K UVs and their normals; the collapse only
    ever removes a vertex by moving it onto a neighbour.  Returns (P, N, W, imp, tris, cuvs) with compact vertex ids."""
    if rect is not None:
        P, N, W, imp, tris, cuvs = collect_cards(hparts, rect=rect)
    else:
        P, N, W, imp, tris, cuvs = collect_cards(hparts, to_px=ATLAS, use_patch_uv=(uv_patch is None))
    if not tris:
        return None
    nv0 = len(set(v for t in tris for v in t))
    nt, nc = qem.decimate(P, tris, cuvs, t_budget, weights=W, target_verts=v_budget, importance=imp, bound_w=SHELL_CLEAN['bound_w'])
    nt, nc = qem.enforce_budget(P, nt, nc, t_budget, v_budget)
    used = sorted(set(v for t in nt for v in t))
    loc = dict((v, i) for i, v in enumerate(used))
    log("Beard / hair: the original cards, only decimated (no vertex merging, no shell): %d triangles / %d vertices -> %d triangles / "
        "%d vertices (budget %d / %d); default 2K UVs kept" % (len(tris), nv0, len(nt), len(used), t_budget, v_budget))
    return ([P[v] for v in used], [np.asarray(N[v], float) for v in used], [W[v] for v in used],
            np.asarray([imp[v] for v in used], float), [tuple(loc[v] for v in t) for t in nt], [tuple(c) for c in nc])


def prepare_merged_hair(hparts, t_budget, v_budget, tol, log, head_center=None, ref_sign=None, mouth_pts=None, uv_patch=None,
                        uv_mode='default', mode='cards', rect=None):
    """Beard / hair cards that stay inside the body DUMY (no hair donor).  They are made of hundreds of tiny islands, which
    the body decimation would drop or cannot merge, so they get their OWN budget.  Preferred: a solid outer shell of the
    cards (hair_shell, needs scikit-image); otherwise the cards are welded without dropping any, grid-clustered and
    edge-collapsed to `t_budget` triangles / `v_budget` vertices.  Returns (P, N, W, imp, tris, cuvs) with compact vertex ids,
    or None when there is nothing."""
    items = [(p, np.arange(len(p.T))) for p in hparts if len(p.T)]
    if not items or t_budget <= 0:
        return None
    if mode == 'cards':
        return hair_cards(hparts, t_budget, v_budget, log, uv_patch=uv_patch, rect=rect)
    if head_center is not None and ref_sign:
        res = hair_shell([p for p in hparts if len(p.T)], head_center, ref_sign, t_budget, v_budget, log, mouth_pts=mouth_pts,
                         uv_patch=uv_patch, uv_mode=uv_mode)
        if res is not None:
            return res
        log("Beard / hair: scikit-image is not installed (pip install scikit-image) -> coarser grid-clustered cards are used")
    P, N, W, imp, tris, cuvs = weld_collect2(items, tol)
    if not tris:
        return None
    if len(tris) > t_budget or len(set(v for t in tris for v in t)) > v_budget:
        P_, N_, W_, t_, c_ = qem.cluster_decimate(P, tris, cuvs, N, W, v_budget, t_budget)
        # cluster_decimate lost the per-vertex importance: the hair sits on the head, use the largest one
        imp_ = np.full(len(P_), float(np.max(imp)))
    else:
        P_, N_, W_, t_, c_, imp_ = P, N, W, tris, cuvs, imp
    nt, nc = qem.decimate(P_, t_, c_, t_budget, weights=W_, target_verts=v_budget, importance=imp_)
    nt, nc = qem.enforce_budget(P_, nt, nc, t_budget, v_budget)
    used = sorted(set(v for t in nt for v in t))
    loc = dict((v, i) for i, v in enumerate(used))
    log("Beard / hair cards: %d triangles / %d vertices after merge -> %d triangles / %d vertices (budget %d / %d)" % (
        len(tris), len(P), len(nt), len(used), t_budget, v_budget))
    return ([tuple(np.asarray(P_[v], float)) for v in used], [np.asarray(N_[v], float) for v in used], [W_[v] for v in used],
            np.asarray([imp_[v] for v in used], float), [tuple(loc[v] for v in t) for t in nt], [tuple(c) for c in nc])


def build_hair(hair_parts, hdonor, hair_rgb, args, log, names=None):
    """Decimate the 2K hair/beard (combinations) to the limits of the hair donor DUMY and import it into that DUMY."""
    hv = hdonor.real_vcount
    ht = sum(len(list(hdonor.triangles(b))) for b in range(len(hdonor.blocks)))
    hbytes = len(hdonor.data)
    for p in hair_parts:
        p.PUV = p.UV - np.floor(p.UV)                       # strand texture tiles: uv = fract(2K uv)
    cards = (getattr(args, 'hair_mode', 'cards') == 'cards')
    if cards:
        # the original cards, only decimated: no welding of vertices, no clustering (per-triangle default UVs, uv = fract(2K uv))
        P, N, W, _imp, tris, cuvs = collect_cards(hair_parts, to_px=None)
        log("Hair: %d vertices / %d triangles kept as they are (no vertex merging); donor hair limits %d verts / %d tris" % (
            len(set(v for t in tris for v in t)), len(tris), hv, ht))
    else:
        items = [(p, np.arange(len(p.T))) for p in hair_parts]
        P, N, W, tris, cuvs = weld_collect(items, args.merge * args.merge_scale, seam_tol=float(getattr(args, 'seam_weld', SEAM_WELD) or 0.0) * args.merge_scale)
        log("Hair: %d vertices / %d triangles after merge; donor hair limits %d verts / %d tris" % (len(P), len(tris), hv, ht))
    dP = np.array([hdonor.pos(i) for i in range(hv)])
    dN = np.array([hdonor.normal_out(i) for i in range(hv)])
    dtree = cKDTree(dP)
    scale = 1.0
    dumy_out = None
    for attempt in range(8):
        T_t, V_t = int(ht * 0.97 * scale), int(hv * 0.97 * scale)
        # 1) cluster the hair cards into a coarse volume that fits the vertex budget, 2) edge-collapse to the triangle budget
        if cards:
            P_, N_, W_, t_, c_ = P, N, W, tris, cuvs
            nt, nc = qem.decimate(P_, t_, c_, T_t, weights=W_, target_verts=V_t, log=log, bound_w=SHELL_CLEAN['bound_w'])
        else:
            P_, N_, W_, t_, c_ = qem.cluster_decimate(P, tris, cuvs, N, W, V_t, T_t)
            nt, nc = qem.decimate(P_, t_, c_, T_t, weights=W_, target_verts=V_t, log=log)
        nt, nc = qem.enforce_budget(P_, nt, nc, T_t, V_t)
        used = sorted(set(v for t in nt for v in t))
        loc = dict((v, i) for i, v in enumerate(used))
        obj = T.ObjModel(); obj.skin = {}; obj.meta = {}
        for v in used:
            obj.V.append(tuple(P_[v]))
            n = np.array(N_[v], float)
            if args.normals == 'donor':
                dd, jj = dtree.query(P_[v])
                if dd < args.normal_dist and float(np.dot(dN[jj], n)) > 0.3:
                    n = dN[jj]
            obj.VN.append(tuple(n / (np.linalg.norm(n) or 1.0)))
            obj.skin[loc[v]] = W_[v]
        vti = {}
        tl = []
        for t, c in zip(nt, nc):
            cs = []
            for k in range(3):
                key = (round(float(c[k][0]), 5), round(1.0 - float(c[k][1]), 5))
                if key not in vti:
                    vti[key] = len(obj.VT); obj.VT.append(key)
                cs.append((loc[t[k]], vti[key], loc[t[k]]))
            tl.append(tuple(cs))
        obj.groups['hair'] = tl
        mapping = collections.OrderedDict([('hair', dict(block=0, bone=None, color=None))])
        out, stats = T.port_model(hdonor, obj, mapping, T.Xform(1.0, flip=(False, False, False)), names=names,
                                  weight_mode='file', restrict=True, colour_mode='transfer',
                                  weld_angle='auto' if args.weld == 'auto' else float(args.weld),
                                  vert_budget=hv, log=lambda s: log("  [hair dumy] " + s))
        chk = T.Dumy(out)
        ntri = sum(len(list(chk.triangles(b))) for b in range(len(chk.blocks)))
        log("Hair DUMY attempt %d: %d vertices (limit %d), %d triangles (limit %d), %d bytes (donor %d)" % (
            attempt + 1, chk.real_vcount, hv, ntri, ht, len(out), len(hdonor.data)))
        dumy_out = out
        if chk.real_vcount <= hv and ntri <= ht and len(out) <= len(hdonor.data) * args.size_limit:
            return out, chk, ntri
        scale *= 0.93
    log("WARNING: hair model exceeds the hair donor's limits - lower --tri-scale")
    return dumy_out, chk, ntri

# --------------------------------------------------------------------------------------------------
def main(argv=None):
    ap = argparse.ArgumentParser(description="WWE 2K to Wii Model Converter by Jatin Talwar (Mod Place Wii): WWE 2K26 character -> WWE (Wii) .pac")
    ap.add_argument('character', help="2K26 character .zip or extracted folder (baseModel + attire folders)")
    ap.add_argument('donor', nargs='?', help="donor character .pac (WWE 13 Wii ch102.pac, or e.g. the 3-submesh ch342.pac); "
                                             "not needed with --list")
    ap.add_argument('--list', '--detect', dest='list_parts', action='store_true',
                    help="detect and print the attires and every mesh / material of the 2K26 character (with triangle counts and which "
                         "textures exist), then exit")
    ap.add_argument('--only', action='append', metavar='NAME',
                    help="port only meshes / materials with these names (repeat or comma separated; 'Mesh/material', just the mesh or "
                         "just the material, * and ? allowed; see --list)")
    ap.add_argument('--exclude', action='append', metavar='NAME',
                    help="do not port these meshes / materials (same naming as --only)")
    ap.add_argument('--beard-as', choices=['hair', 'body'], default='hair',
                    help="the 2K material named 'combinations' (the beard): hair (default) = ported as hair cards (own submesh / texture 'trans', "
                         "or the hair donor).  body = the beard is painted into the head colour texture and no beard geometry is made - the triangles / vertices go back to the body")
    ap.add_argument('--hair-as', choices=['hair', 'body'], default='hair',
                    help="the same for the material named 'hair' (the head hair of characters that have it besides 'combinations', e.g. Brock Lesnar): "
                         "body = painted into the head texture")
    ap.add_argument('--beard-in-body', action='store_true',
                    help="the 2K material named 'combinations' (the beard) stays 3D hair cards but INSIDE THE BODY MESH: head submesh and body "
                         "atlas, no own hair submesh / texture 'trans' / hair DUMY.  Its strand map is converted to colour and baked into a "
                         "patch of the colour atlas.  (ignored with --beard-as body)")
    ap.add_argument('--hide-under-cloth', action='store_true',
                    help="make the skin texture under clothes invisible: where clothing covers the body, the skin texture is painted in the colour "
                         "of the cloth above it (soft along hems; head, neck and hands untouched), so skin never shows through.  It also "
                         "scales down the skin vertices that are near or crossing the cloth (see --poke-fix); the rest of the skin geometry "
                         "is not touched (that is what --cull does)")
    ap.add_argument('--under-grow', type=int, default=0, metavar='RINGS',
                    help="with --hide-under-cloth, the cloth colour is painted RINGS triangle rings of the 2K26 body mesh "
                         "beyond every hem / waistband too, so no skin-coloured texel is left right at the edge of the cloth where skin shows "
                         "when the cloth moves (belly under the waistband, thigh under the trunks).  Head, neck and hands are never painted.  "
                         "0 (default) = only the skin that is really covered.  Visible skin next to a hem gets a dark edge")
    ap.add_argument('--keep-arm-wrist', action='store_true',
                    help="keep the 2K26 ARM LENGTH and WRIST length: the arms and hands are not matched to the donor's segment lengths "
                         "(same as --arms keep) and --finger-length donor leaves the wrist -> knuckle (palm) length alone; the fingers "
                         "still follow the donor (knuckle spread / height across the hand, finger lengths)")
    ap.add_argument('--poke-fix', choices=['scale', 'remove', 'off'], default='scale',
                    help="with --hide-under-cloth, skin that is near or crossing the cloth above it (poking through / on top of it, in the reduced "
                         "mesh): scale (default) = those skin vertices are scaled down, moved inward along the cloth normal to 0.3 cm under the "
                         "cloth surface (triangles kept, nothing opens up; vertices shared with cloth / head are left alone); remove = the "
                         "skin triangles lying on the cloth are removed; off = only the texture is changed")
    ap.add_argument('--face-tex', action='store_true',
                    help="the 2K26 eyes and the lips (mouth area of head_color) as their OWN texture 'face' on their own submesh, at the "
                         "2K26 resolution, instead of a small patch of the 512x512 colour atlas.  Needs a donor with a spare material "
                         "(ch342 has two; the separate beard texture uses one) - not for the 6-submesh layout")
    ap.add_argument('--face-tex-size', type=int, choices=[512, 1024, 2048], default=1024, metavar='W',
                    help="width of the texture 'face' (height = width / 2), CMPR; default 1024 holds the 2K26 eye and lip crops at full size "
                         "(about 256 KB); 512 halves it, 2048 only helps characters with larger source textures")
    ap.add_argument('--finger-length', choices=['donor', 'keep'], default='donor',
                    help="donor (default): every finger joint (knuckle and the segments) is put where the donor's joint is, the finger segments "
                         "and the palm are stretched to the donor's lengths (needs --pose legs-fingers); keep: the 2K26's own finger proportions")
    ap.add_argument('--no-beard-alpha', dest='beard_alpha', action='store_false',
                    help="beard / hair textures SOLID: the gaps between the strands are filled with the undercoat colour.  Default: the gaps "
                         "are see-through (alpha) in the texture 'trans' / the hair texture / the beard patch of the atlas")
    ap.add_argument('--beard-alpha-cut', type=float, default=0.5, metavar='C',
                    help="1-bit alpha of the texture 'trans' and of the beard patch in the atlas: a texel is opaque when at least this "
                         "share of it is strand (default 0.5; lower = thicker strands, higher = thinner)")
    ap.add_argument('--beard-atlas-share', type=float, default=0.06,
                    help="with --beard-in-body: size of the beard's patch in the atlas, as a weight next to the other textures "
                         "(body about 0.5, head about 0.4); larger = sharper strands, smaller = more pixels for the face / body")
    ap.add_argument('--hair-body-opacity', type=float, default=0.92,
                    help="how opaque the hair colour is where hair is painted into the head texture (--beard-as / --hair-as body)")
    ap.add_argument('--variants', action='store_true',
                    help="also port the duplicate variant meshes (M_Hair_Entrance, M_Jacket_withBelt ...); off by default because they are "
                         "second copies of a mesh that is already ported")
    ap.add_argument('-o', '--out', help="output .pac")
    ap.add_argument('--attire', help="attire to port: its name (Default_Attire, Suit, Suit_2024 - see --list), its number, or a unique "
                                     "part of the name (default: the first one)")
    ap.add_argument('--hair-color', default='auto',
                    help="hair / beard colour: 'auto' (default) = the 2K hair material's root / tip colours when they hold a real "
                         "colour, otherwise the colour painted into the head texture's beard area; 'material' = always the material's "
                         "(g_rootColor / g_tipColor); 'head' = always the head texture's beard colour; '#RRGGBB' = one flat colour")
    ap.add_argument('--beard-tip-mix', type=float, default=0.5,
                    help="with the 2K material colours: how far towards the material's tip colour the average beard strand goes "
                         "(0 = root colour, 1 = tip colour, default 0.5)")
    ap.add_argument('--hair-gap-alpha', type=float, default=0.55,
                    help="separate hair donor route: how opaque the gaps between the strands of the hair texture are (0 = see-through, "
                         "1 = solid, default 0.55); the strands themselves are opaque")
    ap.add_argument('--fit', choices=['height', 'bbox'], default='height',
                    help="height: uniform scale by height (default); bbox: also stretch X to the donor's arm span")
    ap.add_argument('--cull', type=float, default=1.0,
                    help="cm: sideways tolerance when culling body skin that is hidden under clothing (0 = off, default 1.0). "
                         "Culling is conservative: head / neck / hands are never culled and a margin of skin is kept under every cloth edge")
    ap.add_argument('--cull-depth', type=float, default=8.0, help="cm: how far outside the skin a cloth surface may be and still hide it (default 8)")
    ap.add_argument('--cull-margin', type=int, default=2, help="triangle rings of covered skin that are kept under every cloth edge (default 2)")
    ap.add_argument('--face-bias', type=float, default=5.0, help="triangle priority of the face/head (default 5.0)")
    ap.add_argument('--body-bias', type=float, default=2.0, help="triangle priority of the torso (arms/hands/legs follow, default 2.0)")
    ap.add_argument('--limit-boost', type=float, default=1.0,
                    help="multiply the donor's vertex / triangle / size limits (default 1.0 = exactly the donor's maximum; >1 is untested in-game)")
    ap.add_argument('--normals', choices=['donor', 'blend', 'source'], default='donor',
                    help="vertex normals drive the lighting in game.  donor (default): borrow the donor's normals where the surfaces are close "
                         "(the head / neck keep the 2K normals), which lights like the donor does; source: the 2K model's own normals everywhere "
                         "(sharper, can light oddly on the Wii); blend: the average of both.  The relief of the 2K normal maps is baked into "
                         "the colour atlas separately (--bake-normals)")
    ap.add_argument('--normal-dist', type=float, default=2.5, help="donor units for --normals donor")
    ap.add_argument('--weld', default='auto', help="normal weld angle for the importer: 'auto' or degrees")
    ap.add_argument('--tri-scale', type=float, default=1.0, help="scale of the triangle / vertex budget (<=1, default 1 = full donor limit)")
    ap.add_argument('--face-share', type=float, default=0.25,
                    help="share of the body's triangles (everything except beard / hair) that the head must keep; the face priority "
                         "is calibrated until the real result reaches it (default 0.25, 0 = only use --face-bias)")
    ap.add_argument('--hand-share', type=float, default=0.15,
                    help="share of the body's triangles the two hands must keep so the fingers stay readable (default 0.15, "
                         "the Wii donor spends ~19 %%; 0 = only use --body-bias)")
    ap.add_argument('--arms', choices=['match', 'keep'], default='match',
                    help="match (default): upper arm, forearm and hand get the donor's segment LENGTHS (stretched along their own axis, "
                         "no rotation); keep: the 2K26 arm lengths")
    ap.add_argument('--hand-height', choices=['donor', 'keep'], default='donor',
                    help="donor (default): with --arms match, the hands are turned into the donor's hand orientation and the arms are "
                         "raised / lowered a few degrees in their vertical plane so that knuckles and fingers are at the donor's height; "
                         "keep: only the lengths are matched")
    ap.add_argument('--arm-reach', choices=['donor', 'length'], default='donor',
                    help="donor (default): the arm segments are stretched by a few percent at most so the hands are as far out as the "
                         "donor's hands (the 2K26 shoulder joints sit a little further inside); length: exactly the donor's segment lengths")
    ap.add_argument('--beard-texture', choices=['colour', 'raw', 'atlas'], default='colour',
                    help="colour (default): the beard kept in the body model gets its own submesh and the 2K strand map "
                         "(combinations_rai) CONVERTED to a colour texture in --hair-color as its own texture 'trans'; raw: the "
                         "unconverted 2K data map (purple / green); atlas: flat colour patch inside the body atlas, no extra "
                         "submesh (safest for the game).  Nothing of the beard goes into the atlas except with 'atlas'")
    ap.add_argument('--beard-uv', choices=['default', 'wrap'], default='default',
                    help="default (default): the beard takes the 2K hair material's own (default) UVs, copied from the nearest hair "
                         "card of every triangle; wrap: one smooth wrap-around mapping onto the dense strand area of the texture")
    ap.add_argument('--beard-open-mouth', action='store_true',
                    help="cut an opening for the lips (and the see-through gaps of the cards) into the solid beard; "
                         "default: the beard is filled like the 2K model")
    ap.add_argument('--hair-max-tris', type=int, default=1000,
                    help="hard cap of triangles for the beard / hair that stays in the body DUMY (default 1000)")
    ap.add_argument('--hair-max-verts', type=int, default=None,
                    help="hard cap of vertices for that beard / hair (default: 1.15 x the triangle budget with --hair-mode cards, 300 with "
                         "--hair-mode shell; 0 = no vertex cap with shell)")
    ap.add_argument('--hair-mode', choices=['cards', 'shell'], default='cards',
                    help="cards (default): the beard / hair keep their ORIGINAL cards and are only decimated - no vertex merging, no "
                         "clustering, no solid shell, default 2K UVs; shell: the old solid outer shell of the cards (a few hundred "
                         "triangles, smooth, filled like a solid beard) / the old merge + cluster for a hair donor")
    ap.add_argument('--hair-share', type=float, default=0.18,
                    help="share of the triangle budget for beard / hair cards that stay in the body DUMY (no hair donor); "
                         "they get their own budget and are not thinned out by the body decimation (default 0.18)")
    ap.add_argument('--boundary-weight', type=float, default=50.0,
                    help="how strongly open borders (hems, cloth edges, lips / eyelids) are protected from simplification "
                         "(default 50; higher keeps borders exactly, lower spends fewer vertices on borders)")
    ap.add_argument('--size-limit', type=float, default=1.12,
                    help="max size of the new DUMY relative to the donor's file (default 1.12). A decimated mesh strips less "
                         "efficiently than the hand-made donor, so reaching the donor's full vertex / triangle count costs ~10 %% more "
                         "bytes; use 1.0 for a DUMY that is not bigger than the donor's (then ~10 %% fewer triangles)")
    ap.add_argument('--merge', type=float, default=0.01, help="merge vertices closer than this (2K units, cm) before decimation (default 0.01)")
    ap.add_argument('--pose', choices=['legs-fingers', 'full', 'none'], default='legs-fingers',
                    help="legs-fingers: rotate ONLY the legs and fingers to the donor's rest pose (default); "
                         "full: old full limb retarget (arms too, rescales limbs); none: keep the 2K26 pose")
    ap.add_argument('--no-pose', dest='pose', action='store_const', const='none', help="same as --pose none")
    ap.add_argument('--hair', choices=['separate', 'merged'], default='separate',
                    help="separate: hair/beard ('combinations') become their own hair DUMY (PACH 0x2710) with a 'hair_' texture")
    ap.add_argument('--hair-donor', help="pac that already has a hair DUMY (PACH 0x2710), e.g. ch107.pac")
    ap.add_argument('--no-hair-springs', dest='hair_springs', action='store_false',
                    help="do not copy the donor's SpringHairSetting/Collision (0x3C/0x3D) entries")
    ap.add_argument('--eyes', choices=['2k', 'donor'], default='2k',
                    help="2k: eyes (positions + eye_color texture) from the 2K26 model (default); donor: keep the donor's eyes")
    ap.add_argument('--no-blood', dest='blood', action='store_false', help="leave the blood submesh empty")
    ap.add_argument('--seam-weld', type=float, default=SEAM_WELD, metavar='CM',
                    help="stitch the open borders where two 2K26 objects meet: vertices on an open border that lie closer than CM (2K units, "
                         "default %g, 0 = off) to a vertex of another border are merged, before the simplification, so the join stays closed "
                         "(the normal --merge only joins vertices that sit exactly on top of each other).  Bigger values close wider cracks "
                         "but also glue parts that should stay apart" % SEAM_WELD)
    ap.add_argument('--atlas-focus', type=float, default=ATLAS_FOCUS, metavar='F',
                    help="how much of the 512x512 colour atlas the head and the body get (default %g).  0 = the old layout, where the "
                         "patches follow the model area (a big plain trouser / boot texture could take more room than the face); 1 = the head "
                         "gets about 1.9x and the body about 1.7x its old share, trousers / boots / wrist tape / accessories shrink; "
                         "2 = more of the same.  A bigger patch means sharper skin, face and tattoos in the game" % ATLAS_FOCUS)
    ap.add_argument('--sharpen', type=float, default=SHARPEN, metavar='S',
                    help="unsharp mask (strength S, default %g, 0 = off) on every colour patch after it is shrunk into the 512 atlas, so the "
                         "textures look clearer after the CMPR compression and the console's smoothing.  Only the PAC atlas is sharpened; "
                         "the 4K export stays as the source" % SHARPEN)
    ap.add_argument('--no-atlas-4k', dest='atlas_4k', action='store_false', help="do not export the 4K atlas image")
    ap.add_argument('--no-atlas-plain', dest='atlas_plain', action='store_false',
                    help="with --hide-under-cloth the atlas image is exported twice: <out>_atlas_4k.png (skin under the clothes painted) and "
                         "<out>_atlas_4k_plain.png (the plain 2K26 skin texture).  This switches the plain one off")
    ap.add_argument('--atlas-size', type=int, default=4096, choices=[1024, 2048, 4096, 8192],
                    help="edge of the exported atlas image (default 4096); the PAC itself keeps the donor's 512x512 CMPR texture")
    ap.add_argument('--no-bake-normals', dest='bake_normals', action='store_const', const=0.0, default=1.0,
                    help="do not merge the normal maps into the colour texture (the same as --bake-normals 0)")
    ap.add_argument('--bake-normals', type=float, default=1.0, metavar='STRENGTH',
                    help="bake the relief of the 2K normal maps (muscles, veins, wrinkles) into the PAC's colour atlas as light and shadow "
                         "(default 1.0; 0 = off, 2 = twice as strong).  Flat areas do not change; the game's own lighting is not affected")
    ap.add_argument('--bake-shadow', type=float, default=1.0, metavar='S',
                    help="how much stronger the little shadows (dark side of the baked relief, lit from above by the green channel of the "
                         "normal map) are than the highlights (default 1.0; 0 = same as the highlights, 2 = much deeper shadows)")
    ap.add_argument('--bake-size', type=int, default=2048, help="edge of the bake used for --bake-normals (1024 needs much less memory)")
    ap.add_argument('--no-normal-atlas', dest='normal_atlas', action='store_false',
                    help="do not bake the object-space normal atlas (<out>_normals_object_4k.png)")
    ap.add_argument('--normal-green', choices=['auto', 'up', 'down'], default='auto',
                    help="green channel of the 2K normal maps: up (OpenGL) / down (DirectX); auto detects it from the body / head maps")
    ap.add_argument('--normal-space', choices=['obj', 'pac'], default='obj',
                    help="axes of the baked object-space normals: obj = like the --obj export / preview (Y up, face +Z, default), "
                         "pac = the PAC's own axes (Y down, face -Z)")
    ap.add_argument('--obj', action='store_true', help="also write the decimated model as .obj")
    args = ap.parse_args(argv)
    if args.list_parts:
        print_scan(scan_character(args.character, log=lambda s: None))
        return
    if not args.donor:
        ap.error("the donor .pac is required (only --list works without it)")
    if args.tri_scale > 1.0:
        ap.error("--tri-scale must be <= 1 (use --limit-boost to go above the donor's limits)")
    build(args)




if __name__ == '__main__':
    main()
