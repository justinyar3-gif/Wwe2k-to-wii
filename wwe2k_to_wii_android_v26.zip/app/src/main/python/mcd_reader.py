# -*- coding: utf-8 -*-
"""Minimal WWE 2K (MCD! v4 / MDL 2.x) reader - geometry, skin, materials, LOD0 triangles, bone table.
Reverse engineered from 2K26 attire / baseModel files (see notes in wwe2k_to_wii.py)."""
import struct
import numpy as np

FMT = {'R32_G32_B32': (12, '<f4', 3), 'R8_G8_B8_A8': (4, None, 4), 'R8': (1, None, 1), 'R32': (4, '<u4', 1),
       'R32_G32': (8, '<f4', 2), 'R16_G16': (4, None, 2), 'R16_G16_B16_A16': (8, None, 4),
       'R32_G32_B32_A32': (16, '<f4', 4), 'R16': (2, None, 1)}


class McdError(Exception):
    pass


class Mesh(object):
    pass


class Mcd(object):
    def __init__(self, path):
        self.path = path
        d = self.d = open(path, 'rb').read()
        if d[:4] not in (b'MCD!', b'MDL!'):
            raise McdError('not an MCD! / MDL! file: %s' % path)
        # 'MDL!' = the older 2K export (WWE 2K24 and earlier characters, e.g. the .mdl / .mtls / .ctg folders): the same
        # chunks (TEXT BONE MTL! MBfD LODs) but a shorter file and mesh header, and stream data aligned to 4 bytes.
        self.mdl = d[:4] == b'MDL!'
        self.version = struct.unpack_from('<I', d, 4)[0]
        # --- string table
        t = d.find(b'TEXT')
        tsz, tcnt = struct.unpack_from('<II', d, t + 4)
        offs = struct.unpack_from('<%dI' % tcnt, d, t + 12)
        sb = t + 12 + 4 * tcnt
        self.strs = []
        for o in offs:
            e = d.index(b'\0', sb + o)
            self.strs.append(d[sb + o:e].decode('latin1'))
        self.text_end = t + 8 + tsz
        # --- bones
        b = d.find(b'BONE', self.text_end - 4)
        self._parse_bones(b)
        # --- materials list
        m = d.find(b'MTL!', b)
        msz, mcnt = struct.unpack_from('<II', d, m + 4)
        # one entry per material: [u32 string index] (older files) or [u16 string index][u32 hash] (6 bytes, newer files)
        stride = (msz - 4) // mcnt if mcnt else 4
        if stride == 6:
            self.materials = [self.strs[struct.unpack_from('<H', d, m + 12 + 6 * k)[0]] for k in range(mcnt)]
        else:
            self.materials = [self.strs[i] for i in struct.unpack_from('<%dI' % mcnt, d, m + 12)]
        # --- meshes
        mb = d.find(b'MBfD', m)
        msz, nmesh = struct.unpack_from('<II', d, mb + 4)
        p = mb + 12
        self.meshes = []
        for mi in range(nmesh):
            me, p = self._parse_mesh(p, mi)
            self.meshes.append(me)
        # --- LODs
        lp = d.find(b'LODs', p - 8)
        self._parse_lods(lp)

    # ------------------------------------------------------------------
    def _parse_bones(self, b):
        d = self.d
        sz = struct.unpack_from('<I', d, b + 4)[0]
        scale, thr, n = struct.unpack_from('<ffI', d, b + 8)
        self.bone_end = b + 8 + sz
        self.bone_count = n
        self.bones = []          # (name, parent)
        # records found empirically: 33 bytes, [i32 -1][u16 idx][u16 parent][6 x f32][u8]; record 0 is shifted
        self.bone_names = []
        names = [s for s in self.strs[1:] if s[:2] in ('J_', 'H_') or s.startswith('Bip') or s.startswith('d_')]
        # bone names appear first in the string table, one per bone, in bone order
        self.bone_names = self.strs[1:1 + n] if n < len(self.strs) else names

    def _parse_mesh(self, p, mi):
        d, strs = self.d, self.strs
        me = Mesh()
        me.start = p
        mdl = getattr(self, 'mdl', False)
        if mdl:
            # MDL! mesh header: [u32 name][u32 flag][u16][i32 -1][6 x f32 bbox][u32 nverts][u32 nstreams] = 46 bytes
            nid, flag = struct.unpack_from('<II', d, p)
            me.bbox = struct.unpack_from('<6f', d, p + 14)
            nv, ns = struct.unpack_from('<II', d, p + 38)
            q = p + 46
        else:
            nid, flag, z, m1 = struct.unpack_from('<IIII', d, p)
            me.bbox = struct.unpack_from('<6f', d, p + 16)
            nv, ns = struct.unpack_from('<II', d, p + 40)
            q = p + 48
        me.name = strs[nid] if nid < len(strs) else str(nid)
        me.flag = flag
        me.nv = nv
        me.streams = {}
        uv = []
        for s in range(ns):
            if mdl:
                # stream header: 12 bytes hash + 4 x u16 (semantic, format, type, name); the data starts 4-aligned
                sem, fmt, typ, _ = struct.unpack_from('<HHHH', d, q + 12)
                sem, fmt, typ = strs[sem], strs[fmt], strs[typ]
                size, dt, nc = FMT[fmt]
                q = (q + 20 + 3) & ~3
                raw = d[q:q + size * nv]
                q = (q + size * nv + 3) & ~3
            else:
                sem, fmt, typ, _ = struct.unpack_from('<HHHH', d, q + 12)
                sem, fmt, typ = strs[sem], strs[fmt], strs[typ]
                size, dt, nc = FMT[fmt]
                raw = d[q + 20:q + 20 + size * nv]
                q += 20 + ((size * nv + 3) & ~3)
            if sem == 'POSITION':
                me.streams['POSITION'] = np.frombuffer(raw, '<f4').reshape(nv, 3).copy()
            elif sem == 'TEXCOORD':
                uv.append(np.frombuffer(raw, '<f4').reshape(nv, 2).copy())
            elif sem == 'NORMAL':
                if fmt == 'R32_G32_B32':                      # newer files: float normals
                    a = np.frombuffer(raw, '<f4').reshape(nv, 3).astype(np.float32)
                    a = np.concatenate([a, np.zeros((nv, 1), np.float32)], 1)
                else:                                         # int8 x 4
                    a = np.frombuffer(raw, 'i1').reshape(nv, 4).astype(np.float32) / 127.0
                me.streams['NORMAL'] = a
            elif sem == 'COLOR':
                me.streams['COLOR'] = np.frombuffer(raw, 'u1').reshape(nv, 4).astype(np.float32) / 255.0
            else:
                me.streams[sem] = raw
        me.uvs = uv
        # skin section: [u16 ngroups][u16 wpv][u16 bone x nv*wpv][u8 weight x nv*wpv]
        ng, wpv = struct.unpack_from('<HH', d, q)
        me.skin_groups, me.wpv = ng, wpv
        q += 4
        me.bone_idx = np.frombuffer(d[q:q + 2 * nv * wpv], '<u2').reshape(nv, wpv).copy()
        q += (2 * nv * wpv + 3) & ~3
        me.weights = np.frombuffer(d[q:q + nv * wpv], 'u1').reshape(nv, wpv).astype(np.float32) / 255.0
        q += nv * wpv
        me.skin_end = q
        e = d.find(b'ENDM', q)
        me.end = e + 8
        me.tail = d[q:e]
        return me, me.end

    def _parse_lods(self, p):
        """Only LOD0 is read: nm entries of [u16 mesh][u32 nIdx][u16 idx...][pad][u32 nsub][nsub x (mat,start,count)]ENDM"""
        d = self.d
        tag, size, nlod, nm = struct.unpack_from('<4sIII', d, p)
        if tag != b'LODs':
            raise McdError('LODs chunk not found')
        self.nlod = nlod
        lod = {}
        q = p + 16
        for _ in range(nm):
            mi, cnt = struct.unpack_from('<HI', d, q)
            q += 6
            idx = np.frombuffer(d[q:q + 2 * cnt], '<u2').astype(np.int64)
            q += 2 * cnt
            e = d.find(b'ENDM', q)
            tr = d[q:e]
            if len(tr) % 4 == 2:
                tr = tr[2:]
            nsub = struct.unpack_from('<I', tr, 0)[0]
            if len(tr) == 4 + 12 * nsub:                       # older files: (material, start, count)
                subs = [struct.unpack_from('<III', tr, 4 + 12 * k) for k in range(nsub)]
            elif len(tr) == 8 + 16 * nsub:                     # newer files: (material, start, count, max vertex) + a closing u32
                subs = [struct.unpack_from('<III', tr, 4 + 16 * k) for k in range(nsub)]
            else:
                raise McdError('unexpected LOD trailer size %d for %d submeshes' % (len(tr), nsub))
            lod[mi] = dict(idx=idx, subs=[dict(mat=a, start=b, count=c) for a, b, c in subs])
            q = e + 8
        self.lods = [lod]
